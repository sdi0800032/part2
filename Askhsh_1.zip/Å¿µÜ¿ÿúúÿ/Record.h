#ifndef RECORD_H
#define RECORD_H

typedef struct{
	int id;
	char name[15];
	char surname[20];
	char city[10];
}Record;

#endif
