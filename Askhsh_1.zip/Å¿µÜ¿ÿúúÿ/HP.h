#ifndef __HEAP_H__
#define __HEAP_H__
#include <stdio.h>
#include "Record.h"

int HP_CreateFile(char*fileName);
int HP_OpenFile(char*fileName);
int HP_CloseFile(int fileDesc);
int HP_InsertEntry(int fileDesc,Record record);
int HP_DeleteEntry(int fileDesc,char*fieldName,void*value);
void HP_GetAllEntries(int fileDesc,char*fieldName,void*value);
#endif
