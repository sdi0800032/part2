#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BF.h"                                         /* Include BF library */
#include "Sorted.h"                                        /* Include HP librarty */
#include "Record.h"

int Sorted_CreateFile(char*fileName)
{
int FileNo,BlockNo,Pointer=-1;
char Sorted[6]="Sorted";
void*block;

if (BF_CreateFile(fileName)<0)
{
	BF_PrintError("Error creating File");
	return -1;
}
FileNo=BF_OpenFile(fileName);
if (FileNo<0)
{
	BF_PrintError("Error Opening File");
	return -1;
}

if (BF_AllocateBlock(FileNo)<0)    /*An to prwto arxeio einai Sorted tote sto telos tou prwtou block tha exoume Sorted*/
{
	BF_PrintError("Error Allocating First Block");
	return -1;
}
if (BF_ReadBlock(FileNo, 0, &block) < 0) 
{
	BF_PrintError("Error reading block");
	return -1;
}
BlockNo=BF_GetBlockCounter(FileNo)-1;
memcpy(block+10*sizeof(Record),Sorted,sizeof(char)*6);
memcpy(block+10*sizeof(Record)+sizeof(char)*6,&Pointer,sizeof(int));
if (BF_WriteBlock(FileNo,BlockNo) < 0)
{
	BF_PrintError("Error writing block back");
	return -1;
}
if (BF_CloseFile(FileNo))
{
	BF_PrintError("Error Closing File");
	return -1;
}
}

int Sorted_OpenFile(char*fileName)
{
int FileNo;
char HeapCheck[6];
void*block;



FileNo=BF_OpenFile(fileName);
if (FileNo<0)
{
	BF_PrintError("Error Opening File");
	return -1;
}
if (BF_ReadBlock(FileNo, 0, &block) < 0) 
{
	BF_PrintError("Error reading block");
	return -1;
}	
memcpy(HeapCheck,block+sizeof(Record)*10,sizeof(char[6]));
if(strcmp(HeapCheck,"Sorted")!=0)
{
    if (BF_CloseFile(FileNo))
    {
	BF_PrintError("Error Closing File");
	return -1;
    }
    return -1;
}
else	return FileNo;

}


int Sorted_CloseFile(int fileDesc)
{
if (BF_CloseFile(fileDesc))
{
	BF_PrintError("Error Closing File");
	return -1;
}
else return 0;
}

int Sorted_InsertEntry(int fileDesc,Record record)
{
    int BlockNo,i,j,flag,tempBlockNo,EntriesNo,LastBlock,tempBlock;
    void*block;
    Record re;

    BlockNo=0;
    if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
    {
            BF_PrintError("Error reading block");
            return -1;
    }
    memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(char)*6,sizeof(int));
    if(BlockNo==-1)
    {
        if(BF_AllocateBlock(fileDesc)<0)
        {
           BF_PrintError("Error Allocating Block");
           return -1;
        }
        BlockNo=BF_GetBlockCounter(fileDesc)-1;
        memcpy(block+10*sizeof(Record)+sizeof(char)*6,&BlockNo,sizeof(int));
        if (BF_WriteBlock(fileDesc,0) < 0)
        {
                BF_PrintError("Error writing block back");
                return -1;
        }
        if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
        {
              BF_PrintError("Error reading block");
              return -1;
        }
        BlockNo=-1;
        memcpy(block+10*sizeof(Record)+sizeof(int),&BlockNo,sizeof(int)); //Vazw na deixnei sto -1 mias kai einai to teleftaio
        memcpy(block,&record,sizeof(Record));
        EntriesNo=1;
        memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
        BlockNo=1;
        if (BF_WriteBlock(fileDesc,BlockNo) < 0)
        {
	    BF_PrintError("Error writing block back");
	    return -1;
	}
        BlockNo=BF_GetBlockCounter(fileDesc)-1;
        return 0;
    }
    flag=0;
    tempBlockNo=1;
    LastBlock=1;
    while(LastBlock< BF_GetBlockCounter(fileDesc))
    {
    
        if (BF_ReadBlock(fileDesc,tempBlockNo, &block) < 0) 
        {
            BF_PrintError("Error reading block");
            return -1;
        }
    memcpy(&tempBlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
    if(tempBlockNo>=1)   LastBlock=tempBlockNo;
    else break;
    }
    /*To teleftaio block einai to Last block*/
    while(flag==0)
    {   
        if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
        {
                BF_PrintError("Error reading block");
                return -1;
        }
        memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
        i=0;
        while(i<EntriesNo)
        {
            memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
            if(re.id>=record.id)
            {
                flag=1;
                break;
            }
            i++;
        }
        if(i==10 && BlockNo==LastBlock)
        {
            i=0;
            BlockNo++;
            flag=1;
        }
        if(flag!=1)
        {
            memcpy(&tempBlock,block+10*sizeof(Record)+sizeof(int),sizeof(int));
            if(tempBlock==-1)       flag=1;
            else BlockNo=tempBlock;
        }
    }
    /*Twra sto BlockNo exw to Block sto opoio tha ginei h eggrafh */
    /*Sto i exw thn thesh sthn opoia tha ginei h eggrafh*/
    /*H seira einai afkxousa*/

    /*Twra tha arxisw thn metakinhsh twn eggrafwn prws ta pisw*/
    tempBlock=LastBlock;
    while(tempBlock>=1)
    {
        if (BF_ReadBlock(fileDesc,tempBlock, &block) < 0) 
        {
                BF_PrintError("Error reading block");
                return -1;
        }
        memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
        if(EntriesNo==10)                                                       //An einai gemato symvainei mono sto teleftaio
        {
            memcpy(&(re),block+9*sizeof(Record),sizeof(Record));                     //Pairnw thn teleftaia eggrafh
            memcpy(&tempBlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
            if(tempBlockNo==-1)                                                 //An to arxeio den exei allo block
            {
                if(LastBlock==BF_GetBlockCounter(fileDesc)-1)                     //Tote den yparxei desmevmeno allo block
                { 
                    if(BF_AllocateBlock(fileDesc)<0)
                    {
                        BF_PrintError("Error Allocating Block");
                        return -1;
                    }
                    tempBlockNo=BF_GetBlockCounter(fileDesc)-1;
                    memcpy(block+10*sizeof(Record)+sizeof(int),&tempBlockNo,sizeof(int));
                    if (BF_WriteBlock(fileDesc,tempBlock) < 0)
                    {
                        BF_PrintError("Error writing block back");
                        return -1;
                    }
                    if (BF_ReadBlock(fileDesc,tempBlockNo, &block) < 0) 
                    {
                        BF_PrintError("Error reading block");
                        return -1;
                    }
                    tempBlockNo=-1;
                    memcpy(block+10*sizeof(Record)+sizeof(int),&tempBlockNo,sizeof(int)); //Vazw na deixnei sto -1 mias kai einai to teleftaio
                    EntriesNo=0;
                    memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
                    tempBlockNo=BF_GetBlockCounter(fileDesc)-1;
                    if (BF_WriteBlock(fileDesc,tempBlockNo) < 0)
                    {
			BF_PrintError("Error writing block");
			return -1;
	            }
                    
                }
                else    tempBlockNo=LastBlock+1;
            }
            if(tempBlockNo!=BlockNo)
            {
                 if(BF_ReadBlock(fileDesc,tempBlockNo,&block)<0)                     //Diavazw to neo teleftaio
                 {
                     BF_PrintError("Error reading Block");
                     return -1;
                  }
                  memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
                  memcpy(block+0*sizeof(Record),&re,sizeof(Record));
                  EntriesNo++;
                  memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
                  if(BF_WriteBlock(fileDesc,tempBlockNo)<0)
                  {
                      BF_PrintError("Error writing block");
                       return -1;
                  }
                  if(BF_ReadBlock(fileDesc,tempBlock,&block)<0)                       //Diavazw to block apo to opoio phra thn eggrafh
                  {
                      BF_PrintError("Error reading Block");
                      return -1;
                  }
                  EntriesNo=9;                                                        //Twra exei 9 eggrafes kathos thn teleftaia thn edwsa sto allo
                  memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
                  if(BF_WriteBlock(fileDesc,tempBlock)<0)
                  {
                      BF_PrintError("Error writing block");
                      return -1;
                  }
            }
           
        }
        if(tempBlock==BlockNo)
        {
            if(BF_ReadBlock(fileDesc,tempBlock,&block)<0)                       //Diavazw to block apo to opoio phra thn eggrafh
            {
               BF_PrintError("Error reading Block");
               return -1;
            }
            memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
            for(j=EntriesNo-1;j>=i;j--)
            {
               memcpy(&re,block+j*sizeof(Record),sizeof(Record));
               memcpy(block+(j+1)*sizeof(Record),&re,sizeof(Record)); 
            }
            memcpy(block+i*sizeof(Record),&record,sizeof(Record));
            if(EntriesNo!=10)
            {
                EntriesNo++;
                memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
            }
            if(BF_WriteBlock(fileDesc,tempBlock)<0)
            {
                    BF_PrintError("Error writing block");
                    return -1;
            }
            tempBlock=-1;
        }
        else if(tempBlockNo==BlockNo)
        {
            if(BF_ReadBlock(fileDesc,tempBlockNo,&block)<0)                       //Diavazw to block apo to opoio phra thn eggrafh
            {
               BF_PrintError("Error reading Block");
               return -1;
            }
            memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
            for(j=EntriesNo-1;j>=i;j--)
            {
               memcpy(&re,block+j*sizeof(Record),sizeof(Record));
               memcpy(block+(j+1)*sizeof(Record),&re,sizeof(Record)); 
            }
            memcpy(block+i*sizeof(Record),&record,sizeof(Record));
            if(EntriesNo!=10)
            {
                EntriesNo++;
                memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
            }
            if(BF_WriteBlock(fileDesc,tempBlockNo)<0)
            {
                    BF_PrintError("Error writing block");
                    return -1;
            }
            tempBlock=-1;
        }
        else
        {
                if(BF_ReadBlock(fileDesc,tempBlock,&block)<0)                       //Diavazw to block apo to opoio phra thn eggrafh
                {
                    BF_PrintError("Error reading Block");
                    return -1;
                }  
                memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
                for(j=EntriesNo-1;j>=0;j--)
                {
                   memcpy(&re,block+j*sizeof(Record),sizeof(Record));
                   memcpy(block+(j+1)*sizeof(Record),&re,sizeof(Record));
                }
                if(BF_WriteBlock(fileDesc,tempBlock)<0)
                {
                        BF_PrintError("Error writing block");
                        return -1;
                }
                tempBlock--;
        }
    }
    return 0;
}

void Sorted_GetAllEntries(int fileDesc,char*fieldName,void*value)
{
int i,EntriesNo,BlockNo,flag,imid,imax;
int*Pointer;
Record re;
void*block;



flag=0;
BlockNo=1;
while(flag==0)
{
	if(BlockNo==-1)	break;
	if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
	{
		BF_PrintError("Error reading block");
	}
	memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));   /*kai kataxwro to plhthos ton eggrafwn tou sto EntriesNo*/
	if(EntriesNo==0) break;   				  /*An to block einai adeio kai ta ypoloipa tha einai adeia ara teliwsa*/
	if((int*)value==NULL)					/*An to pedio Value einai NULL*/
	{
		i=0;
		while(i<EntriesNo)  /////////////////////////////////////Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
   			strcpy( re.surname, "" );
    			strcpy( re.city, "");   				  	  
           		memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
			memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record), sizeof(char[15]));
			memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
			memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
			printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			i++;
		}
	memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
        continue;
	}
        else if( (strcmp( fieldName, "id" )) == 0 )			  /*An anazhtw to record me vash to id*/
        {
                i=0;
                imid=0;
                imax=EntriesNo-1;
                while(imax>=i)
                {
                        imid=(imax+i)/2;
                        memcpy(&(re.id),block+imid*sizeof(Record),sizeof(int));
                        if(re.id < (int)value)   i=imid+1;
                        else if (re.id > (int)value)   imax=imid-1;
                        else
                        {
                                memcpy(&(re.id),block+(imid-1)*sizeof(Record),sizeof(int));
                                if(re.id==(int)value)
                                {
                                do
                                {
                                        imid--;
                                        memcpy(&(re.id),block+(imid-1)*sizeof(Record),sizeof(int));
                                        if(re.id==(int)value)      continue;
                                        else break;
                                }
                                while(imid>=0);
                                }
                                memcpy(&(re.id),block+imid*sizeof(Record),sizeof(int));
                                while(re.id == (int)value)
                                {
                                        memcpy(&(re.name),block+sizeof(int)+imid*sizeof(Record), sizeof(char[15]));
                                        memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+imid*sizeof(Record),sizeof(char[20]));
                                        memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+imid*sizeof(Record),sizeof(char[10]));
                                        printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
                                        imid++;
                                        if(imid<=9)  memcpy(&(re.id),block+imid*sizeof(Record),sizeof(int));
                                        else break;
                                }
                                i=10;
                        } 
                        
                }
         if(i>=9)
        {
            memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int)); 
        }
        else   flag=1;
	}
        else if  (strcmp( fieldName, "name" ) == 0 )
     	{
                i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
       			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
   			strcpy( re.surname, "" );
    			strcpy( re.city, "");  
           		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
			if( strcmp(re.name,(char*)value)== 0 )		  /*An einai afto pou anazhtw*/
			{
				memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
				memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
				memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
				printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			}
			i++;
		}
                        
                
        if(i==9)	flag=1;						/*An den einai gemato to arxeio block afto den yparxoun alles eggrafes*/
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	/*An den einai gemato paw sto epomeno*/
        }

	else if( strcmp( fieldName, "surname" ) == 0 )
        {
           	i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
       			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
  			strcpy( re.surname, "" );
    			strcpy( re.city, "");  
           		memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
           		if( strcmp(re.surname,(char*)value)== 0 )
			{
         		     	memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
                		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
                		memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
				printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			}
		i++;
		}
        if(i==9)	flag=1;						/*An den einai gemato to arxeio block afto den yparxoun alles eggrafes*/
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	/*An den einai gemato paw sto epomeno*/
	}
	else if( strcmp( fieldName, "city")==0)
        {
		i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
       			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
   			strcpy( re.surname, "" );
    			strcpy( re.city, "");  
           		memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
           		if( strcmp(re.city,(char*)value)== 0 )
			{
                		memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
                		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
                		memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));;
				printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			}
			i++; 
		}
        if(i==9)	flag=1;						/*An den einai gemato to arxeio block afto den yparxoun alles eggrafes*/
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	/*An den einai gemato paw sto epomeno*/
	}
}
}



int Sorted_DeleteEntry(int fileDesc,char*fieldName,void*value)
{

int SDeleteEntry(int fileDesc,int BlockNo,int i);
int i,j,EntriesNo,BlockNo,flag,TempEntNo,LastBlock,TempFlag,imid,imax,NextBlockNo;
Record re;
void*block;


flag=0;
BlockNo=1;
while(flag==0)
{
	if(BlockNo==-1)	break;
	if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
	{
		BF_PrintError("Error reading block");
		return -1;
	}
	memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));   //kai kataxwro to plhthos ton eggrafwn tou sto EntriesNo
	if(EntriesNo==0) break;   				  //An to block einai adeio kai ta ypoloipa tha einai adeia ara teliwsa
      
	if( (strcmp( fieldName, "id" )) == 0 )			  //An anazhtw to record me vash to id       
        {
                i=0;
                imid=0;
                imax=EntriesNo-1;
                while(imax>=i)
                {
                        imid=(imax+i)/2;
                        memcpy(&(re.id),block+imid*sizeof(Record),sizeof(int));
                        if(re.id < (int)value)   i=imid+1;
                        else if (re.id > (int)value)   imax=imid-1;
                        else
                        {
                                memcpy(&(re.id),block+(imid-1)*sizeof(Record),sizeof(int));
                                if(re.id==(int)value)                                  //An den einai to prwto stoixeio me id==value
                                {
                                        do                                                      //To imid tha apoxthsei thn timh ths theshs tou prtou stoixzeiou to block me id==value
                                        {
                                                imid--;
                                                memcpy(&(re.id),block+(imid-1)*sizeof(Record),sizeof(int));
                                                if(re.id==(int)value)      continue;
                                                else break;
                                        }
                                        while(imid>=0);
                                }
                                memcpy(&(re.id),block+imid*sizeof(Record),sizeof(int));
                                while(re.id==(int)value)
                                {
                                    SDeleteEntry(fileDesc,BlockNo,imid);
                                    if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
                                    {                               
                                       BF_PrintError("Error reading block");
                                        return -1;
                                    }
                                    memcpy(&(re.id),block+imid*sizeof(Record),sizeof(int));
                                    memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
                                    if(imid>EntriesNo-1)  return 1;
                                    if(imid==0 && BlockNo>1)
                                    {
                                       if (BF_ReadBlock(fileDesc,(BlockNo-1), &block) < 0) 
                                       {                               
                                          BF_PrintError("Error reading block");
                                          return -1;
                                       } 
                                       memcpy(&NextBlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
                                       if(NextBlockNo<0)        flag=1;
                                    }
                                    
                               }
                               i=10;
                        }
                }
        if(i>=9)
        {
             memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int)); 
        }
        else   flag=1;                       
	}
	else if  (strcmp( fieldName, "name" ) == 0 )
     	{
           	i=0;
		while(i<EntriesNo)   					  //Mexri na elegxksw kai to teleftaio stoixeio tou block
		{
    			strcpy( re.name, "" );				//Arxikopoiw to name
           		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
			if( strcmp(re.name,(char*)value)== 0 )		  //An einai afto pou anazhtw
			{
				SDeleteEntry(fileDesc,BlockNo,i);
			}
			i++;
		}
        if(i==9)	flag=1;						//An den einai gemato to arxeio block afto den yparxoun alles eggrafes
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	//An den einai gemato paw sto epomeno
	}

	else if( strcmp( fieldName, "surname" ) == 0 )
        {
           	i=0;
		while(i<EntriesNo)   					  //Mexri na elegxksw kai to teleftaio stoixeio tou block
		{
  			strcpy( re.surname, "" );
           		memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
           		if( strcmp(re.surname,(char*)value)== 0 )
			{
         		     	SDeleteEntry(fileDesc,BlockNo,i);
			}
		i++;
		}
        if(i==9)	flag=1;						//An den einai gemato to arxeio block afto den yparxoun alles eggrafes
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	//An den einai gemato paw sto epomeno
	}
	else if( strcmp( fieldName, "city")==0)
        {
		i=0;
		while(i<EntriesNo)   					  //Mexri na elegxksw kai to teleftaio stoixeio tou block
		{
    			strcpy( re.city, "");  
           		memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
           		if( strcmp(re.city,(char*)value)== 0 )
			{
                		SDeleteEntry(fileDesc,BlockNo,i);
			}
			i++; 
		}
        if(i==9)	flag=1;						//An den einai gemato to arxeio block afto den yparxoun alles eggrafes
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	//An den einai gemato paw sto epomeno
	}
}
return 1;
}




int SDeleteEntry(int fileDesc,int SBlockNo,int imid)
{
    void*block;
    void DeleteLastBlock(int fileDesc);
    int EntriesNo,BlockNo,NextBlockNo,j,i;
    Record re;
    BlockNo=SBlockNo;
    if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
    {
	BF_PrintError("Error reading block");
	return -1;
    }
    memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
    memcpy(&NextBlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
    i=imid;
    while(i<EntriesNo-1)                                                        //Metakinw tis eggrafes tou block kata ena apo thn epomenh
    {                                                                        //tou record pros diagrafh kai meta
        i++;    
        if(BF_ReadBlock(fileDesc,BlockNo,&block)<0)
        {
            BF_PrintError("Error ReadingBlock");
            return -1;
        }
        memcpy(&re,block+i*sizeof(Record),sizeof(Record));
        memcpy(block+(i-1)*sizeof(Record),&re,sizeof(Record));
        if(BF_WriteBlock(fileDesc,BlockNo)<0)
        {
            BF_PrintError("Error Writing Block");
            return -1;
        }
    }
    if(NextBlockNo<0)                                                           //An h diagrafh ginetai sto teleftaio block
    {                                                                       //Tote den xreiazetai na metakinhsw ta records twn parakatw blocks
        EntriesNo--;
        if (EntriesNo==0)
        {
            DeleteLastBlock(fileDesc);
            return 1;
        }
        if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
        {
    	    BF_PrintError("Error reading block");
	    return -1;
        }
        memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
        if(BF_WriteBlock(fileDesc,BlockNo)<0)
        {
            BF_PrintError("Error Writing Block");
            return -1;
        }
    }
    else
    {
        while(NextBlockNo>0)
        {
            BlockNo=NextBlockNo;
            if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
            {
    	        BF_PrintError("Error reading block");
	        return -1;
            }
            memcpy(&re,block,sizeof(Record));                                   //Antigrafw to prwto stoixeio tou block
            if (BF_ReadBlock(fileDesc,(BlockNo-1), &block) < 0)                 //Kai to vazw sthn teleftaia thesh tou prohgoumenou
            {
    	        BF_PrintError("Error reading block");
	        return -1;
            }
            memcpy(block+9*sizeof(Record),&re,sizeof(Record));
            if(BF_WriteBlock(fileDesc,BlockNo-1)<0)
            {
                BF_PrintError("Error Writing Block");
                return -1;
            }
            if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
            {
    	        BF_PrintError("Error reading block");
	        return -1;
            }
            memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
            memcpy(&NextBlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
            if(EntriesNo==1)    {DeleteLastBlock(fileDesc); break;}                         //An eixe mono mia eggrafh kai afth phge sto prohgoumeno tote adeiase kai to svhnw
            else
            {
                i=0;
                while(i<EntriesNo-1)
                {
                    i++;
                    if(BF_ReadBlock(fileDesc,BlockNo,&block)<0)
                    {
                        BF_PrintError("Error ReadingBlock");
                        return -1;
                    }
                    memcpy(&re,block+i*sizeof(Record),sizeof(Record));
                    memcpy(block+(i-1)*sizeof(Record),&re,sizeof(Record));
                    if(BF_WriteBlock(fileDesc,BlockNo)<0)
                    {
                       BF_PrintError("Error Writing Block");
                       return -1;
                    }
                }
                if(NextBlockNo<0)
                {
                    EntriesNo--;
                    if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
                    {
                        BF_PrintError("Error reading block");
                        return -1;
                    }
                    memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
                    if(BF_WriteBlock(fileDesc,BlockNo)<0)
                    {
                        BF_PrintError("Error Writing Block");
                        return -1;
                    }
                }
            }
        }
    }
    
return 1;
}


void DeleteLastBlock(int fileDesc)
{
    int LastBlock,TempBlockNo,K;
    void*block;
    
    TempBlockNo=1;
    while(TempBlockNo>0)
    {                                                  
        if(BF_ReadBlock(fileDesc,TempBlockNo,&block)<0)
        {
            BF_PrintError("Error Reading Block");
        }
        memcpy(&TempBlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
        if (TempBlockNo>0)
        {
            LastBlock=TempBlockNo;                                               //To teleftaio Block
        }
    }
    if(BF_ReadBlock(fileDesc,LastBlock,&block))                                   //To adeiazw
    {
        BF_PrintError("Error Reading Block");
    }
    K=0;
    memcpy(block+10*sizeof(Record),&K,sizeof(int));
    if(BF_WriteBlock(fileDesc,LastBlock)<0)
    {
        BF_PrintError("Error Writing Block");
    }
    LastBlock--;
     if(BF_ReadBlock(fileDesc,LastBlock,&block))                                   //To adeiazw
    {
        BF_PrintError("Error Reading Block");
    }
    K=-1;
    memcpy(block+10*sizeof(Record)+sizeof(int),&K,sizeof(int));                //Vazw ton eixth tou proteleftaiou na mhn deixnei pouthena
    if(BF_WriteBlock(fileDesc,LastBlock)<0)
    {
        BF_PrintError("Error Writing Block");
    }
  
    return;
}


