#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BF.h"                                         /* Include BF library */
#include "HP.h"                                        /* Include HP librarty */
#include "Record.h"
#define BLOCK_SIZE 1024


int HP_CreateFile(char*fileName)
{
int FileNo,BlockNo,Pointer=-1;
char Heap[4]="Heap";
void*block;

if (BF_CreateFile(fileName)<0)
{
	BF_PrintError("Error creating File");
	return -1;
}
FileNo=BF_OpenFile(fileName);
if (FileNo<0)
{
	BF_PrintError("Error Opening File");
	return -1;
}

if (BF_AllocateBlock(FileNo)<0)    /*An to prwto arxeio einai Heap tote 			sto telos tou prwtou block tha exoume Heap*/
{
	BF_PrintError("Error Allocating First Block");
	return -1;
}
if (BF_ReadBlock(FileNo, 0, &block) < 0) 
{
	BF_PrintError("Error reading block");
	return -1;
}
BlockNo=BF_GetBlockCounter(FileNo)-1;
memcpy(block+10*sizeof(Record),Heap,sizeof(char)*4);
memcpy(block+10*sizeof(Record)+sizeof(char)*4,&Pointer,sizeof(int));

if (BF_WriteBlock(FileNo,BlockNo) < 0)
{
	BF_PrintError("Error writing block back");
	return -1;
}
if (BF_CloseFile(FileNo))
{
	BF_PrintError("Error Closing File");
	return -1;
}
}

int HP_OpenFile(char*fileName)
{
int FileNo;
char HeapCheck[4];
void*block;



FileNo=BF_OpenFile(fileName);
if (FileNo<0)
{
	BF_PrintError("Error Opening File");
	return -1;
}
if (BF_ReadBlock(FileNo, 0, &block) < 0) 
{
	BF_PrintError("Error reading block");
	return -1;
}	
memcpy(HeapCheck,block+sizeof(Record)*10,sizeof(char[4]));
if(strcmp(HeapCheck,"Heap")!=0)
{
    if (BF_CloseFile(FileNo))
    {
	BF_PrintError("Error Closing File");
	return -1;
    }
    return -1;
}
else	return FileNo;

}


int HP_CloseFile(int fileDesc)
{
if (BF_CloseFile(fileDesc))
{
	BF_PrintError("Error Closing File");
	return -1;
}
else return 0;
}

int HP_InsertEntry(int fileDesc,Record record)
{
int FileNo,BlockNo,BlockCheck,Pointer,EntriesNo,flag;
void*block;

if (BF_ReadBlock(fileDesc, 0, &block) < 0) /*Diavazw to prwto block*/
{
	BF_PrintError("Error reading block");
	return -1;
}
memcpy(&Pointer,block+10*sizeof(Record)+sizeof(char)*4,sizeof(int));

if (Pointer==-1)	/*An yparxei mono to prwto block*/
{
	if (BF_AllocateBlock(fileDesc)<0)    /*desmevw kainourio*/
	{
		BF_PrintError("Error Allocating First Block");
		return -1;
	}
	Pointer=1;
	memcpy(block+10*sizeof(Record)+sizeof(char)*4,&Pointer,sizeof(int)); /*To prwto deixnei twra sto deftero*/
	BlockNo=0;
	if (BF_WriteBlock(fileDesc,BlockNo) < 0)
	{
		BF_PrintError("Error writing block back");
		return -1;
	}
	BlockNo++;	/*Paw sto epomeno block*/
	if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
	{
		BF_PrintError("Error reading block");
		return -1;
	}
	Pointer=-1;
	memcpy(block+10*sizeof(Record)+sizeof(int),&Pointer,sizeof(int)); /*Den yparxei epomeno ara to Pointer einai -1*/

	if (BF_WriteBlock(fileDesc,BlockNo) < 0)
	{
		BF_PrintError("Error writing block back");
		return -1;
	}
}
else
{	
	BlockNo=1;	/*Arxika eimai sto deftero Block*/
	flag=0;		/*H flag deixnei pote eimai etoimos na grapsw se block*/
	while(!flag)
	{	
		if (BF_ReadBlock(fileDesc, BlockNo, &block) < 0) /*Diavazw block*/
		{
			BF_PrintError("Error reading block");
			return -1;
		}
		memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int)); /*To prwto stoixeio tou xwrou pou perisevei einai o arithmos ton entries*/
		if(EntriesNo==10) 	/*Dhladh an einai gemato*/
		{
			memcpy(&Pointer,block+10*sizeof(Record)+sizeof(int),sizeof(int));
			if(Pointer==-1)	         /*An den yparxei allo block desmevmeno*/
			{	
				if (BF_AllocateBlock(fileDesc)<0)    /*desmevw kainourio*/
				{
					BF_PrintError("Error Allocating First Block");
					return -1;
				}		
				Pointer=BlockNo+1;	/*To trexon block deixnei twra sto kainourio*/
				memcpy(block+10*sizeof(Record)+sizeof(int),&Pointer,sizeof(int)); 
				if (BF_WriteBlock(fileDesc,BlockNo) < 0)
				{
					BF_PrintError("Error writing block back");
					return -1;
				}
				BlockNo++;			/*Paw sto kainourio block*/
				if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
				{
					BF_PrintError("Error reading block");
					return -1;
				}
				Pointer=-1;
				memcpy(block+10*sizeof(Record)+sizeof(int),&Pointer,sizeof(int)); /*Den yparxei epomeno ara to Pointer einai -1*/

				if (BF_WriteBlock(fileDesc,BlockNo) < 0)
				{
					BF_PrintError("Error writing block back");
					return -1;
				}
				flag=1; 		/*Mporw na grapsw sto Block me BlockNo*/
			}
			else	BlockNo++;
		}
		else	flag=1;	/*An den einai gemato mporw na grapsw se afto*/
	}
}
/*Pleon Exw vrei to swsto BlockNo*/
if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
{
	BF_PrintError("Error reading block");
	return -1;
}
memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));
memcpy(block+sizeof(Record)*EntriesNo,&record,sizeof(Record));	/*Grafw sto block to record*/
EntriesNo++;									/*Afksanw ton arithmo ton eisaxthenton entries kata 1*/ 
memcpy(block+10*sizeof(Record),&EntriesNo,sizeof(int));
if (BF_WriteBlock(fileDesc,BlockNo) < 0)						/*Ta pernaw sto block*/
{
	BF_PrintError("Error writing block back");
	return -1;
}
return 0;
}
		


void HP_GetAllEntries(int fileDesc,char*fieldName,void*value)
{
int i,EntriesNo,BlockNo,flag;
Record re;
void*block;


flag=0;
BlockNo=1;
while(flag==0)
{
	if(BlockNo==-1)	break;
	if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
	{
		BF_PrintError("Error reading block");
	}
	memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));   /*kai kataxwro to plhthos ton eggrafwn tou sto EntriesNo*/
	if(EntriesNo==0) break;   				  /*An to block einai adeio kai ta ypoloipa tha einai adeia ara teliwsa*/
	if((int*)value==NULL)					/*An to pedio Value einai NULL*/
	{
		i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
   			strcpy( re.surname, "" );
    			strcpy( re.city, "");   				  	  
           		memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
			memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record), sizeof(char[15]));
			memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
			memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
			printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			i++;
		}
	memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));
	continue;
	}	
      
	if( (strcmp( fieldName, "id" )) == 0 )			  /*An anazhtw to record me vash to id*/
        {
		i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
   			strcpy( re.surname, "" );
    			strcpy( re.city, "");   				  	  
           		memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
			if(re.id==(int)value)
			{

				memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record), sizeof(char[15]));
				memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
				memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
				printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			}
			i++;
		}
	}
	else if  (strcmp( fieldName, "name" ) == 0 )
     	{
           	i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
       			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
   			strcpy( re.surname, "" );
    			strcpy( re.city, "");  
           		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
			if( strcmp(re.name,(char*)value)== 0 )		  /*An einai afto pou anazhtw*/
			{
				memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
				memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
				memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
				printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			}
			i++;
		}
	}

	else if( strcmp( fieldName, "surname" ) == 0 )
      {
           	i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
       			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
  			strcpy( re.surname, "" );
    			strcpy( re.city, "");  
           		memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
           		if( strcmp(re.surname,(char*)value)== 0 )
			{
         		     	memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
                		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
                		memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
				printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			}
		i++;
		}
	}
	else if( strcmp( fieldName, "city")==0)
        {
		i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
       			re.id = 0;						/*Arxikopoiw to re*/
    			strcpy( re.name, "" );
   			strcpy( re.surname, "" );
    			strcpy( re.city, "");  
           		memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
           		if( strcmp(re.city,(char*)value)== 0 )
			{
                		memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
                		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
                		memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));;
				printf("(%d, %s, %s, %s) \n", re.id, re.name, re.surname, re.city);
			}
			i++; 
		}							
	}
	if(i==9)	flag=1;						/*An den einai gemato to arxeio block afto den yparxoun alles eggrafes*/
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	/*An den einai gemato paw sto epomeno*/
}
}		
		
		

int HP_DeleteEntry(int fileDesc,char*fieldName,void*value)
{
int DeleteEntry(int fileDesc,int BlockNo,int i);
int i,j,EntriesNo,BlockNo,flag,TempEntNo,LastBlock,TempFlag;
Record re;
void*block;


flag=0;
BlockNo=1;
while(flag==0)
{
	if(BlockNo==-1)	break;
	if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
	{
		BF_PrintError("Error reading block");
		return -1;
	}
	memcpy(&EntriesNo,block+10*sizeof(Record),sizeof(int));   /*kai kataxwro to plhthos ton eggrafwn tou sto EntriesNo*/
	if(EntriesNo==0) break;   				  /*An to block einai adeio kai ta ypoloipa tha einai adeia ara teliwsa*/
      
	if( (strcmp( fieldName, "id" )) == 0 )			  /*An anazhtw to record me vash to id*/
        {
		i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
			re.id = 0;						/*Arxikopoiw to re.id*/   				  	  
           		memcpy(&(re.id),block+i*sizeof(Record),sizeof(int));
			if(re.id==(int)value)
			{	
				DeleteEntry(fileDesc,BlockNo,i);
			}

			i++;
			
		}
	}
	else if  (strcmp( fieldName, "name" ) == 0 )
     	{
           	i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
    			strcpy( re.name, "" );				/*Arxikopoiw to name*/  
           		memcpy(&(re.name),block+sizeof(int)+i*sizeof(Record),sizeof(char[15]));
			if( strcmp(re.name,(char*)value)== 0 )		  /*An einai afto pou anazhtw*/
			{
				DeleteEntry(fileDesc,BlockNo,i);
			}
			i++;
		}
	}

	else if( strcmp( fieldName, "surname" ) == 0 )
      {
           	i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
  			strcpy( re.surname, "" );
           		memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+i*sizeof(Record),sizeof(char[20]));
           		if( strcmp(re.surname,(char*)value)== 0 )
			{
         		     	DeleteEntry(fileDesc,BlockNo,i);
			}
		i++;
		}
	}
	else if( strcmp( fieldName, "city")==0)
        {
		i=0;
		while(i<EntriesNo)   					  /*Mexri na elegxksw kai to teleftaio stoixeio tou block*/
		{
    			strcpy( re.city, "");  
           		memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+i*sizeof(Record),sizeof(char[10]));
           		if( strcmp(re.city,(char*)value)== 0 )
			{
                		DeleteEntry(fileDesc,BlockNo,i);
			}
			i++; 
		}							
	}
	if(i==9)	flag=1;						/*An den einai gemato to arxeio block afto den yparxoun alles eggrafes*/
	else memcpy(&BlockNo,block+10*sizeof(Record)+sizeof(int),sizeof(int));	/*An den einai gemato paw sto epomeno*/
}
return 1;
}
int DeleteEntry(int fileDesc,int BlockNo,int i)
{
int TempEntNo,LastBlock,TempFlag,j;
void*block;
Record re;


TempEntNo=0;		/*Psaxnw na vrw to teleftaio Block*/
LastBlock=1;
TempFlag=0;
j=0;			/*Gia na kataxwro to proteleftaio block*/
while(TempFlag==0)
{
	if (BF_ReadBlock(fileDesc,LastBlock, &block) < 0) 
	{
		BF_PrintError("Error reading block");
		return -1;
	}
	memcpy(&LastBlock,block+10*sizeof(Record)+sizeof(int),sizeof(int));
	if(LastBlock==-1)	TempFlag=1;
	else 		j++;		/*Ypopsifio gia proteleftaio*/
}				/*Exw vrei to teleftaio Block*/
LastBlock=j+1;
memcpy(&TempEntNo,block+10*sizeof(Record),sizeof(int));
TempEntNo--;
memcpy(&(re.id),block+TempEntNo*sizeof(Record),sizeof(int));	/*Pairnw thn teleftaia egrafh tou teleftaiou block*/
memcpy(&(re.name),block+sizeof(int)+TempEntNo*sizeof(Record), sizeof(char[15]));
memcpy(&(re.surname),block+sizeof(int)+sizeof(char[15])+TempEntNo*sizeof(Record),sizeof(char[20]));
memcpy(&(re.city),block+sizeof(int)+sizeof(char[35])+TempEntNo*sizeof(Record),sizeof(char[10]));
if(TempEntNo==0)					/*An htan to teleftaio stoixeio tou block*/
{
	if (BF_ReadBlock(fileDesc,j, &block) < 0) 	/*Bgazw ton deikth tou proteleftaiou pros afto*/
	{
		BF_PrintError("Error reading block");
		return -1;
	}
	TempEntNo=-1;
	memcpy(block+10*sizeof(Record)+sizeof(int),&TempEntNo,sizeof(int));
	if (BF_WriteBlock(fileDesc,j) < 0)		
	{
		BF_PrintError("Error writing block back");
		return -1;
	}
}
else							/*An den htan h teleftaia eggrafh*/
{
memcpy(block+10*sizeof(Record),&TempEntNo,sizeof(int));	/*Meiwnw to plhthos twn eggrafwn tou teleftaiou kata 1*/
if (BF_WriteBlock(fileDesc,BlockNo) < 0)		
{
	BF_PrintError("Error writing block back");
	return -1;
}
}
if (BF_ReadBlock(fileDesc,BlockNo, &block) < 0) 
{
	BF_PrintError("Error reading block");
	return -1;
}
memcpy(block+i*sizeof(Record),&re,sizeof(Record));
if (BF_WriteBlock(fileDesc,BlockNo) < 0)		
{
	BF_PrintError("Error writing block back");
	return -1;
}
return 0;
}


