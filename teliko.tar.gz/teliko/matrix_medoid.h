#ifndef MATRIX_MEDOID_H
#define MATRIX_MEDOID_H

#include <stdio.h>
#include <stdlib.h>
//#include <math.h>
#include <string.h>
#include "records.h"
#include "records_medoid.h"




void matrix2(char*,int ,int ,char *,int,int,int,int*);///i vasiki mas sunartis

void create_query_matrix(centroids **centroids_array,int **pinakas,int aktina,int count,int clusters);
void assign_LSH_matrix(int k,int L,int **tuxaioi,int count,int **pinakas,char *output,data **data_array,int old_centroid_position,centroids **centroids_array,int clusters);


void update_Lloyds_matrix(centroids **centroids_array,data** data_array,int amount,int k,int L,int ** tuxaioi,char *output,int clusters,int **,int);
void update_clarance_matrix(centroids **centroids_array,data **data_array,int amount,int k,int L,char *output,int** tuxaioi,int clusters,int **pinakas,int fraction,int iterations,int);

#endif
