#ifndef STORE_DISTANCES_C
#define STORE_DISTANCES_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "pareheader.h"



cos_items_ptr allocate_space_items( int num ){					// allocate space for the given vectors in the DATAFILE	
	cos_items_ptr ptr;
	int elements , i;
	if(num>0) elements = num;
	else{
		printf("invalid number of items \n");
		return NULL;
	}
	ptr = malloc(sizeof (struct COS_items));
	ptr->item_array = malloc(sizeof(double) * elements );
	ptr->centroid = malloc(sizeof(int) * elements );
	ptr->temp_centroid = malloc(sizeof(int) * elements );
	ptr->distance_to_centroid = malloc(sizeof(double)*elements);
	for(i=0; i<elements; i++){
		ptr->item_array[i] = malloc(sizeof(double) * 5000 );		
		ptr->distance_to_centroid[i] = 100000000;
		ptr->centroid[i] = -1;
	}
	ptr->current_items = 0;
	ptr->current_dimension = 0;
	return ptr;
}


char* store_distances( cos_items_ptr items, int elements){
	int i,j,dim , val;
	FILE *fp;
	char *name = "Distance_Matrix.csv" ;
	fp = fopen( name , "w+");
	fprintf(fp , "%s" , "@metric_space matrix\n");
	fprintf(fp , "%s" , "@items ");
	for(i=0; i<elements; i++){
		if(i==elements-1) {
			fprintf(fp , "%s%d" , "item" , i+1 );
			break;
		}
		fprintf(fp , "%s%d%s" , "item" , i+1 , ",");
	}
	fprintf(fp , "%s" , "\n");
	double distance = 0.0;
	for(i=0; i<elements; i++){
		for(j=0; j<elements; j++){
			distance = 0.0;
			for(dim = 0; dim<items->total_dimensions; dim++){
				distance += pow( (items->item_array[i][dim] - items->item_array[j][dim])  , 2 ); 
			}
			distance = sqrt(distance);
			distance += 0.5;
			val = distance;
			fprintf(fp , "%d%s" , val , "	");
		}
		fprintf(fp , "%s" , "\n");
	}
	fclose(fp);
	return name;
}
void store_item_coords( double num , cos_items_ptr ptr ){
	ptr->item_array[ptr->current_items][ptr->current_dimension] = num;
	ptr->current_dimension ++ ;
}



cos_items_ptr store_vectors(char *path , char *query_file , char *output_file , int K ){
	cos_items_ptr items_ptr;
	double item_coords;
	int elements=-2 ;				// starting at -2 to ignore the 2 titles in the euclidean files
	char * line = NULL;
    size_t len = 0;
    ssize_t read;
	char *token;
    printf("%s\n",path);
    FILE* fp ;
    fp = fopen(path, "r");
    if( fp == NULL) {
		printf("error opening file , exiting ... \n");
	}
	while ((read = getline(&line, &len, fp)) != -1) {		// searched how many items are in file to dynamically allocate array of ''element'' size
		elements++;
	}
	printf("Items in file :%d\n",elements);					
	items_ptr = allocate_space_items( elements * 2) ;
	printf("allocating space for %d elements..\n" , elements);
	fclose(fp);
	fp = fopen(path, "r");
    if( fp == NULL) {
		printf("error opening file , exiting ... \n");
	}
	read = getline(&line, &len, fp);
	read = getline(&line, &len, fp);			
	 while ((read = getline(&line, &len, fp)) != -1) {
        token = strtok(line, "	");					
        while( token != NULL ) {
			token = strtok(NULL, "	");
			if(token!=NULL){
				item_coords = atof( token );				
				store_item_coords( item_coords , items_ptr );			// save item coords in our structure
			}
		}
		items_ptr->current_items ++; 
		items_ptr->total_dimensions = items_ptr->current_dimension; 
		items_ptr->current_dimension = 0;
    }
    return items_ptr;

}

int* menu(){
	char *answer;
	int *methods  , i;
	methods = malloc(sizeof(char)*3);
	answer = malloc(sizeof(char)*10);
	printf("select clustering algorithm \n\n");
	printf("Do you wish to run the CLARA algorithm ? y / n \n");
	scanf("%s", answer);
	if( !strcmp(answer , "y")){
		for(i=0; i<3; i++){
			methods[i] = 0;
		}
		return methods;
	}else if(!strcmp(answer , "n")){
		printf("select clustering methods \n");
		printf("Initialization\n");
		printf("	1. kmedoids++\n");
		printf("	2. park_jun \n");
		scanf("%s", answer);
		if( atoi(answer) == 1 ) methods[0] = 1;
		else if( atoi(answer) == 2) methods[0] = 2;
		printf("Assignment\n");
		printf("	1. PAM\n");
		printf("	2. LSH++\n");
		scanf("%s", answer);
		if( atoi(answer) == 1 ) methods[1] = 1;
		else if( atoi(answer) == 2) methods[1] = 2;
		printf("Update\n");
		printf("	1. loyds\n");
		printf("	2. CLARANS\n\n");
		scanf("%s", answer);
		if( atoi(answer) == 1 ) methods[2] = 1;
		else if( atoi(answer) == 2) methods[2] = 2;
	}
	return methods;
	
	
	
	
	}

#endif
