#ifndef RECORDS_MEDOID_H
#define RECORDS_MEDOID_H


typedef struct{
	int position;
	double value;
	int *distances;
	int sum_distances;
	int total;
}centroids;

typedef struct{
	double value;
	int position;
	int *distances;
}entries;

typedef struct{
	int distance_from_centroid;
	int position;
	int centroid_position;
	int distance_from_2nd_centroid;
	int second_centroid_position;
	int *distances;
	int has_been_centroid;
	int is_centroid;
	int which_centroid;
	centroids **centroids_for_data;
}data;


#endif
