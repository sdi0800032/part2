#ifndef EXHASH_C
#define EXHASH_C


#include "BF.h"
#include "exhash.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int total_depth;   /////////to megalutero depth sto opoio ftanoume
int total_buckets;	/////// telikos arithmos twn buckets
int first_depth;	/////// arxiko depth



int EH_CreateIndex(char *fileName, char *attrName, char attrType, int attrLength, int depth) {
	int FileNo,BlockNo,Pointer=-1;
	char EX_hash[10]="EX_hash";
	void*block;
	BF_Init();
	if (BF_CreateFile(fileName)<0){
		BF_PrintError("Error creating File");
		return -1;
	}
	FileNo=BF_OpenFile(fileName);
	printf(" file %d \n",FileNo); ////polutimo
	if (FileNo<0){
		BF_PrintError("Error Opening File");
		return -1;
	}

	if (BF_AllocateBlock(FileNo)<0) {  
		BF_PrintError("Error Allocating First Block");
		return -1;
	}
	if (BF_ReadBlock(FileNo, 0, &block) < 0) {
		BF_PrintError("Error reading block");
		return -1;
	}
///////apothikeuoume tis plirofories sto prwto block
 	long unsigned int position = 0;
	BlockNo=BF_GetBlockCounter(FileNo)-1;
	memcpy( block + position , EX_hash , 10*sizeof(char));
	position += 10*sizeof(char) ;
	memcpy( block + position , &attrType , sizeof(char));
	position+= sizeof(char);
	memcpy( block + position  , &attrLength , sizeof(int));
	position+= sizeof(int);
	memcpy( block + position  , attrName , attrLength*sizeof(char));
	position+= attrLength*sizeof(char);

	memcpy( block + position  , &depth , sizeof(int));
	position+= sizeof(int);
	if (BF_WriteBlock(FileNo,BlockNo) < 0){
		BF_PrintError("Error writing block back");
		return -1;
	}
	if (BF_CloseFile(FileNo)){
		BF_PrintError("Error Closing File");
		return -1;
	}
	   
}


EH_info* EH_OpenIndex(char *fileName) {
	int FileNo;
	char HashCheck[7];
	void*block;
	EH_info *header_info=malloc(sizeof(EH_info));;

 	long unsigned int position = 0;
	char filetype[10];
	header_info->fileDesc=BF_OpenFile(fileName);
	header_info->attrName=malloc(sizeof(char)*15);
	FileNo=header_info->fileDesc;
	printf(" file %d \n",FileNo);
	if (FileNo<0)
	{
		BF_PrintError("Error Opening File");
		return NULL;
	}
	if (BF_ReadBlock(FileNo, 0, &block) < 0) 
	{
		BF_PrintError("Error reading block");
		return NULL;
	}	
    memcpy( filetype , block+position, 10*sizeof(char));
    position += 10*sizeof(char);
	printf("type of file is : %s \n " , filetype);
	memcpy( &(header_info->attrType) , block+position ,sizeof(char));
	position += sizeof(char);
	memcpy( &(header_info->attrLength) , block+position , sizeof(int));
	position += sizeof(int);
	memcpy( header_info->attrName , block+position , header_info->attrLength*sizeof(char));
	position += header_info->attrLength*sizeof(char);

	memcpy( &(header_info->depth) , block+position , sizeof(int));
	position += sizeof(int);
	total_depth=header_info->depth;
	first_depth=header_info->depth;

	//printf("type %c Name %s length %d depth %d \n",header_info->attrType,header_info->attrName ,header_info->attrLength,header_info->depth);
	int amount=pow(2,header_info->depth);
	int i=0;
	int block_size=BLOCK_SIZE;
	int hash_blocks_size=amount*sizeof(int);
	int blocks_needed=0;

//////kanoume allocate kapoia blocks gia na apothikeusoume to hash table
	if(hash_blocks_size < block_size) blocks_needed = 1;
	else{
		blocks_needed = 1;
		int current_size = block_size;
		while( hash_blocks_size > current_size){
			current_size += block_size;
			blocks_needed ++;
		}
	}
	blocks_needed*=8;
	//printf("hash blocks %d amount %d size %d \n",blocks_needed,amount,hash_blocks_size);
	int entries=0;
	for(i=0; i<blocks_needed*2+1; i++){
		if( BF_AllocateBlock(header_info->fileDesc)<0) BF_PrintError("error while allocating block");
	}
///////allocate blocks gia ta apotelesmata pou 8a paroume analoga me to arxiko depth
	int ptr=blocks_needed*2+1;
	for(i=0;i<amount;i++){
		if( BF_AllocateBlock(header_info->fileDesc)<0) BF_PrintError("error while allocating block");
		if( BF_ReadBlock(header_info->fileDesc, i+ptr  , &block)< 0 ) BF_PrintError("error while reading block");
		memcpy(block + 512 - 2*sizeof(int) , &entries , sizeof(int));
		memcpy(block + 512 - sizeof(int) , &(header_info->depth) , sizeof(int));
		if( BF_WriteBlock(header_info->fileDesc , i+ptr) < 0 ){ BF_PrintError("error while writing block");  /*return -1 */ };
	}
	total_buckets=1+blocks_needed*2+amount;
	if(strcmp(filetype,"EX_hash")!=0)
	{
		if (BF_CloseFile(FileNo))
		{
		BF_PrintError("Error Closing File");
		return NULL;
		}
		return NULL;
	}
	else	return header_info;
} 



int EH_CloseIndex(EH_info* header_info) {
if (BF_CloseFile(header_info->fileDesc))
{
	BF_PrintError("Error Closing File");
	return -1;
}
else return 0;
  
}

int EH_InsertEntry(EH_info* header_info, Record record) {
	int amount=pow(2,header_info->depth);
	int i=0;
	int block_size=BLOCK_SIZE;
	int hash_blocks_size=amount*sizeof(int);
	int blocks_needed=0;
	int result;
	void *block;
	int bucket;
	int fd=header_info->fileDesc;
	//printf("++++++++++%d %s %s %s \n" , record.id , record.name , record.surname , record.city  );
	if(hash_blocks_size < block_size) blocks_needed = 1;
	else{
		blocks_needed = 1;
		int current_size = block_size;
		while( hash_blocks_size > current_size){
			current_size += block_size;
			blocks_needed ++;
		}
	}
	blocks_needed*=8;
//////kaloume ti hash function kai pername to apotelesma apo ti find_bucket gia na paroume to bucket pou psaxnoume
///// analoga me to attrName 
	if(strcmp(header_info->attrName,"id")==0){
		result = hash_function( NULL , record.id , header_info );
		bucket=find_bucket(result,header_info->depth);
	}
	if(strcmp(header_info->attrName,"name")==0){
		result = hash_function( record.name , 0 , header_info );
		bucket=find_bucket(result,header_info->depth);
	}
	if(strcmp(header_info->attrName,"surmname")==0){
		result = hash_function( record.surname , 0 , header_info );
		bucket=find_bucket(result,header_info->depth);
	}
	if(strcmp(header_info->attrName,"city")==0){
		result = hash_function( record.city , 0 , header_info );
		bucket=find_bucket(result,header_info->depth);
	}
	//printf("bucket %d \n",bucket);
	int place=bucket*sizeof(int)*2;
/////vriskoume to block sto opoio antistoixei to bucket mesa apo to block me to hash table
	for(i=0;i<blocks_needed*2+1;i++){
		if(place<(512*i)){
			int blockno=i+1;
			int where=0;
			int position=place + sizeof(int);
			int bucket_position=bucket+1+blocks_needed*2;
			if( BF_ReadBlock(fd, blockno  , &block)< 0 ) BF_PrintError("1error while reading block");
			memcpy( &where , block+position , sizeof(int));
//////////an den uparxei to antistoixo block to vazoume emeis sto hash table
			if(where==0){
				memcpy( block+position-sizeof(int)  , &bucket, sizeof(int));
				memcpy( block+position  , &(bucket_position), sizeof(int));
				if( BF_WriteBlock(fd , blockno ) < 0 ){ BF_PrintError("error while writing block");  /*return -1 */ };
				where=bucket_position;
			}
/////////pigainw sto block pou vrika kai vaze to entry stin antistoixi thesi
			if( BF_ReadBlock(fd,where, &block)< 0 ) BF_PrintError("1error while reading block");
			int entries=0,local_depth=0;
			memcpy(&entries ,block + 512 - 2*sizeof(int) ,  sizeof(int));
			memcpy(&local_depth ,block + 512 - sizeof(int) ,  sizeof(int));
			if(entries<7){
				int which_record=entries*sizeof(Record);
				int thesi=0;
				memcpy(block+which_record+thesi,&(record.id),sizeof(int));
				thesi+=sizeof(int);
				memcpy(block+which_record+thesi,(record.name),sizeof(char)*15);
				thesi+=sizeof(char)*15;
				memcpy(block+which_record+thesi,(record.surname),sizeof(char)*20);
				thesi+=sizeof(char)*20;
				memcpy(block+which_record+thesi,(record.city),sizeof(char)*25);
				thesi+=sizeof(char)*25;
				entries++;
				memcpy(block + 512 - 2*sizeof(int) , &entries , sizeof(int));
				if( BF_WriteBlock(fd , where ) < 0 ){ BF_PrintError("error while writing block");  /*return -1 */ };
				return 0;
			}
///////an to bucket einai gematoalla to depth den einai to megisto tou bucket xanakaloume ti sunartisi me megalutero depth
			else if(entries==7 && local_depth>header_info->depth){
				EH_info *ehptr=malloc(sizeof(EH_info));
				ehptr->attrName=malloc(sizeof(char)*15);
				ehptr->fileDesc=header_info->fileDesc;
				strcpy(ehptr->attrName,header_info->attrName);
				ehptr->attrType=header_info->attrType;
				ehptr->attrLength=header_info->attrLength;
				ehptr->depth=header_info->depth;
				ehptr->depth++;
				//printf("----------%d %s %s %s \n" , record.id , record.name , record.surname , record.city  );
				EH_InsertEntry(ehptr, record);
				free(ehptr->attrName);
				free(ehptr);
				return 0;

			}
/////////// an einai gemato kai to depth einai to megisto
			else if(entries==7 && local_depth==header_info->depth){
				
				int new_bucket_position=total_buckets+1;
				int new_depth=local_depth+1;
				int new_bucket=pow(2,new_depth-1)+bucket;
				int new_place=new_bucket*sizeof(int)*2;
				int new_where=0;
				if(local_depth==total_depth){			
					total_depth++;
				}
////// vriskoume se poio block einai apothikeumeno to se poio block prepei na paei to entry
				for(i=0;i<blocks_needed*2+1;i++){
					if(new_place<(512*i)){
						int new_blockno=i+1;

						int new_position=new_place + sizeof(int);
						if( BF_ReadBlock(fd, new_blockno  , &block)< 0 ) BF_PrintError("1error while reading block");
/////ftiaxnoume to kainourgio block kai apothikeuoume sto hash table ti thesi tou
///// kai se poia timi tou hashing antistoixei
						if( BF_AllocateBlock(fd)<0) BF_PrintError("error while allocating block");
						total_buckets++;
						memcpy( block+new_position-sizeof(int)  , &new_bucket, sizeof(int));
						memcpy( block+new_position  , &(new_bucket_position), sizeof(int));
						if( BF_WriteBlock(fd , new_blockno ) < 0 ){ BF_PrintError("error while writing block");  /*return -1 */ };

						new_where=new_bucket_position;
					
						break;
					}
				}
				Record temp_record;
				int j=0,upto=7;
///////kanoume rehash ola ta entries tou paliou bucket
				if( BF_ReadBlock(fd,where, &block)< 0 ) BF_PrintError("1error while reading block");
				while(j<upto){
					int re_result;
					int re_bucket;
					int which_record=(j)*sizeof(Record);
					int thesi=0;
					memcpy(&(temp_record.id),block+which_record+thesi,sizeof(int));
					thesi+=sizeof(int);
					memcpy(temp_record.name,block+which_record+thesi,sizeof(char)*15);
					thesi+=sizeof(char)*15;
					memcpy(temp_record.surname,block+which_record+thesi,sizeof(char)*20);
					thesi+=sizeof(char)*20;
					memcpy(temp_record.city,block+which_record+thesi,sizeof(char)*25);
					thesi+=sizeof(char)*25;
					if(strcmp(header_info->attrName,"id")==0){
						printf(" ID %d pou %d which_record+thesi \n",temp_record.id,which_record+thesi);
						re_result = hash_function( NULL , temp_record.id , header_info );
						re_bucket=find_bucket(re_result,new_depth);
					}
					if(strcmp(header_info->attrName,"name")==0){
						re_result = hash_function( temp_record.name , 0 , header_info );
						re_bucket=find_bucket(re_result,new_depth);
					}
					if(strcmp(header_info->attrName,"surmname")==0){
						re_result = hash_function( temp_record.surname , 0 , header_info );
						re_bucket=find_bucket(re_result,new_depth);
					}
					if(strcmp(header_info->attrName,"city")==0){
						re_result = hash_function( temp_record.city , 0 , header_info );
						re_bucket=find_bucket(re_result,new_depth);
					}
///////an prepei na mpei sto kainourgio bucket to metaferoume 
////// kai vazoume sti thesi tou sto palio bucket to teleutaio entry tou bucket ekeinou
					if(re_bucket==new_bucket){
						int new_bucket_entries=0;
						if( BF_ReadBlock(fd,new_where, &block)< 0 ) BF_PrintError("1error while reading block");
						int local_depth=0;
						memcpy(&new_bucket_entries ,block + 512 - 2*sizeof(int) ,  sizeof(int));
						memcpy(&local_depth ,block + 512 - sizeof(int) ,  sizeof(int));
						
						int thes=0;
						memcpy(block+thes,&(temp_record.id),sizeof(int));
						thes+=sizeof(int);
						memcpy(block+thes,(temp_record.name),sizeof(char)*15);
						thes+=sizeof(char)*15;
						memcpy(block+thes,(temp_record.surname),sizeof(char)*20);
						thes+=sizeof(char)*20;
						memcpy(block+thes,(temp_record.city),sizeof(char)*25);
						thes+=sizeof(char)*25;
						new_bucket_entries++;
						memcpy(block + 512 - 2*sizeof(int) , &new_bucket_entries , sizeof(int));
						memcpy(block + 512 - sizeof(int) , &total_depth , sizeof(int));
						if( BF_WriteBlock(fd , new_where ) < 0 ){ BF_PrintError("error while writing block");  /*return -1 */ };

						if( BF_ReadBlock(fd,where , &block)< 0 ) BF_PrintError("1error while reading block");
						
						Record last_record;
						int last=0;
						memcpy(&last ,block + 512 - 2*sizeof(int) ,  sizeof(int));
						//printf("mesa where %d /n",where);
						int pou=0;
						int kati=0;
						char edw[25]="0000000000000000000000000";
						memcpy(&(last_record.id),block+(last-2)*sizeof(Record)+pou,sizeof(int));
						memcpy(block+(last-2)*sizeof(Record)+pou,&kati,sizeof(int));						
						memcpy(block+j*sizeof(Record)+pou,&(last_record.id),sizeof(int));						
						pou+=sizeof(int);
						memcpy(last_record.name,block+(last-2)*sizeof(Record)+pou,sizeof(char)*15);
						memcpy(block+(last-2)*sizeof(Record)+pou,edw,sizeof(char)*15);						
						memcpy(block+j*sizeof(Record)+pou,(last_record.name),sizeof(char)*15);						
						pou+=sizeof(char)*15;
						memcpy(last_record.surname,block+(last-2)*sizeof(Record)+pou,sizeof(char)*20);
						memcpy(block+(last-2)*sizeof(Record)+pou,edw,sizeof(char)*20);						
						memcpy(block+j*sizeof(Record)+pou,&(last_record.surname),sizeof(char)*20);						
						pou+=sizeof(char)*20;
						memcpy(last_record.city,block+(last-2)*sizeof(Record)+pou,sizeof(char)*25);
						memcpy(block+(last-2)*sizeof(Record)+pou,edw,sizeof(char)*25);						
						memcpy(block+j*sizeof(Record)+pou,&(last_record.city),sizeof(char)*25);						
						pou+=sizeof(char)*25;
						upto--;
						last--;
						int new=header_info->depth+1;
						memcpy(block + 512 - 2*sizeof(int) ,&last,  sizeof(int));
						memcpy(block + 512 - sizeof(int) ,&new,  sizeof(int));
						if( BF_WriteBlock(fd , where ) < 0 ){ BF_PrintError("error while writing block");  /*return -1 */ };
					}
					else{
						j++;

					}
					
					
				
				}
/////////xanakaloume ti sunartisi me to entry pou den mpike pote giati allaxan ta bucekts
				EH_info *ehptr=malloc(sizeof(EH_info));
				ehptr->attrName=malloc(sizeof(char)*15);
				ehptr->fileDesc=header_info->fileDesc;
				strcpy(ehptr->attrName,header_info->attrName);
				ehptr->attrType=header_info->attrType;
				ehptr->attrLength=header_info->attrLength;
				ehptr->depth=header_info->depth;
				ehptr->depth++;
				EH_InsertEntry(ehptr, record);
				free(ehptr->attrName);
				free(ehptr);
				return 0;



			}

			//if( BF_WriteBlock(fd , where ) < 0 ){ BF_PrintError("error while writing block");  /*return -1 */ };

			
			break;
		}
	}
}

int many_buckets=1;

int EH_GetAllEntries(EH_info *header_info, void *value) {
    Record record;
    char *key_string , key_chars[25];
    void *block;
    printf("\n\n");
	int result,bucket;
	int amount=pow(2,header_info->depth);
	int key_id;
	int search_position,i,flag=0;
	int block_size=BLOCK_SIZE;
	int hash_blocks_size=amount*sizeof(int);
	int blocks_needed=0;

	int many_entries=0;
	int o=0;
	int kati,allo;
////////// vriskoume to bucket pou 8a itan to entry pou psaxnoume me to arxiko depth
/////// an den einai se auto auxanoume to depth kai xanakaloume ti sunartisi
	if(header_info->depth<=total_depth){
	if(hash_blocks_size < block_size) blocks_needed = 1;
	else{
		blocks_needed = 1;
		int current_size = block_size;
		while( hash_blocks_size > current_size){
			current_size += block_size;
			blocks_needed ++;
		}
	}
	blocks_needed*=8;
    if(!strcmp( header_info->attrName , "id")){
		search_position = 0;
		key_string = value ;
		flag=1;
		}
	else if(!strcmp( header_info->attrName , "name")){
		search_position = sizeof(int);
		key_string = value;
	}
	else if(!strcmp( header_info->attrName , "surname" )){
		search_position = sizeof(int) + sizeof(char) * 15 ;
		key_string = value;
	}
	else if(!strcmp( header_info->attrName , "city")){
		search_position = sizeof(int) + sizeof(char) * 15 + sizeof(char) * 20 ; 
		key_string = value;
	}
	if(flag) { key_id = atoi(key_string);  printf("%d\n" , key_id); }
    if(flag){
	
		result = hash_function( NULL , key_id , header_info);
		bucket=find_bucket(result,header_info->depth);
	}
    else {
		result = hash_function( key_string , 0 , header_info);
		bucket=find_bucket(result,header_info->depth);
	}
	int place=bucket*sizeof(int)*2;

	int fd=header_info->fileDesc;
	int local_depth;
	int j=0;
	for(i=0;i<blocks_needed*2+1;i++){
		if(place<(512*i)){
			int blockno=i+1;
			int position=place + sizeof(int);
			int entries=0;
			int where=0;
			if( BF_ReadBlock(fd, blockno  , &block)< 0 ) BF_PrintError("1error while reading block");
			memcpy( &where , block+position , sizeof(int));
			if(where!=0){
				if( BF_ReadBlock(fd,where, &block)< 0 ) BF_PrintError("1error while reading block");
				memcpy( &local_depth , block+512-sizeof(int) , sizeof(int));
				memcpy( &entries , block+512-2*sizeof(int) , sizeof(int));
				if(local_depth==header_info->depth){
					int id=0;
					char name[15],surname[20],city[25];
					for(j=0;j<entries;j++){
						if(strcmp(header_info->attrName,"id")==0){
						
							memcpy( &id , block+sizeof(Record)*j , sizeof(int));
							if(id==key_id){
								memcpy(name, block+ sizeof(Record)*j+4,sizeof(char)*15);
								memcpy(surname, block+ sizeof(Record)*j+4+15,sizeof(char)*20);
								memcpy(city, block+ sizeof(Record)*j+4+15+20,sizeof(char)*25);
								many_entries++;
							}
						}
						if(strcmp(header_info->attrName,"name")==0){
							memcpy(name, block+ sizeof(Record)*j+4,sizeof(char)*15);
							if(strcmp(name,key_string)==0){
								memcpy( &id , block+sizeof(Record)*j , sizeof(int));
								memcpy(surname, block+ sizeof(Record)*j+4+15,sizeof(char)*20);
								memcpy(city, block+ sizeof(Record)*j+4+15+20,sizeof(char)*25);
								printf(" ID %d name %s surnmae %s city %s \n",id,name,surname,city);
								many_entries++;
							}
						}
						if(strcmp(header_info->attrName,"surmname")==0){

							memcpy(surname, block+ sizeof(Record)*j+4+15,sizeof(char)*20);
							if(strcmp(name,key_string)==0){
								memcpy( &id , block+sizeof(Record)*j , sizeof(int));
								memcpy(name, block+ sizeof(Record)*j+4,sizeof(char)*15);
								memcpy(city, block+ sizeof(Record)*j+4+15+20,sizeof(char)*25);
								printf(" ID %d name %s surnmae %s city %s \n",id,name,surname,city);
								many_entries++;					
							}
						}
						if(strcmp(header_info->attrName,"city")==0){
							memcpy(city, block+ sizeof(Record)*j+4+15+20,sizeof(char)*25);

							if(strcmp(city,key_string)==0){
								memcpy( &id , block+sizeof(Record)*j , sizeof(int));
								memcpy(name, block+ sizeof(Record)*j+4,sizeof(char)*15);
								memcpy(surname, block+ sizeof(Record)*j+4+15,sizeof(char)*20);
								many_entries++;
								printf(" ID %d name %s surnmae %s city %s \n",id,name,surname,city);
							}
						}

					}	
				printf("Found %d entries \n",many_entries);
				printf("searched %d buckets \n",many_buckets);
				return many_entries;
				break;
				}
				else{
					many_buckets++;
					EH_info *ehptr=malloc(sizeof(EH_info));
					ehptr->attrName=malloc(sizeof(char)*15);
					ehptr->fileDesc=header_info->fileDesc;
					strcpy(ehptr->attrName,header_info->attrName);
					ehptr->attrType=header_info->attrType;
					ehptr->attrLength=header_info->attrLength;
					ehptr->depth=header_info->depth;
					ehptr->depth++;

					int pame= EH_GetAllEntries(ehptr,value);
					free(ehptr->attrName);
					free(ehptr);
					break;
				}

				break;
			}
		}
	}
	}
	return 0;
   
}

//////////diavazoume apo ola ta blocks ti thesi pou metraei ta entries tou
/////////kai vriskoume tis posotites pou zitountai
int HashStatistics(char* filename) {
	int amount=pow(2,first_depth);
	int i=0;
	int block_size=BLOCK_SIZE;
	int hash_blocks_size=amount*sizeof(int);
	int blocks_needed=0;
	int fd=BF_OpenFile(filename);
	int most=0;
	int least=7;
	int all=0;
	void *block;
    printf("\n\n");
	float average=0;
	int sum=0;
	if(hash_blocks_size < block_size) blocks_needed = 1;
	else{
		blocks_needed = 1;
		int current_size = block_size;
		while( hash_blocks_size > current_size){
			current_size += block_size;
			blocks_needed ++;
		}
	}
	blocks_needed*=8;
	int which;
	int entries=0;
	for(which=blocks_needed+1;which<total_buckets;which++){
		if( BF_ReadBlock(fd,which, &block)< 0 ) BF_PrintError("1error while reading block");
		memcpy(&entries,block+512-2*sizeof(int),sizeof(int));

		if(entries!=0){
		all+=entries;
		sum++;
		if(entries>most && entries!=0){most=entries; }
		if(entries<least && entries!=0){least=entries;}
		}

	}
	average=(float)all/(sum);
   printf("most %d least %d average %f \n",most,least,average);
	return 0;
}

unsigned long hash_function( char *field1 , int field2  , EH_info *ehptr){
	unsigned long result = 5381;
	int c;
	//printf("%s field 1 \n" , field1);
	if( field2 != 0 ){
		// we're given an integer to process
		int numBuckets=pow(2,ehptr->depth);
		result = field2 % (10000 );
	}else{
		// we're given a string to process
		// (from stackoverflow)
		while ( c = *field1++ ) {
			result = ((result << 5) + result) + c; 				/* hash * 33 + c */
		}
		int numBuckets=pow(2,ehptr->depth);
		result = result % (10000);
	}
	return result;
}


///////////metatrepei ena string apo duadika psifia se dekadiko arithmo

long bin2int(const char *final) 
{
	int i=0;
	int count=0;
	long apotel=0;
	int number=0;
	int temp=0,diairetis=10;
	number=atoi(final);
	while(final[i]!='\0'){
		if(i==0){
			count=1;
			temp=number%10;
			number=number/10;
			apotel+=temp*count;
			count*=2;
		}
		else{
			temp=number%10;
			number=number/10;
			apotel+=temp*count;
			count*=2;
		
		}		
		i++;
		//printf("mesa %d \n",apotel);
	}
	return apotel;

}


//////////// kanei reverse ena string

char *strrev(char *str)
{
      char *p1, *p2;

      if (! str || ! *str)
            return str;
      for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
      {
            *p1 ^= *p2;
            *p2 ^= *p1;
            *p1 ^= *p2;
      }
      return str;
}


///////////pairnei tin timi apo ti hash function ti metatrepei se duadiko string kai pairnei
//////// ta osa teleutaia psifia tou oso kai to depth
//////// i timi pou epistrefei einai to bucket sto opoio tha prepei na paei to entry
int find_bucket(int result,int depth){
	int i=0;
	char binary[10];  
	char final[depth+1];
    int index = 0; 
	int temp=result;
	long apotel=0;
	//printf("result %d \n",temp);
	while(temp!=0)  
    {  
        /* Finds decimal%2 and adds to the binary value */  
        binary[index] = (temp % 2) + '0';  

        temp /= 2;  
        index++;  
    }  
    binary[index] = '\0';  

	//printf("binary %s \n",binary);
	//strrev(binary);
	for(i=0;i<depth;i++){
		
		final[i]=binary[i];

	}
	final[i]='\0';
	strrev(final);
	//printf("final %s \n",final);
	apotel=bin2int(final);
	//printf("apotel %ld \n",apotel);
	return apotel;

}



#endif 
