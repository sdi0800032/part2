#ifndef HAMMING_MEDOID_H
#define HAMMING_MEDOID_H

#include <stdio.h>
#include <stdlib.h>
//#include <math.h>
#include <string.h>
#include "records.h"
#include "records_medoid.h"


void hamming2(char *path,int k,int L,char *output,int,int,int);


centroids** concentrate_init(int **distance_matrix_hamming,int *line_total,double *v,entries **entries_array,int amount,data **data_array,int);
centroids** plus_init(int **distance_matrix_hamming,data **data_array,int amount,int);



void pam_assign(data **data_array,centroids **centroids_array,int amount,int);
void assign_LSH(int k,int L,int **tuxaioi,int mikos,int amount,char **inputs,char *output,data **data_array,int old_centroid_position,centroids **centroids_array,int);



void update_clarance(centroids **centroids_array,data **data_array,int amount,int k,int L,char **inputs,char *output,int** tuxaioi,int mikos,int,int fraction,int iterations);

void update_Lloyds(centroids **centroids_array,data** data_array,int amount,int k,int L,int ** tuxaioi,char **inputs,char *output,int mikos,int);



void clara(int old_amount,centroids **centroids_array,data **data_array,int **distance_matrix_hamming,int);
void clara_update(data **data_array,centroids **centroids_array,int amount,int);

int find_silhouett(data **data_array,int amount);



int j_function(data **data_array,int amount);
void centroid_sort(int *distances,centroids ** centroids_array,int first,int last);
int find_cluster_medoid(centroids *centroid,data** data_array,int amount,int old_centroid);
void create_query_hamming(centroids **centroids_array,char **inputs,int aktina,int);
int find_distance2(char *sto_hashtable,char *apexw,int mikos,int amount);
void quicksort(entries **entries_array,int first,int last);
void init_data_array(int amount,data **data_array,entries **entries_array,int);
int search(int D[1000],int new,int amount,int posa);





#endif











