#ifndef MEDOIDS_C
#define MEDOIDS_C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "hash.h"
#include "records.h"
#include "records_medoid.h"
#include "matrix_medoid.h"
#include "hamming_medoid.h"
//#include <math.h>
#define LINESZ 1024

int main(int argc, char** argv){

	char path[256],output[256],config[256];
	int i=0;
	int k=0,L=0,clusters=0,fraction=0,iterations=0;
	char gramma[50],gramma2[50];
	for(i=0;i<argc;i++){
		if(strcmp(argv[i],"-d")==0){
				strcpy(path,argv[i+1]);
				printf("%s\n",path);
		}
		if(strcmp(argv[i],"-c")==0){
				strcpy(config,argv[i+1]);
				printf("%s\n",config);
		}
		if(strcmp(argv[i],"-o")==0){
				strcpy(output,argv[i+1]);
				printf("%s\n",output);
		}
	}
	i=0;
	FILE *conf=fopen(config,"r");
	char *line;
	size_t len = 0;
	ssize_t read;
	while ((read = getline(&line, &len, conf)) != -1) {
		sscanf(	line,"%s %s  ",gramma,gramma2);
		if(strcmp(gramma,"number_of_clusters:")==0){
			clusters=atoi(gramma2);
		}
		if(strcmp(gramma,"number_of_hash_functions:")==0){
			k=atoi(gramma2);
		}
		if(strcmp(gramma,"number_of_hash_tables:")==0){
			L=atoi(gramma2);
		}
		if(strcmp(gramma,"clarans_set_fraction:")==0){
			fraction=atoi(gramma2);
		}
		if(strcmp(gramma,"clarans_iterations:")==0){
			iterations=atoi(gramma2);
		}
	}
	if(L==0){
		L=5;
	}
	if(k==0){
		k=4;
	}
	if(fraction==0){
		fraction=-1;
	}
	if(iterations==0){
		iterations=2;
	}
	printf(" k : %d L : %d \n",k,L);
	fclose(conf);
 	FILE* stream = fopen(path, "r");


	fscanf(stream,"%s %s ",gramma,gramma2);
	printf("%s  \n", gramma2);

	if(strcmp(gramma2,"hamming")==0){
		hamming2(path,k,L,output,clusters,fraction,iterations);
	}
	if(strcmp(gramma2,"matrix")==0){
		matrix2(path,k,L,output,clusters,fraction,iterations);
	}
	if(strcmp(gramma2,"euclidean")==0){
//cosine_eucl(path, query, output, k  ,L  );
		//matrix(path,k,L,query,output);
	}
	fclose(stream);
	return 1;
}

#endif
