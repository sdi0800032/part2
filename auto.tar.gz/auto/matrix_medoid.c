#ifndef HAMMING_MEDOID_C
#define HAMMING_MEDOID_C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "hash.h"
#include "records.h"
#include "records_medoid.h"
#include "matrix_medoid.h"
#include "hamming_medoid.h"
//#include "lin.c"
#define LINESZ 1024

/*
int main(int argc, char** argv){

	char path[256],query[256],output[256];
	int i=0;
	int k=0,L=0;
	char gramma[50],gramma2[50];
	for(i=0;i<argc;i++){
		if(strcmp(argv[i],"-d")==0){
				strcpy(path,argv[i+1]);
				printf("%s\n",path);
		}
		if(strcmp(argv[i],"-q")==0){
				strcpy(query,argv[i+1]);
				printf("%s\n",query);
		}
		if(strcmp(argv[i],"-o")==0){
				strcpy(output,argv[i+1]);
				printf("%s\n",output);
		}
		if(strcmp(argv[i],"-k")==0){
			sscanf(argv[i+1], "%d", &k);
		}
		if(strcmp(argv[i],"-L")==0){
			sscanf(argv[i+1], "%d", &L);
		}
	}
	i=0;
	if(L==0){
		L=5;
	}
	if(k==0){
		k=4;
	}
	printf(" k : %d L : %d \n",k,L);
 	FILE* stream = fopen(path, "r");


	fscanf(stream,"%s %s ",gramma,gramma2);
	printf("%s  \n", gramma2);

	if(strcmp(gramma2,"hamming")==0){
		hamming2(path,k,L,query,output);
	}
	if(strcmp(gramma2,"matrix")==0){
		matrix2(path,k,L,query,output);
	}
	if(strcmp(gramma2,"euclidean")==0){
		cosine_eucl(path, query, output, k  ,L  );
		//matrix(path,k,L,query,output);
	}
	return 1;
}*/


void matrix2(char* path,int k,int L,char *output,int clusters,int fraction,int iteration){

 	FILE* stream = fopen(path, "r");
	int i=0,j=0;
	char buff[3000];
	char gramma[50],gramma2[50],item[3000],number[3000];
	fscanf(stream,"%s %s ",gramma,gramma2);
	printf("%s  \n", gramma2);
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
	int count=0;

    read = getline(&line, &len, stream);

    //printf("%s", line);
    read = getline(&line, &len, stream);
    //printf("Retrieved line of length %zu :\n", read);
 
	char *token = strtok(line," \n\t");  ////metrame to plithos apostasew kathe stoixeiou
	while( token != NULL) 
	{
		count++;
		int d = atoi(token);
		token = strtok(NULL," \n\t");
	}
	//printf("count %d\n",count);
	int **pinakas= malloc (sizeof (int*) * count); //////edw apothikeuontai ola ta dedomena apo to dataset
	for(i=0;i<count;i++){
		pinakas[i]=(int*)malloc(sizeof(int) * count);
	}
	i=0;
	rewind(stream);
	fscanf(stream,"%s %s ",gramma,gramma2);
    read = getline(&line, &len, stream);
	char **onomata= malloc (sizeof (char*) * count); ///////////ftiaxnoume ena pinaka me to onoma kathe entry gia na ektupwthei argotera

	for(i=0;i<count;i++){
		onomata[i]=(char*)malloc(sizeof(char) * 64);
		memset(onomata[i], 0, sizeof onomata[i]);
	}
	i=0;
	while(    read = getline(&line, &len, stream)!=0 && i<count){
       //printf("Retrieved line of length %zu :\n", read);
        //printf("%s", line);
		char noumero[6];
		strcat(onomata[i],"item");
		sprintf(noumero,"%d",i);
		strcat(onomata[i],noumero);
		//printf("onoma %s \n",onomata[i]);
		char *token = strtok(line," \n\t");  //should use delimiter
		while( token != NULL) {
			int d = atoi(token);
	   
			//printf("j=%d\n",j);
			pinakas[i][j]=d;
	   		token = strtok(NULL," \n\t");
			j++;
		}
		i++;
		j=0;


	}
	i=0;
	int **tuxaioi= malloc (sizeof (int*) *(2* k));	////edw apothikeuontai oi tuxaioi arithmoi pou paragontai gia kathe L
	for(i=0;i<(2*k);i++){
		tuxaioi[i]=(int*)malloc(sizeof(int) * L);
	}
	for(j=0;j<L;j++){		////////apothikeusi tuxaiwn arithmwn
	for(i=0;i<k;i++){
		int tuxaios1=rand()%(count);
		int tuxaios2=rand()%(count);
		while(tuxaios1==tuxaios2){
			tuxaios1=rand()%(count);
			tuxaios2=rand()%(count);

		}
		//printf("tuxaioi :%d %d\n",tuxaios1,tuxaios2);
		tuxaioi[j][2*i]=tuxaios1;
		tuxaioi[j][2*i+1]=tuxaios2;

	}
	}
	int o=0;
	initHashtable(1000,L);		////arxikopoiisi hashtable
	for(o=0;o<1000;o++){
		for(j=0;j<L;j++){

		int bucket=metric_hash(pinakas,tuxaioi,o,count,L,k,j);	//////kanoume to hashing gia na vroume to bucket pou tha mpei to entry
		//printf("o %d bucket : %d \n",o,bucket);
		matrix_ptr neo=malloc(sizeof(matrix_ptr));    ////ftiaxnoume to node tou hashtable
	    neo->matrix_distances= malloc(sizeof(int) * 1000);
		neo->matrix_distances=pinakas[o];
		neo->id=onomata[o];
		neo->position=o;
		bucketentry2( neo , bucket, o, j);	////vazoume to neo node sto hashtable
			
		}
	}
	//printf(" QUERY %s \n",query);
	//metric_Search(query,k,L,tuxaioi,count,pinakas,output); ////kaloume ti sunartisi pou analamvanei to query file















	
	//int line_total[1000];
	//double v[1000];
	int *line_total=malloc(sizeof(int)*count);
	int total_sum=0;
	double *v=malloc(sizeof(double)*count);	
	entries **entries_array=malloc(sizeof(entries*)*count);
	
	for(i=0;i<count;i++){
		entries_array[i]=malloc(sizeof(entries*));
		entries_array[i]->value=0;

	}
////// afou diavasame ola ta dedomena kaloume ti sunartisi pou dexetai ta queries
	//hamming_Search(query,k,L,tuxaioi,mikos,amount,inputs,output);
	for(i=0;i<count;i++){
		line_total[i]=0;
		for(j=0;j<count;j++){
			//distance_matrix_hamming[i][j]=find_distance(inputs[i],inputs[j],mikos,amount);
			//fprintf(fp,"%d \t",distance_matrix_hamming[i][j]);
			line_total[i]+=pinakas[i][j];
		}

		//printf(" sum distance %d \n",line_total[i]);
		//fprintf(fp," \n");
		total_sum+=line_total[i];
		//printf("total sum %d \n",total_sum);
	}
	/*for(i=0;i<5;i++){
		for(j=0;j<amount;j++){
			printf("%d \t",distance_matrix_hamming[i][j]);

		}
			printf(" sum distance %d \n",line_total[i]);
			printf(" \n");
	}*/
	double smallest=1;
	for(i=0;i<count;i++){
		entries_array[i]->distances=pinakas[i];
		entries_array[i]->position=i;
	}
	data **data_array=malloc(sizeof(data*)*count);
	init_data_array(count,data_array,entries_array,clusters);





	centroids **centroids_array=malloc(sizeof(centroids*)*clusters);
	centroids_array=concentrate_init(pinakas,line_total,v,entries_array,count,data_array,clusters);
	//centroids_array=plus_init(pinakas,data_array,count,clusters);



	int u;
	for(u=0;u<clusters;u++){
		printf(" centroid %d   \n",centroids_array[u]->position);
	}
	//clara(count,centroids_array,data_array,pinakas,clusters);

	//pam_assign(data_array,centroids_array,count,clusters);
	assign_LSH_matrix( k, L,tuxaioi,count,pinakas,output,data_array,0,centroids_array,clusters);

	update_Lloyds_matrix(centroids_array,data_array,count,k,L,tuxaioi,output,clusters,pinakas);
	//update_clarance_matrix(centroids_array,data_array,count,k,L,output,tuxaioi,clusters,pinakas,fraction,iteration);

	for(u=0;u<clusters;u++){
		printf(" centroid %d   \n",centroids_array[u]->position);
	}

	for(i=0;i<count;i++){
		printf("data %d \n",data_array[i]->centroid_position);


	}

	fclose(stream);

	/*for(i=0;i<count;i++){
		free(pinakas[i]);
		free(onomata[i]);
	}
	free(pinakas);
	free(onomata);*/
	/*for(i=0;i<(2*k);i++){
		free(tuxaioi[i]);
	}
	free(tuxaioi);*/
}

void create_query_matrix(centroids **centroids_array,int **pinakas,int aktina,int count,int clusters){
	char file[30]="Query_Distance_Matrix.txt";
	FILE* stream = fopen(file, "w");
	int i,j;
	fprintf(stream,"Radius:\t%d \n",aktina);
	for(i=0;i<clusters;i++){
		fprintf(stream,"item_idS%d",(i+1));
		for(j=0;j<count;j++){
			fprintf(stream,"\t%d",pinakas[centroids_array[i]->position][j]);
		}
		fprintf(stream,"\n");
	}
	fclose(stream);


}

void assign_LSH_matrix(int k,int L,int **tuxaioi,int count,int **pinakas,char *output,data **data_array,int old_centroid_position,centroids **centroids_array,int clusters){

		int aktina=1;
		int flag=0;
		char file[30]="Query_Distance_Matrix.txt";
		int i=0;
		//for(i=0;i<count;i++){
			//data_array[i]->centroids_for_data=centroids_array;

		//}
		while( aktina<65){
			
			create_query_matrix(centroids_array,pinakas,aktina,count,clusters);
			//flag=hamming_Search(file,k,L,tuxaioi, mikos,amount,inputs,output,data_array,old_centroid_position);
			//printf("FLAG %d \n",flag);
			metric_Search(file,k,L,tuxaioi,count,pinakas,output,data_array,old_centroid_position,centroids_array);











			aktina=aktina*2;
		}

}

void update_Lloyds_matrix(centroids **centroids_array,data** data_array,int count,int k,int L,int ** tuxaioi,char *output,int clusters,int **pinakas){

	int i=0;
	while(i<clusters){
		int old_centroid=centroids_array[i]->position;
		int something=find_cluster_medoid(centroids_array[i],data_array,count,old_centroid);
		//printf("KAINOURGIO %d \n",centroids_array[i]->position);
		//pam_assign(data_array,centroids_array,amount,clusters);
		assign_LSH_matrix( k, L,tuxaioi,count,pinakas,output,data_array,old_centroid,centroids_array,clusters);
			if(old_centroid==centroids_array[i]->position && i<5){
				i++;
			}

	}

}



void update_clarance_matrix(centroids **centroids_array,data **data_array,int amount,int k,int L,char *output,int** tuxaioi,int clusters,int **pinakas,int fraction,int iterations){
	int q=0;
	int posa;
	for(q=0;q<iterations;q++){
	if(fraction==-1){
		posa=0.12*clusters*(amount-clusters);
	
		if(posa<250)	posa=250;
	}
	else{
		posa=fraction;
	}
	printf("posa %d amount %d \n",posa,amount);
	int i=0,j=0,flag2=0,flag,aktina,u=0;
	int old_centroid,old_centroid_position,which;
		int total_distances=0;
		for(u=0;u<amount;u++){
			total_distances+=data_array[u]->distance_from_centroid;

		}
	for(i=0;i<posa;i++){
		int tuxaio_centroid=rand()%(clusters);
		int tuxaio_neo=rand()%amount;
		for(j=0;j<clusters;j++){
			if(centroids_array[j]->position!=tuxaio_neo)
				flag2=1;

		}


		if(flag2==1)
			tuxaio_neo=rand()%amount;
		//printf("zeugari %d , %d \n ",centroids_array[tuxaio_centroid]->position,data_array[tuxaio_neo]->position);
		//if(data_array[tuxaio_neo]->position==652)
			//printf(" !!!!!!!!!!! \n\n\n\n ");

		for(u=0;u<clusters;u++){
			//total_distances+=centroids_array[u]->sum_distances;
			if(centroids_array[u]->position==centroids_array[tuxaio_centroid]->position){
				old_centroid=centroids_array[u]->sum_distances;
				old_centroid_position=centroids_array[u]->position;			
				centroids_array[u]->position=data_array[tuxaio_neo]->position;
				//centroids_array->sum_distances=data_array[tuxaio_neo]->position->distances;
				centroids_array[u]->distances=data_array[tuxaio_neo]->distances;
				//printf("KAINOURGIO %d \n",centroids_array[u]->position);
				which=u;
			}
		}
		//printf("KAINOURGIO %d \n",centroids_array[which]->position);
		

		pam_assign(data_array,centroids_array,amount,clusters);
		//assign_LSH_matrix( k, L,tuxaioi,amount,pinakas,output,data_array,old_centroid_position,centroids_array,clusters);

		/*aktina=1;
		flag=0;
		char file[20]="Query_hamming.txt";
		while(flag<amount && aktina<65){
			
			create_query_hamming(centroids_array,inputs,aktina);
			flag=hamming_Search(file,k,L,tuxaioi, mikos,amount,inputs,output,data_array,old_centroid_position);
			//printf("FLAG %d \n",flag);











			aktina=aktina*2;
		}*/
		int new_total_distances=0;
		for(u=0;u<amount;u++){
			if(data_array[u]->centroid_position==old_centroid_position){
				data_array[u]->centroid_position=0;
				data_array[u]->distance_from_centroid=0;
			}
			else{
				data_array[u]->distance_from_centroid=data_array[u]->distances[data_array[u]->centroid_position];
		}
			new_total_distances+=data_array[u]->distance_from_centroid;
			//printf("DIS %d \n",data_array[u]->distance_from_centroid);
			centroids_array[which]->sum_distances=new_total_distances;
		}
		//printf("old %d new %d \n",total_distances,new_total_distances);
		if(total_distances<new_total_distances){

			int temp_centroid=centroids_array[which]->position;
			centroids_array[which]->position=old_centroid_position;
			
			centroids_array[which]->distances=data_array[old_centroid_position]->distances;
			//printf("KEEP IT \n");



			pam_assign(data_array,centroids_array,amount,clusters);	
			//assign_LSH_matrix( k, L,tuxaioi,amount,pinakas,output,data_array,temp_centroid,centroids_array,clusters);
			//sleep(2);
			for(u=0;u<amount;u++){
				if(data_array[u]->centroid_position==temp_centroid){
					data_array[u]->centroid_position=0;
					data_array[u]->distance_from_centroid=0;
				}
							else{
				data_array[u]->distance_from_centroid=data_array[u]->distances[data_array[u]->centroid_position];
			}
			new_total_distances+=data_array[u]->distance_from_centroid;
				//printf("DIS %d \n",data_array[u]->distance_from_centroid);
			
			}
			centroids_array[which]->sum_distances=total_distances;
		
		//total_distances=new_total_distances;
		new_total_distances=0;



		}
		else{
			total_distances=new_total_distances;


		}		


	}
	centroids **temp_centroid_array=malloc(sizeof(centroids*)*clusters);
	int best_distance=0,last_distance=0;
	last_distance=j_function(data_array,amount);
	if(last_distance<best_distance){
		best_distance=last_distance;
		temp_centroid_array=centroids_array;

	}
	else{
		pam_assign(data_array,centroids_array,amount,clusters);
		//assign_LSH_matrix( k, L,tuxaioi,amount,pinakas,output,data_array,0,temp_centroid_array,clusters);

	}
	}

}




#endif 

