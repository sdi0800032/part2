#include "BF.h"
#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#define block_size 512

int HT_CreateIndex( char *fileName, char attrType, char* attrName, int attrLength, int buckets) {
    char filetype[10] = "static";
    int fd ;
    long unsigned int position = 0;
	void *block;
    printf("size of block is %d bytes\n" , block_size);
    printf("size of record is %lu bytes \n" , sizeof(Record));
    printf("each block can contain up to %lu records (saving some bytes for info)\n" , (block_size - sizeof(Record))/sizeof(Record));		// keep some bytes in ea. block to store additional info
    printf("Requested buckets : %d  \n" , buckets );
    
	BF_Init();
	if( BF_CreateFile(fileName) < 0 ) { BF_PrintError("error while creating file"); return -1; }
	fd=BF_OpenFile(fileName);
	if( BF_AllocateBlock(fd)<0) {BF_PrintError("error while allocating block"); return -1; }
	if( BF_ReadBlock(fd, 0, &block)< 0 ) {BF_PrintError("error while reading block"); return -1; }
	//save info in first block
	memcpy( block + position , filetype , 10*sizeof(char));
	position += 10*sizeof(char) ;
	memcpy( block + position , &attrType , sizeof(char));
	position+= sizeof(char);
	memcpy( block + position  , attrName , 15*sizeof(char));
	position+= 15*sizeof(char);
	memcpy( block + position  , &attrLength , sizeof(int));
	position+= sizeof(int);
	memcpy( block + position  , &buckets , sizeof(int));
	position+= sizeof(int);
	//done saving 
	
	if( BF_WriteBlock( fd , 0) < 0 ){ BF_PrintError("error while writing block"); return -1; }
	if(BF_CloseFile(fd) < 0 ) { BF_PrintError("error while closing file"); return -1; }
    return 0; 
}

unsigned long hash_function( char *field1 , int field2 , HT_info *hptr){
	unsigned long result = 5381;
	int c;
	if( field1 == NULL ){
		// we're given an integer to process
		result = field2 % ( hptr->numBuckets ) ;
	}else{
		// we're given a string to process
		// (from stackoverflow)
		while ( c = *field1++ ) {
			result = ((result << 5) + result) + c; 				/* hash * 33 + c */
		}
		result = result % ( hptr->numBuckets ) ;
	}
	return result;
}

HT_info* HT_OpenIndex(char *fileName) {
	char filetype[20];
    HT_info *static_info;
    int fd , size_needed , blocks_needed , current_size , i , j , ptr , overflow = 0 , entries = 0 , pos=0;
    long unsigned int position = 0 ;
    void *block;
    static_info = malloc(sizeof(HT_info));
    static_info->attrName = malloc(sizeof(char)*15);
    fd=BF_OpenFile(fileName);
    if( BF_ReadBlock(fd, 0, &block)< 0 ){ BF_PrintError("error while reading block");sleep(5) ;/*return -1 */ };
    
    //get filetype
    memcpy( filetype , block+position, 10*sizeof(char));
    position += 10*sizeof(char);
    printf("type of file is : %s \n " , filetype);
    if(!strcmp(filetype,"static\n")){
		printf("wrong type of file , exiting \n");
		return NULL;
	}
    //store key type
	memcpy( &(static_info->attrType) , block+position ,sizeof(char));
	position += sizeof(char);
	//store attrname
	memcpy( static_info->attrName , block+position , 15*sizeof(char));
	position += 15*sizeof(char);
	//store key length
	memcpy( &(static_info->attrLength) , block+position , sizeof(int));
	position += sizeof(int);
	//store requested buckets
	memcpy( &(static_info->numBuckets) , block+position , sizeof(int));
	position += sizeof(int);
	//store fd
	static_info->fileDesc = fd;
	//compute how many blocks we'll need to store the "hash table" 
	size_needed = sizeof(int) * static_info->numBuckets ;
	if(size_needed < block_size) blocks_needed = 1;
	else{
		blocks_needed = 1;
		current_size = block_size;
		while( current_size < size_needed){
			current_size += block_size;
			blocks_needed ++;
		}
	}
	ptr = blocks_needed + 1;
	// allocate blocks to hold the hash table , range of id blocks is : [1 , blocks_needed(for hashtable)] ( 0 is holding basic info )
	for(i=0; i<blocks_needed; i++){
		if( BF_AllocateBlock(fd)<0){ BF_PrintError("error while allocating block"); sleep(5); /*return -1 */ };
	}
	// allocate all essential starting buckets ( none overflow yet )
	// range of id buckets is : [blocks_needed(for hashtable) + 1 , total_buckets + blocks_needed(for hashtable) + 1]
	for(i=0; i<static_info->numBuckets; i++){
		if( BF_AllocateBlock(fd)<0){ BF_PrintError("error while allocating block");	sleep(5); /*return -1 */ };
		if( BF_ReadBlock(fd, i+ptr  , &block)< 0 ) BF_PrintError("error while reading block");
		memcpy(block + 512 - sizeof(int) , &overflow , sizeof(int));
		memcpy(block + 512 - 2*sizeof(int) , &entries , sizeof(int));
		if( BF_WriteBlock( fd , i+ptr) < 0 ){ BF_PrintError("error while writing block"); sleep(5); /*return -1 */ };
	}
//	capacity = block_size / sizeof(int) ; // how many pointers (int values) can contain each block
	// link hashtable to all initial blocks
	for(i=1; i<=blocks_needed; i++){
		position = 0;
		if( BF_ReadBlock(fd, i  , &block)< 0 ){ BF_PrintError("error while reading block");sleep(5); /*return -1 */ };
		for(j=pos; j<static_info->numBuckets; j++){
			memcpy(block+position, &ptr , sizeof(int));
			position+= sizeof(int);
			ptr++;
			pos++;
			if(position>508) break;
		}
		if( BF_WriteBlock( fd , i) < 0 ){ BF_PrintError("error while writing block");sleep(5) ;/*return -1 */ };
	}
	if( BF_ReadBlock(fd, 0  , &block)< 0 ){ BF_PrintError("error while reading block");sleep(5); /*return -1 */ };
	memcpy( block + 512 - sizeof(int) , &blocks_needed , sizeof(int));
	memcpy( block + 512 - 2*sizeof(int) , &static_info->numBuckets , sizeof(int));
	if( BF_WriteBlock( fd , 0) < 0 ){ BF_PrintError("error while writing block");sleep(5) ;/*return -1 */ };
    return static_info;
} 


int HT_CloseIndex( HT_info* header_info ) {
    if(header_info->fileDesc){
		printf("closing file...\n");
	}
	if(BF_CloseFile(header_info->fileDesc) < 0 ) BF_PrintError("error while closing file");
	free((header_info->attrName));
	free(header_info);
    
    return -1;
    
}

int ct = 0; 
int HT_InsertEntry(HT_info *header_info, Record record) {
    int result=-1 , fd , current_size , blockno=1 , offset = 0 , block_id , entries , overflow=0, prev_overflow ,   new_overflow=0 , new_entries=1  , overflow_id;
    void *block;
    long unsigned size ;
    fd = header_info->fileDesc;
    	char name[50];
    // find key and hash it
    if(!strcmp( header_info->attrName , "city")){
		result = hash_function( record.city , 0 , header_info );
	}
	else if(!strcmp( header_info->attrName , "surname")){
		result = hash_function( record.surname , 0 , header_info );
	}
	else if(!strcmp( header_info->attrName , "name")){
		result = hash_function( record.name , 0 , header_info );
	}
	else if(!strcmp( header_info->attrName , "id")){
		result = hash_function( NULL , record.id , header_info  );
	}
	//where can I find the pointer to the block?
	size = result * sizeof(int);
	if( size < block_size ){			// you will find your entry in the block 1
		blockno = 1;
	}else{
		current_size = block_size;
		while( current_size <= size){
			current_size += block_size;
			blockno++;
			offset ++ ; 				// offset is a value which holds how many blocks will a value skip to find the entry . so if the hashtable needs to be stored in 3 blocks , in the 3rd block a hash result with value X , will go to entry X*sizeof(int) - ( offset*(block_size / sizeof(int))
		}	
	}
	
		if( BF_ReadBlock(fd, blockno  , &block)< 0 ) {BF_PrintError("1error while reading block"); printf("q : %d\n" , block_id); sleep(5); }
		memcpy( &block_id , block + (result)*sizeof(int)- ( offset*block_size ) , sizeof(int));
//		printf(" got id %d from entry %d \n" , block_id , result);
		// go to the bucket with id : block_id
		if( BF_ReadBlock(fd, block_id  , &block)< 0 ){ BF_PrintError("2error while reading block");  sleep(5); }
		memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int));
		memcpy( &overflow , block + 512 - sizeof(int) , sizeof(int));
		if(block_id==0){ printf("...\n"); sleep(3); }
		
		if(entries < 7 ) {
			// we can store the record here , there's enough space
				memcpy( block + entries*sizeof(Record) , &record , sizeof(Record));
				entries++;
				memcpy( block + 512 - 2*sizeof(int) , &entries , sizeof(int));
				if( BF_WriteBlock( fd , block_id) < 0 ) {BF_PrintError("error while writing1 block"); sleep(5); }
//				memcpy( name , block + (entries-1) * sizeof(Record) + sizeof(int) , sizeof(char)*15);
//				printf("fished a name , is it :%s \n" , name);
		}else{
//			printf("no space left in bucket %d \n" , block_id);
			// check if there is already an overflow bucket
			memcpy( &overflow , block + 512 - sizeof(int) , sizeof(int));
			if( overflow == 0 ){
//				printf("no overflow found , allocating ... \n");
				// no overflowbucket found , allocate a new one and link it to the one we're in
				if( BF_AllocateBlock(fd)<0){ BF_PrintError("error while allocating block");	sleep(5); }
				ct++;
			    overflow = BF_GetBlockCounter(fd) - 1 ;
			    memcpy( block + 512 - sizeof(int) , &overflow , sizeof(int));			// store overflow id in the current bucket 
			    if( BF_WriteBlock( fd , block_id) < 0 ) {BF_PrintError("error while writing1 block"); sleep(5); }
			    // go to overflow bucket , initialize all needed info ( entries and overflow ) and then store our record in the first entry
				if( BF_ReadBlock(fd, overflow  , &block)< 0 ){ BF_PrintError("error while reading block");sleep(5); }
				memcpy( block + 512 - sizeof(int) , &new_overflow , sizeof(int));					// this bucket was just allocated , obviously overflow value is 0
				memcpy( block , &record , sizeof(Record));
				memcpy( block + 512 - 2*sizeof(int) , &new_entries , sizeof(int));					// entries count is now 1 (just saved a record)
				memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int));
//				memcpy( name , block + (entries-1) * sizeof(Record) + sizeof(int) , sizeof(char)*15);
//				printf("fished a name , is it :%s \n" , name);
				if( BF_WriteBlock( fd , overflow) < 0 ){ BF_PrintError("1error while writing block");  sleep(5); }
		//s		sleep(5);
				
			}
			else{
				if( BF_ReadBlock(fd, overflow  , &block)< 0 ){ BF_PrintError("error while reading block"); sleep(5); }
//				printf(" overflow found , checking ... \n");
				memcpy( &overflow_id , block + 512 - sizeof(int) , sizeof(int));
				if(overflow_id == 0 ){
					// this is the last overflow node , no need to look further
					overflow_id = overflow;
				}else{
						while( 1 ) {
							// find the last linked overflow bucket
							if( BF_ReadBlock(fd, overflow_id  , &block)< 0 ){ BF_PrintError("error while reading block"); sleep(5); }
							prev_overflow = overflow_id;
							memcpy( &overflow_id , block + 512 - sizeof(int) , sizeof(int));
							if(overflow_id == 0 ){
								overflow_id = prev_overflow;
								// found the last connected bucket , dont search for another , stay in the previous one
								break;
							}
						}
				}
				overflow = overflow_id;
				memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int)); 
				if(entries < 7 ) { 
				// we can store the record here , there's enough space
					memcpy( block + entries*sizeof(Record) , &record , sizeof(Record)); 
					entries++;
					memcpy( block + 512 - 2*sizeof(int) , &entries , sizeof(int));
					memcpy( name , block + (entries-1) * sizeof(Record) + sizeof(int) , sizeof(char)*15); 
//					printf("fished a name , is it :%s \n" , name);
					if( BF_WriteBlock( fd , overflow) < 0 ) {BF_PrintError("2error while writing block"); printf("id %d\n"  , overflow) ; sleep(5); }
				}else{
					new_overflow = 0; new_entries = 1;
					if( BF_AllocateBlock(fd)<0){ BF_PrintError("error while allocating block");	sleep(5); }
					ct++;
					prev_overflow = overflow;
					overflow = BF_GetBlockCounter(fd) - 1 ;
					memcpy( block + 512 - sizeof(int) , &overflow , sizeof(int));			// store overflow id in the current bucket 
					if( BF_WriteBlock( fd , prev_overflow) < 0 ) {BF_PrintError("error while writing1 block"); sleep(5); }
					// go to overflow bucket , initialize all needed info ( entries and overflow ) and then store our record in the first entry
					if( BF_ReadBlock(fd, overflow  , &block)< 0 ){ BF_PrintError("error while reading block"); sleep(5); }
					memcpy( block + 512 - sizeof(int) , &new_overflow , sizeof(int));					// this bucket was just allocated , obviously overflow value is 0
					memcpy( block , &record , sizeof(Record));
					memcpy( block + 512 - 2*sizeof(int) , &new_entries , sizeof(int));					// entries count is now 1 (just saved a record)
					memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int));
					memcpy( name , block + (entries-1) * sizeof(Record) + sizeof(int) , sizeof(char)*15);
//					printf("fished a name , is it :%s \n" , name);
					if( BF_WriteBlock( fd , overflow) < 0 ){ BF_PrintError("3error while writing block"); sleep(5); }
				}
			}
		}
//		printf("%d\n", ct); 

    return -1;
}



int HT_GetAllEntries(HT_info *header_info, void *value) {
    int blocks_needed_for_table , total_buckets , fd , key_id , flag =0 , i , result , block_no = 1 , current_size , offset = 0 , block_id , entries , overflow , key_int , found=0 ,total=0,blocks_read=0;
    long unsigned   search_position , size;
    Record record;
    char *key_string , key_chars[25];
    void *block;
    printf("\n\n");
    if(!strcmp( header_info->attrName , "id")){
		search_position = 0;
		key_string = value ;
		flag=1;
		}
	else if(!strcmp( header_info->attrName , "name")){
		search_position = sizeof(int);
		key_string = value;
	}
	else if(!strcmp( header_info->attrName , "surname" )){
		search_position = sizeof(int) + sizeof(char) * 15 ;
		key_string = value;
	}
	else if(!strcmp( header_info->attrName , "city")){
		search_position = sizeof(int) + sizeof(char) * 15 + sizeof(char) * 20 ; 
		key_string = value;
	}
    fd = header_info->fileDesc ;
    if( BF_ReadBlock(fd, 0  , &block)< 0 ){ BF_PrintError("error while reading block"); }
    memcpy( &blocks_needed_for_table  , block + 512 - sizeof(int) , sizeof(int));
    total_buckets = header_info->numBuckets;
    printf("blocks needed to store_hashtable:%d  , total buckets :%d\n" , blocks_needed_for_table , total_buckets);
	if(flag) { key_id = atoi(key_string);  printf("%d\n" , key_id); }
//	else printf("%s \n" , key_string);
    if(flag) result = hash_function( NULL , key_id , header_info);
    else {
		result = hash_function( key_string , 0 , header_info);
	}
    
    size = result * sizeof(int);
	if( size < block_size ){			// you will find your entry in the block 1
		block_no = 1;
	}else{
		current_size = block_size;
		while( current_size <= size){
			current_size += block_size;
			block_no++;
			offset ++ ; 			
		}
	}
    // search in block blockno to find your entry's id
    if( BF_ReadBlock(fd, block_no  , &block)< 0 ){ BF_PrintError("error while reading block"); sleep(5); }
    memcpy( &block_id , block + (result)*sizeof(int)- ( offset*block_size ) , sizeof(int));
    //search bucket with id: block id to find your entry
    if( BF_ReadBlock(fd, block_id  , &block)< 0 ){ BF_PrintError("error while reading block");  sleep(5); }
    blocks_read++;
    memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int));
	memcpy( &overflow , block + 512 - sizeof(int) , sizeof(int));
	for(i=0; i<entries; i++){
		// get all entries from the bucket , check if the key matches . If it does , print it
		if(flag) {
			memcpy( &key_int , block + search_position + i*sizeof(Record) , sizeof(int));
			if(key_int == key_id) {
				memcpy( &record , block +  i*sizeof(Record) , sizeof(Record));
				printf("found item with id : %d \n details: %d %s %s %s \n" , record.id , record.id ,  record.name , record.surname , record.city);
				found=1;
				total++;
			}
		}else{
			memcpy( &key_chars , block + search_position + i*sizeof(Record) , sizeof(char)*25);
			if(!strcmp(key_chars , key_string)) {
				memcpy( &record , block +  i*sizeof(Record) , sizeof(Record));
				printf("found item with key : %s \n details: %d %s %s %s \n" , key_chars , record.id , record.name , record.surname , record.city);
				found=1;
				total++;
			}
		}
	}
	// done with the entries , check if there are overflow buckets
	if(	overflow == 0 ) return total;  // done
	else{
		while(overflow!=0){
			if( BF_ReadBlock(fd, overflow  , &block)< 0 ){ BF_PrintError("error while reading block"); sleep(5); }
			blocks_read++;
			memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int));
			for(i=0; i<entries; i++){
				// get all entries from the bucket , check if the key matches . If it does , print it
				if(flag) {
					memcpy( &key_int , block + search_position + i*sizeof(Record) , sizeof(int));
					if(key_int == key_id) {
						memcpy( &record , block +  i*sizeof(Record) , sizeof(Record));
						printf("found item with id : %d \n details: %d %s %s %s \n" , record.id , record.id ,  record.name , record.surname , record.city);
						found=1;
						total++;
					}
				}else{
					memcpy( &key_chars , block + search_position + i*sizeof(Record) , sizeof(char)*25);
					if(!strcmp(key_chars , key_string)) {
						memcpy( &record , block +  i*sizeof(Record) , sizeof(Record));
						printf("found item with key : %s \n details: %d %s %s %s \n" , key_chars , record.id , record.name , record.surname , record.city);
						found=1;
						total++;
					}
				}
			}
			memcpy( &overflow , block + 512 - sizeof(int) , sizeof(int)); // is there another overflow bucket ? If there is , continue and read it
		}
	}

	if(!found) { 
		if(flag) printf("no record with key : %d found \n" , key_id);
		else printf("no record with key : %s found \n" , key_string);
		  return -1;
	}
	printf("total records found :%d\n" , total);
	printf("total blocks read : %d\n" , blocks_read);
	return total;
}

void sort_entries(int  *records ,int *bucket_has_overflow ,  int items ){
	int i , min , max , ct=0;
	float mo=0.0;
	for(i=0; i<items; i++){
		if(i==0) { min = records[i] ; max = records[i]; }
		if( records[i] <= min ){
			min = records[i];
		}
		if( records[i] >= max){
			max = records[i];
		}
		mo+= records[i];
		if( bucket_has_overflow[i]>0){
	//		printf("bucket:%d is linked to %d overflow buckets \n"  , i , bucket_has_overflow[i]);
			 ct++;
		 }
	}
	mo = mo / items;
	printf("max records found in bucket : %d \nmin records found in bucket: %d \naverage records per bucket: %f \n" , max , min , mo );
	printf("buckets that are linked to overflow buckets : %d\n" , ct);
}

int HashStatistics(char* filename) {
	int fd , block_number , i , total_buckets , table , j , position , id , pos=0 , entries , overflow;		// table is a value which holds how many blocks are needed to store the hash table structure ( array of ints )
	void *block;
	int total_blocks_all ;
	printf("\nStatistics:\n");
    fd=BF_OpenFile(filename);
    block_number = BF_GetBlockCounter(fd) - 1 ;
    printf("\n\nFile :%s has %d blocks \n" ,filename ,  block_number);
    if( BF_ReadBlock(fd, 0  , &block)< 0 ){ BF_PrintError("error while reading block"); sleep(5); }
    memcpy( &total_buckets , block + 512 - 2*sizeof(int) , sizeof(int));
    memcpy( &table, block + 512 - sizeof(int) , sizeof(int));
    int records[total_buckets];
    float total_blocks_allocated = 0;
    float average_blocks_allocated;
    int bucket_has_overflow[total_buckets];
    for(i=0; i<total_buckets; i++){
		records[i] = 0 ;
		bucket_has_overflow[i] = 0;
	}
    for(i=1; i<=table; i++){
		position = 0;
		for(j= pos; j<total_buckets; j++){
				if( BF_ReadBlock(fd, i  , &block)< 0 ){ BF_PrintError("error while reading block");sleep(5); /*return -1 */ };
				memcpy(&id, block+position , sizeof(int));
				position+= sizeof(int);
				pos++;
				// search block with id : id for statistics
				if( BF_ReadBlock(fd, id  , &block)< 0 ){ BF_PrintError("2error while reading block");sleep(5); /*return -1 */ };
				total_blocks_allocated++;
				memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int));
				memcpy( &overflow , block + 512 - sizeof(int) , sizeof(int));	
				records[j]+= entries;
				if(overflow!=0){
					while(overflow!=0){
						total_blocks_allocated++;
						bucket_has_overflow[j]++;
						if( BF_ReadBlock(fd, overflow , &block)< 0 ){ BF_PrintError("1error while reading block");sleep(5); /*return -1 */ };
						memcpy( &entries , block + 512 - 2*sizeof(int) , sizeof(int));
						records[j]+= entries;
						memcpy( &overflow , block + 512 - sizeof(int) , sizeof(int));	
					}
				}
				if(position>508) break;
		}
	}
	sort_entries( records ,bucket_has_overflow ,  total_buckets );
	average_blocks_allocated = total_blocks_allocated / total_buckets ;
	total_blocks_all  = (int) total_blocks_allocated ;
	printf("average number of blocks allocated per bucket : %f (total blocks allocated:%d) \n" , average_blocks_allocated  ,total_blocks_all );
	if(BF_CloseFile(fd) < 0 ) BF_PrintError("error while closing file");
    return 0;
    
}
