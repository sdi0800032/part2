
compile : gcc -o ht hash.c testmain.c BF_64.a
run : ./ht -f 10000.csv
