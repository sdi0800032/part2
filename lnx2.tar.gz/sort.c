#include "BF.h"
#include "records.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#define block_size 512

int HT_CreateIndex( char *fileName) {
    int fd , current_blocks = 0;
    int max_rec_per_block  = (block_size - sizeof(int))/sizeof(Record) ;
    long unsigned int position = 0;
	void *block;
//    printf("size of block is %d bytes\n" , block_size);
//    printf("size of record is %lu bytes \n" , sizeof(Record));
//    printf("each block can contain up to %lu records (saving some bytes for info)\n" , (block_size - sizeof(int))/sizeof(Record));		// keep some bytes in ea. block to store additional info
	if( BF_CreateFile(fileName) < 0 ) { BF_PrintError("error while creating file"); return -1; }
	fd=BF_OpenFile(fileName);
	if( BF_AllocateBlock(fd)<0) {BF_PrintError("error while allocating block"); return -1; }
	if( BF_ReadBlock(fd, 0, &block)< 0 ) {BF_PrintError("error while reading block"); return -1; }
	//save info in first block
	memcpy( block+position, &current_blocks , sizeof(int) );
	position += sizeof(int) ;
	memcpy( block+position, &max_rec_per_block , sizeof(int) );
	position += sizeof(int) ;
	memcpy( block+position, &fd , sizeof(int) );
	if( BF_WriteBlock( fd , 0) < 0 ){ BF_PrintError("error while writing block"); return -1; }
	if(BF_CloseFile(fd) < 0 ) { BF_PrintError("error while closing file"); return -1; }
    return 0; 
}

HT_info* HT_OpenIndex(char *fileName) {
    HT_info *static_info;
    int fd ,  max_rec_per_block;
    void *block;
    static_info = malloc(sizeof(HT_info));
    
    fd=BF_OpenFile(fileName);
    if( BF_ReadBlock(fd, 0, &block)< 0 ){ BF_PrintError("error while reading block");sleep(5) ;/*return -1 */ };
    memcpy( &max_rec_per_block  , block+sizeof(int), sizeof(int));
//    printf("in open index :  each block can contain up to %d records \n " , max_rec_per_block);
	//store fd
	static_info->fileDesc = fd;
    return static_info;
} 


int HT_CloseIndex( HT_info* header_info ) {
    if(header_info->fileDesc){
		printf("closing file...\n");
	}
	if(BF_CloseFile(header_info->fileDesc) < 0 ) BF_PrintError("error while closing file");
	free((header_info->attrName));
	free(header_info);
    
    return -1;
    
}

int HT_InsertEntry(HT_info *header_info, Record record) {
    int current_blocks , max_rec_per_block, fd , position = 0 , where_to_store;
    void *block;
    fd = header_info->fileDesc;
    if( BF_ReadBlock(fd, 0, &block)< 0 ){ BF_PrintError("error while reading block");sleep(5) ;/*return -1 */ };
    memcpy( &current_blocks  , block, sizeof(int));
    position = sizeof(int);
    memcpy( &max_rec_per_block  , block+position, sizeof(int));
	position = 0;
	// if this is the first time we try to store a record , create a new block and start there . In the new block the first 4 bytes will be stored to show where the next record should be saved
	if(current_blocks == 0){
//		printf("current blocks 0 , allocate new \n");
		current_blocks++;
		memcpy(  block+position  , &current_blocks, sizeof(int));
		if( BF_WriteBlock( fd , 0) < 0 ){ BF_PrintError("error while writing block"); return -1; }
		if( BF_AllocateBlock(fd)<0) {BF_PrintError("error while allocating block"); return -1; }
		if( BF_ReadBlock(fd, current_blocks , &block)< 0 ) {BF_PrintError("error while reading block"); return -1; }
		//since we will now save a record , we set the value where_to_store to sizeof(record) + int beforehand .
		where_to_store =  sizeof(int) + sizeof(Record) ;
		memcpy(  block  , &where_to_store , sizeof(int));	
		// then we store the first record after the first 4 bytes (needed for the var where_to_store)
		memcpy( block+sizeof(int) , &record , sizeof(Record));
		if( BF_WriteBlock( fd , current_blocks) < 0 ){ BF_PrintError("error while writing block"); return -1; }
		return 1; // a record has been saved succesfully
	}else{
		position = 0;
		if( BF_ReadBlock(fd, current_blocks , &block)< 0 ) {BF_PrintError("aerror while reading block"); return -1; }
		memcpy( &where_to_store , block  , sizeof(int));	
//		printf("where to store : %d , curr blocks : %d \n" , where_to_store , current_blocks);
//		sleep(1);
		if( where_to_store + sizeof(Record) > block_size ) {
			// we need to allocate a new block , no space here . Also update the info in the first block
			if( BF_ReadBlock(fd, 0 , &block)< 0 ) {BF_PrintError("error while reading block"); return -1; }
			current_blocks++;
			memcpy(  block+position  , &current_blocks, sizeof(int));
			if( BF_WriteBlock( fd , 0) < 0 ){ BF_PrintError("error while writing block"); return -1; }
			if( BF_AllocateBlock(fd)<0) {BF_PrintError("error while allocating block"); return -1; }
			if( BF_ReadBlock(fd, current_blocks , &block)< 0 ) {BF_PrintError("error while reading block"); return -1; }
			where_to_store =  sizeof(int) + sizeof(Record) ;
			memcpy(  block  , &where_to_store , sizeof(int));	
			memcpy( block+sizeof(int) , &record , sizeof(Record));
			if( BF_WriteBlock( fd , current_blocks) < 0 ){ BF_PrintError("2error while writing block"); return -1; }
			return 1; // a record has been saved succesfully
		}else{
			//there is still space left in this block , we can store the record here
			position = where_to_store;
			memcpy( block+position , &record , sizeof(Record));;
			where_to_store += sizeof(Record) ;
			memcpy( block , &where_to_store , sizeof(int));
			if( BF_WriteBlock( fd , current_blocks) < 0 ){ BF_PrintError("1error while writing block"); return -1; }
			return 1 ; // a record has been saved succesfully
		}
		
		
		
		}
	if(record.id == -1) HT_CloseIndex( header_info );
    return -1;
}


// Sorted functions 



int Sorted_CreateFile( char *fileName ){		// creates new file with sorted identifier in first block
	void *block;
	int fd , is_sorted = 1 , current_blocks = 1;
	if( BF_CreateFile(fileName) < 0 ) { BF_PrintError("error while creating file"); return -1; }
	fd=BF_OpenFile(fileName);
	printf("fd:%d name:%s\n" , fd , fileName);
	if( BF_AllocateBlock(fd)<0) {BF_PrintError("1error while allocating block"); return -1; }
	if( BF_ReadBlock(fd, 0, &block)< 0 ) {BF_PrintError("error while reading block"); return -1; }
	memcpy( block , &is_sorted , sizeof(int));
	memcpy(block + block_size - sizeof(int)  , &current_blocks , sizeof(int));
	if( BF_WriteBlock( fd , 0) < 0 ){ BF_PrintError("error while writing block"); return -1; } 
	if(BF_CloseFile(fd) < 0 ) { BF_PrintError("error while closing file"); return -1; }
//	printf("created block file with name : %s \n" , fileName);
    return 0; 
}


int Sorted_OpenFile( char *fileName ){		// opens an existing sorted file
	void *block;
	int fd , is_sorted;
	fd=BF_OpenFile(fileName);
	if( BF_ReadBlock(fd, 0, &block)< 0 ) {BF_PrintError("error while reading block"); return -1; }
	memcpy(  &is_sorted , block ,sizeof(int));
	if(is_sorted) return fd;
	else return -1;
}


int Sorted_CloseFile( int fileDesc ){
	if(BF_CloseFile(fileDesc) < 0 ) {
		BF_PrintError("error while closing file");
		return -1;
	}
	return 1;
}

Record* sort_records( Record *recs , int num , int field) {		// sorts records stored in a small array [buffsize] depending on the field that is given
	int i , j;
	Record temp;
	
	if(field==0){ 	// sort id
		for(i=0; i<num-1; i++){
			for(j=0; j<num-i-1; j++){
				if (recs[j].id > recs[j+1].id){
					temp = recs[j];
					recs[j] = recs[j+1];
					recs[j+1] = temp;
				}
			}
		}
	}else if(field==1){	// sort name
		for(i=0; i<num-1; i++){
			for(j=0; j<num-i-1; j++){
				if (strcmp(recs[j].name , recs[j+1].name)>0){
					temp = recs[j];
					recs[j] = recs[j+1];
					recs[j+1] = temp;
				}
			}
		}
	}else if(field==2){ //sort surname
		for(i=0; i<num-1; i++){
			for(j=0; j<num-i-1; j++){
				if (strcmp(recs[j].surname , recs[j+1].surname)>0){
					temp = recs[j];
					recs[j] = recs[j+1];
					recs[j+1] = temp;
				}
			}
		}
	}else if(field==3){ // sort city
		for(i=0; i<num-1; i++){
			for(j=0; j<num-i-1; j++){
				if (strcmp(recs[j].city , recs[j+1].city)>0){
					temp = recs[j];
					recs[j] = recs[j+1];
					recs[j+1] = temp;
				}
			}
		}
	}
	
	
	return recs;
	}


char* Sorted_SortFile( char *fileName, int fieldNo){		// creates the first N files ( given a file with N blocks ) and passes them to another function to start merging them
	void *block ;
	int fd , z ,tim ,  total_blocks , max_per_block , i , position = 0, position2 = 0 , j , flag=0 ,  last_sort_num , sorted;
	char *output_file , *temp;
	char *number;
	output_file = malloc( (strlen(fileName)+1 ) + sizeof(char) * 7  ); // size of filename + SORTED(6 chars) + NUMBER(1 char) 
	number = malloc(sizeof(char));
	sprintf( number , "%d" , fieldNo);
	strcpy(output_file , fileName);
	strcat( output_file , "Sorted");
	strcat( output_file , number);
	
	fd = BF_OpenFile(fileName) ; 
	if( BF_ReadBlock(fd, 0, &block)< 0 ) {BF_PrintError("error while reading block"); return NULL; }
	memcpy(  &total_blocks , block ,sizeof(int));
	int fd2[total_blocks*total_blocks];
//	printf("total blocks found in file : %d \n" , total_blocks);
	memcpy(  &max_per_block , block+sizeof(int) ,sizeof(int));
//	printf("max records per block : %d \n" , max_per_block);
	fd2[0] = fd;
	Record recs[max_per_block+1] ; 
	char namefile[5];
	for(i=1; i<=total_blocks; i++){
		sprintf( namefile , "%d" , i+1 );
		Sorted_CreateFile( namefile);
		fd2[i] = Sorted_OpenFile( namefile );
	}
	for(i=1; i<=total_blocks; i++){
		position = sizeof(int) ; // we dont need the info that is stored in the first 4 bytes of each block , so we skip that
//		printf("reading file %d @ blockn%d \n" , fd , i);
		if( BF_ReadBlock(fd2[0], i , &block)< 0 ) {BF_PrintError("error while reading block"); sleep(5); return NULL; }
		memcpy( &tim ,  block  , sizeof(int));	
//		printf("its first bytes are : %d  , fd2 : %d\n" , tim , fd2[0]);
		for(j=0; j<max_per_block; j++){
			memcpy( &recs[j] , block + position , sizeof(Record));	
			position += sizeof(Record) ;
			if(recs[j].id == -1) {
				flag = 1;
				break;
			}
		}
		if(flag) {
			last_sort_num = j;
			sort_records( recs , last_sort_num ,fieldNo);
			if( BF_AllocateBlock(fd2[i])<0) {BF_PrintError("1error while allocating block"); return NULL; }
			if( BF_ReadBlock(fd2[i], 1 , &block)< 0 ) {BF_PrintError("aerror while reading block"); return NULL; }
			position2 = 0;
			for(z=0; z<last_sort_num; z++){
				memcpy( block+position2 ,  &recs[z]  , sizeof(Record));	
				printf("%d %s %s %s \n" , recs[z].id , recs[z].name , recs[z].surname , recs[z].city);
				position2+= sizeof(Record) ;
			}
			if( BF_WriteBlock( fd2[i] , 1) < 0 ){ BF_PrintError("error while writing block"); return NULL; }
			break; 
		}
	//	printf("\n\n");
		sort_records( recs , max_per_block ,fieldNo);		// sort the records , depends on fieldNO	
		if( BF_AllocateBlock(fd2[i])<0) {BF_PrintError("error while allocating block"); return NULL; }
		if( BF_ReadBlock(fd2[i], 1 , &block)< 0 ) {BF_PrintError("error while reading block"); return NULL; }
		position2 = 0;
		for(z=0; z<max_per_block; z++){
			memcpy( block+position2 ,  &recs[z]  , sizeof(Record));	
			printf("%d %s %s %s \n" , recs[z].id , recs[z].name , recs[z].surname , recs[z].city);
			position2+= sizeof(Record) ;
		}
		if( BF_WriteBlock( fd2[i] , 1) < 0 ){ BF_PrintError("error while writing block"); return NULL; }
	}
	int total_files = i;
	// start merging the sorted files in pairs
	sorted = sort_files( fd2 , total_files , recs  , fieldNo , max_per_block);
	temp = malloc(sizeof(char)*10);
	sprintf( temp , "%d" , sorted );
	rename( temp , output_file);
	return output_file;
	}


int sort_files( int *fd , int total_files , Record *recs , int field , int max ){		// creates pairs of files and passes them to another function to merge them until only one is left 
	int  fd1 , fd2 , j , it , start , done = 0;
	char *name1 , *name2;
	name1= malloc(sizeof(char)*10);
	name2 = malloc(sizeof(char)*10);
	it = total_files;
	if(total_files%2==1) it++;
	start = 1;
	while(1){
		
		if(total_files%2==0){	
			for(j=start; j<total_files; j+=2){
				sprintf(name1, "%d" , j+1);
				fd1 = Sorted_OpenFile( name1 );
				sprintf(name2, "%d" , j+2);
				fd2= Sorted_OpenFile(name2);
				printf("fd1:%d fd2:%d  , name1:%s name2:%s  , tot:%d\n" , fd1,fd2 , name1, name2 , total_files); 
				if( merge_files( fd1 , fd2 , fd , name1,name2 ,  recs , field , max , it) == 1 ) {
					done = 1;
					break;
				}
				it++;	
				Sorted_CloseFile(fd1);
				Sorted_CloseFile(fd2);	
			}
			if(done) break;
			start = total_files;
			total_files = it;
		}else if(total_files%2==1){
			for(j=start; j<=total_files; j+=2){
				sprintf(name1, "%d" , j+1);
				fd1 = Sorted_OpenFile( name1 );
				if(j+1 > total_files){
					sprintf(name2, "%d" , j+1);
					fd2= Sorted_OpenFile(name2);
				}else {
					sprintf(name2, "%d" , j+2);
					fd2= Sorted_OpenFile(name2);
				}
				printf("fd1:%d fd2:%d  , name1:%s name2:%s  , tot:%d\n" , fd1,fd2 , name1, name2 , total_files); 
				if( merge_files( fd1 , fd2 , fd , name1,name2 ,  recs , field , max , it) == 1 ) {
					done = 1;
					break;
					
				}
				it++;	
				Sorted_CloseFile(fd1);
				Sorted_CloseFile(fd2);	
			}
			if(done) break;
			start = total_files + 1;
			total_files = it;
		}
	}
	total_files++;
	return total_files;
	free(name1); free(name2);
}
		
	
	

	
	
int merge_files(int fd1 , int fd2, int *fd3 ,  char *name1, char *name2 , Record *recs , int field , int max , int total_files){		// merge a pair of files
	void *block;
	Record rec1 , rec2;
	int  position1=0 , position2=0 , position3=0 ,  capacity=0  , bl1=1 , bl2=1 , bl3=0  , choose_rec , store_pos = 0 , curr_blocks , flag=0 , skip=0 , nrecs=0;
	char  *new_file ;
	if(fd1 < 0 || fd2 <0) {
		printf("done\n");
		return 1;
	}

	// load first 2 records and compare them , 1 from each file
	if( BF_ReadBlock(fd1, bl1 , &block)< 0 ) {BF_PrintError("1error while reading block"); return 0; }
	memcpy( &rec1 , block+position1 , sizeof(Record) );
	if( BF_ReadBlock(fd2, bl2 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }	
	memcpy( &rec2 , block+position2 , sizeof(Record) );
	position1+=sizeof(Record);
	position2+=sizeof(Record);
	printf("rec1 %d rec2 %d  , fd1:%d , fd2:%d\n" , rec1.id , rec2.id , fd1 , fd2) ;
	if(!strcmp(name1,name2) ){
		skip = 1;
		}
	capacity++;
	//create new file to merge the other two , its name is the number after the last blocknumber in the first line (i.e if we have 12 files with names 1,2,3..12 , the new file will be named 13 etc)
	new_file = malloc(sizeof(char)*15);
	total_files++;
	sprintf( new_file , "%d" , total_files);
	Sorted_CreateFile(new_file);
	fd3[total_files] = Sorted_OpenFile(new_file);
	//
	while(1){
		if(flag) break;
		if( BF_AllocateBlock(fd3[total_files])<0) {BF_PrintError("error while allocating block"); return 0; }
		if( BF_ReadBlock(fd3[total_files] , 0 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
		bl3++;
		memcpy(block+block_size-sizeof(int) , &bl3 , sizeof(int) );
		if( BF_WriteBlock( fd3[total_files] , 0) < 0 ){ BF_PrintError("error while writing block"); return 0; }
		capacity=1;
		position3 = 0;
		store_pos = 0;
		while(capacity<=max){
		
		if(!skip)	choose_rec = which_to_hold( rec1 , rec2 , field );
		else choose_rec = 1;
			if(choose_rec==0){  flag=1 ; break; } 
			if(choose_rec==1){
				if(rec1.id==0 && skip==1) break;
				printf("%d %s %s %s\n",rec1.id , rec1.name , rec1.surname , rec1.city);
				if( BF_ReadBlock(fd3[total_files] , bl3 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
				memcpy(block+position3 , &rec1 , sizeof(Record) );
				nrecs++;
				position3+=sizeof(Record);
				store_pos+= sizeof(Record);
				memcpy(block+block_size - sizeof(int) , &store_pos , sizeof(int) );
				if( BF_WriteBlock( fd3[total_files] , bl3) < 0 ){ BF_PrintError("error while writing block"); return 0; }
				if( BF_ReadBlock(fd1, bl1 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
				if(position1 > block_size - 2*sizeof(Record)){
					// no space left in this block , search if there is another allocated block , if theres not just load the remaining records from the other file
					if( BF_ReadBlock(fd1, 0 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
					memcpy(&curr_blocks , block+block_size - sizeof(int) ,  sizeof(int) );
					if( curr_blocks > bl1 ){
						bl1++;
						if( BF_ReadBlock(fd1, bl1 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
						position1 = 0;
						memcpy( &rec1 , block+position1 , sizeof(Record) );
						capacity ++ ;
						position1+= sizeof(Record);
						continue;
					}else{
						// no more records in this file
						rec1.id = -1;
						if(skip) break;
						continue;
						}
				}
				memcpy( &rec1 , block+position1 , sizeof(Record) );
				position1+= sizeof(Record);
				capacity ++ ;
								if(rec1.id==0) { rec1.id = -1; if(skip) break; continue; }
			}else if(choose_rec==2 ){
				printf("%d %s %s %s\n",rec2.id , rec2.name , rec2.surname , rec2.city);
				if( BF_ReadBlock(fd3[total_files] , bl3 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
				memcpy(block+position3 , &rec2 , sizeof(Record) );
				nrecs++;
				position3+=sizeof(Record);
				store_pos+= sizeof(Record);
				memcpy(block+block_size - sizeof(int) , &store_pos , sizeof(int) );
				if( BF_WriteBlock( fd3[total_files] , bl3) < 0 ){ BF_PrintError("error while writing block"); return 0; }
				if( BF_ReadBlock(fd2, bl2 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
				if(position2 > block_size - 2*sizeof(Record)){
					// no space left in this block , search if there is another allocated block , if theres not just load the remaining records from the other file
					if( BF_ReadBlock(fd2, 0 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
					memcpy(&curr_blocks , block+block_size - sizeof(int) , sizeof(int) );
					if( curr_blocks > bl2 ){
						bl2++;
						if( BF_ReadBlock(fd2, bl2 , &block)< 0 ) {BF_PrintError("error while reading block"); return 0; }
						position2 = 0;
						memcpy( &rec2 , block+position2 , sizeof(Record) );
						capacity ++ ;
						position2+= sizeof(Record);
						continue;
					}else{
						// no more records in this file
						rec2.id = -1;
						continue;
					}
				}
				memcpy( &rec2 , block+position2 , sizeof(Record) );
				position2 += sizeof(Record) ;
				capacity++;
				if(rec2.id==0) { 		rec2.id = -1; if(skip) break; continue; }
			}
		}
		if(skip) break;
	}
	Sorted_CloseFile(fd3[total_files]);
	free(new_file);
	if(nrecs>= nor.num_recs) {
		printf("records:%d \n\n" ,nor.num_recs);
		return 1;
	}
//	printf("recs%d \n\n" , nrecs);
			return 2;
	}




int which_to_hold( Record rec1 ,  Record rec2 , int field ){
	if ( rec1.id == -1 && rec2.id == -1 ) {
		return 0;
	}
	if(rec1.id == -1 ) return 2;
	else if(rec2.id == -1 ) return 1;
	
//	printf("about to choose record id1:%d | id2:%d\n" , rec1.id , rec2.id);
	if(field==0){
		if( rec1.id < rec2.id )	return 1;
		else return 2;
	}else if(field==1){
		if( strcmp( rec1.name ,  rec2.name) < 0) return 1;
		else return 2;
		
	}else if(field==2){
		if( strcmp( rec1.surname ,  rec2.surname) < 0) return 1;
		else return 2;
		
	}else if(field==3){
		if( strcmp( rec1.city ,  rec2.city) < 0) return 1;
		else return 2;
	}
	return 0;
}
	
	
int blockfile_parsing(char *filename){
	void *block;
	int fd , is_sorted , total_blocks ;
	fd=BF_OpenFile(filename);
	if( BF_ReadBlock(fd, 0, &block)< 0 ) {BF_PrintError("error while reading block"); }
	memcpy(  &is_sorted , block ,sizeof(int));
	memcpy(  &total_blocks , block+block_size-sizeof(int) ,sizeof(int));
	Sorted_CloseFile(fd);
	if(is_sorted){ printf("type of file : sorted , name:%s , blocks:%d\n" , filename , total_blocks); return total_blocks ;}
	else return -1;
}
	



int Sorted_CheckSortedFile(char *filename , int field){
	Record rec1 , rec2 ;
	void *block;
	int i ,fd, total_blocks , position=0 ;
	total_blocks = blockfile_parsing(filename);
	fd=BF_OpenFile(filename);
	if(total_blocks == -1 ) { printf("wrong type of file \n" ); return -1; }

	
	
	for(i=1; i<=total_blocks; i++){
		if( BF_ReadBlock(fd, i, &block)< 0 ) {BF_PrintError("error while reading block"); }
		while(position< block_size - 2*sizeof(Record) ){
			memcpy(  &rec1 , block+position ,sizeof(Record));
			position+=sizeof(Record);
			memcpy(  &rec2, block+position ,sizeof(Record));
			position+=sizeof(Record);
			if( which_to_hold(  rec1 ,   rec2 ,  field ) == 2 ){
				printf("file not sorted properly\n" );
				return 0;
			}
		}
	}
	Sorted_CloseFile(fd);
	printf("file sorted properly\n\n\n");
	return 1;
}



void Sorted_GetallEntries( char *filename , int field , int id , char *val){
	Record rec1;
	void *block;
	int fd , i , total_blocks , position = 0;
	total_blocks = blockfile_parsing(filename);
	fd=BF_OpenFile(filename);
	for(i=1; i<=total_blocks; i++){
		if( BF_ReadBlock(fd, i, &block)< 0 ) {BF_PrintError("error while reading block"); }
		position = 0;
		while(position<= block_size - 2*sizeof(Record) ){
			memcpy(  &rec1 , block+position ,sizeof(Record));
			position+=sizeof(Record);
			if(field==0){
				if( rec1.id == id )	{ printf("found item with key_search:%d.  Record: %d %s %s %s \n" , id , rec1.id , rec1.name , rec1.surname , rec1.city); }
			}else if(field==1){
				if( !strcmp( rec1.name ,  val) )  { printf("found item with key_search : %s.  Record: %d %s %s %s \n" , val , rec1.id , rec1.name , rec1.surname , rec1.city); }
			}else if(field==2){
				if( !strcmp( rec1.surname ,  val) ) { printf("found item with key_search : %s .  Record: %d %s %s %s \n" , val , rec1.id , rec1.name , rec1.surname , rec1.city); }
			}else if(field==3){
				if( !strcmp( rec1.city , val) ) { printf("found item with key_search : %s.  Record: %d %s %s %s \n" , val , rec1.id , rec1.name , rec1.surname , rec1.city); }
			}
		}
	
	}
	
	Sorted_CloseFile(fd);
	}













