
run : 1) make
      2) ./prog -f 100.csv -i 0

Exoume ylopoihsei tis sunarthseis pou zhtountai + kapoies voh8htikes.

int sort_files( int *fd2 , int total_files  , Record *recs , int field , int m); Taxinomhsh arxeiwn twn opoiwn oi
											file descriptors einai apothikeumenoi sto fd2

int merge_files( int fd1 , int fd2 , int *fd3 , char *n1 , char *n2 ,  Record *recs , int field , int m  , int total); 
										  '' Enwsh'' 2 arxeiwn me file descriptors
											fd1 kai fd2 antistoixa.

int which_to_hold( Record rec1 ,Record rec2 , int field); Epistrofh timhs analoga me to pio record einai ''mikrotero'' 
								apto allo ( vash tou field )

int blockfile_parsing(char *); Anoigma arxeiou kai epistrofh tou sunolikou arithmou block pou periexei





Syrrakos Xrhstos 1115201100118
Agiannhs Iwannhs 1115200800032

