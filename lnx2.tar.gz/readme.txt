run : 1) make
      2) ./prog -f 100.csv -i 0

variemai na grapsw twra to readme :>
