#include "BF.h"
#include "records.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


int main(int argc, char** argv){
	FILE* fp ;  size_t len = 0;   ssize_t read;
	char * line = NULL;	char *token;
	Record record;
	HT_info *hptr;
	char *output;
	char input_file[256];	char filename[256] ;
    int  elements = 0 , i , field = 0 ;
	for(i=0;i<argc;i++){											// get name of input fiile
		if(strcmp(argv[i],"-f")==0){
				strcpy(input_file,argv[i+1]);
		}else if(strcmp(argv[i],"-i")==0){
			field = atoi(argv[i+1]);
			}
	}
	fp = fopen(input_file , "r");									// open and read the records from the file 
	if(fp==NULL){
		printf("invalid file given  , exiting\n");
		return -1;
	}
	BF_Init();
	strcpy(filename , "starting_file");
	HT_CreateIndex( filename);
	hptr = HT_OpenIndex(filename);
	int recs = 0;
	while ((read = getline(&line, &len, fp)) != -1) {
		token = strtok(line, ",");		
		record.id = atoi(token);		
	    token = strtok(NULL, ",");	
	    strcpy( record.name ,  token);
	    record.name[strlen(record.name)-1] = '\0';
	    memmove(record.name, record.name + 1, strlen(record.name));
	    token = strtok(NULL, ",");	
	    strcpy(record.surname , token);
	    memmove(record.surname, record.surname + 1, strlen(record.surname));
	    record.surname[strlen(record.surname)-1] = '\0';
	    token = strtok(NULL, "\n");	
	    strcpy(record.city , token);
	    record.city[strlen(record.city)-2] = '\0';
	    memmove(record.city, record.city + 1, strlen(record.city));
		elements++;
//		printf("%d %s %s %s \n" , record.id , record.name , record.surname , record.city  );
		HT_InsertEntry(hptr,  record);
		recs++;
	}
	Record record_end;
	record_end.id = -1;
	HT_InsertEntry(hptr,  record_end);
	printf("total recs : %d \n" , recs);
	nor.num_recs = recs;
	fclose(fp);
	output = Sorted_SortFile(filename , field);
	Sorted_CheckSortedFile(output , field);
	Sorted_GetallEntries( output ,  1 ,  0 , "Sung");
	HT_CloseIndex(  hptr );
	return 0;


}
