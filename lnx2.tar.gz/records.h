typedef struct Record {
	int id;
	char name[15];
	char surname[20];
	char city[25];
} Record;


typedef struct {
    int fileDesc;           /* αναγνωριστικός αριθμός ανοίγματος αρχείου από το επίπεδο block */ 
    char attrType;/* ο τύπος του πεδίου που είναι κλειδί για το συγκεκριμένο αρχείο, 'c' ή'i' */ 
    char* attrName;        /* το όνομα του πεδίου που είναι κλειδί για το συγκεκριμένο αρχείο */ 
    int attrLength;      /* το μέγεθος του πεδίου που είναι κλειδί για το συγκεκριμένο αρχείο */ 
} HT_info;

typedef struct{
	int num_recs;
	} Number_of_Records;

Number_of_Records nor;
/* functions used ( modified ) in previous excercise */ 
int HT_CreateIndex( char *fileName );
HT_info* HT_OpenIndex( char *fileName );        
int HT_CloseIndex( HT_info* header_info );                 
int HT_InsertEntry( HT_info *header_info , Record record); 


/* sorted functions */

int Sorted_CreateFile( char *fileName ) ;
int Sorted_OpenFile( char *fileName );
int Sorted_CloseFile( int fileDesc );
char* Sorted_SortFile( char *fileName, int fieldNo);
void Sorted_GetallEntries( char *filename , int field , int id , char *val);

Record* sort_records( Record *recs , int num , int field);
int sort_files( int *fd2 , int total_files  , Record *recs , int field , int m);
int merge_files( int fd1 , int fd2 , int *fd3 , char *n1 , char *n2 ,  Record *recs , int field , int m  , int total);
int which_to_hold( Record rec1 ,Record rec2 , int field);


int blockfile_parsing(char *);
int Sorted_CheckSortedFile(char *filename , int field);
