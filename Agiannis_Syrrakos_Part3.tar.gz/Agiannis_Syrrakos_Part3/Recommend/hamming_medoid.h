#ifndef HAMMING_MEDOID_H
#define HAMMING_MEDOID_H

#include <stdio.h>
#include <stdlib.h>
//#include <math.h>
#include <string.h>
#include "records.h"
#include "records_medoid.h"


void hamming2(char *path,int k,int L,char *output,int,int,int,int*);///////kuria sunartisi

///////sunartiseis gia ta initialize
centroids** concentrate_init(int **distance_matrix_hamming,int *line_total,double *v,entries **entries_array,int amount,data **data_array,int);
centroids** plus_init(int **distance_matrix_hamming,data **data_array,int amount,int);


////sunartiseis gia assign
void pam_assign(data **data_array,centroids **centroids_array,int amount,int);
void assign_LSH(int k,int L,int **tuxaioi,int mikos,int amount,char **inputs,char *output,data **data_array,int old_centroid_position,centroids **centroids_array,int);


////sunartiseis gia updates
void update_clarance(centroids **centroids_array,data **data_array,int amount,int k,int L,char **inputs,char *output,int** tuxaioi,int mikos,int,int fraction,int iterations,int );

void update_Lloyds(centroids **centroids_array,data** data_array,int amount,int k,int L,int ** tuxaioi,char **inputs,char *output,int mikos,int,int);


/////ulopoisi tou clara
void clara(int old_amount,centroids **centroids_array,data **data_array,int **distance_matrix_hamming,int);
void clara_update(data **data_array,centroids **centroids_array,int amount,int);

/////////evresi silhouette
int find_silhouett(data **data_array,int amount,FILE *);

//////voithitikes sunartiseis

int j_function(data **data_array,int amount);//////upologizei tin antikeimeni sunartisi
void centroid_sort(int *distances,centroids ** centroids_array,int first,int last);	//sortarei ta centroids mesa se ena data entry
int find_cluster_medoid(centroids *centroid,data** data_array,int amount,int old_centroid);////vriskei to medoid enos cluster
void create_query_hamming(centroids **centroids_array,char **inputs,int aktina,int);////dimioourgei arxeio me queries apo to centroids
int find_distance2(char *sto_hashtable,char *apexw,int mikos,int amount);////upologizei hamming apostaseis
void quicksort(entries **entries_array,int first,int last);////sortarei ena pinaka me entries
void init_data_array(int amount,data **data_array,entries **entries_array,int);////arxikopoiisi tou data array
int search(int D[1000],int new,int amount,int posa);////





#endif











