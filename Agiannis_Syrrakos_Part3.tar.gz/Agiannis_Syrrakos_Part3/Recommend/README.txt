﻿Part 3 στην Ανάπτυξη Λογισμικού για Αλγοριθμικά Προβλήματα

 Συρράκος Χρήστος  ΑΜ 1115201100118
 Αγιάννης Ιωάννης  ΑΜ 1115200800032

Το πρόγραμμα περιλαμβάνει τα αρχεία :

cosine_eucl.c		Η υλοποίηση των απαράιτητων συναρτήσεων για τις περιπτώσεις euclidean και cosine
hash.c			Υλοποίηση συναρτήσεων για την δημιουργία και γέμισμα του hashtable
Cstruct.c		Υλοποιηση συναρτήσεων για τη δημιουργία των αλγορίθμων τυχαίων αριθμών για τις περιπτώσεις euclidean και cosine και συναρτήσεις για τον υπολογισμό των R(u,i) για το Reccomendation
metric.c		Η υλοποίηση των απαράιτητων συναρτήσεων για τη περίπτωση matrix distances
hamming.c		Η υλοποίηση των απαράιτητων συναρτήσεων για τη περίπτωση hamming
functions.c		Υλοποίηση βοηθητικών συναρτήσεων για τις hamming,metric και hash
hash.h			Δήλωση συναρτήσεων που χρησημοποιούνται στο πρόγραμμα
records.h		Δήλωση δομών τους προγράμματος


hamming_medoid.c	Η υλοποίηση των συναρτήσεων στην περίπτωση που έχουμε σαν είσοδο dataset hamming. Εδώ υπάρχουν και συναρτήσεις
			που χρησιμοποιούνται σε ολόκληρο το πρόγραμμα για το clustering
hamming_medoid.h	Δήλωση των συναρτήσεων που υλοποιούνται στο hamming_medoid.c
matrix_medoid.c		Υλοποίηση συναρτήσεων  σε περίπτωση που έχουμε σαν είδοσο Distance Matrix. Σε αυτή τη κατηγορία καταλήγουμε 
			ακόμα και αν έχουμε άλλο είδος εισόδου(πχ euclidean)
matrix_medoid.h		Δήλωση των συναρτήσεων που υλοποιούνται στο matrix_medoid.c	
store_distances.c	Η υλοποίηση των συναρτήσεων στην περίπτωση που έχουμε σαν είσοδο vectors.
pare_header.h		Δήλωση των συναρτήσεων που υλοποιούνται στο store_distances.c
records_medoid.h	Δήλωση δομών για το centroids data κτλπ.


nnLSC.c 		Η main του προγράμματος. Αφού διαβάσει τα inputs φτιάχνει άλλα αρχεία και τα στέλνει στις συναρτήσεις (LSH,clustering) για να προκύψουν αποτελέσματα REccomendation.

	
Makefile

		


το πρόγραμμα μεταγλωτίζεται από το Makefile με ένα make ή με τη χρήση της εντολής 
gcc -o nnLSH nnLSH.c cosine_eucl.c hash.c Cstruct.c metric.c hamming.c functions.c hamming_medoid.c matrix_medoid.c store_distances.c -lm

και εκτελείται με την εντολή:
./lsh -d (datafile) - o (outputfile)
 τα files είτε να βρίσκονται στον ίδιο φάκελο με το εκτελέσιμο είτε να δίνεται το absolut path σε αυτά.
Για την επιλογή της μεθόδου υπάρχει μενού που ο χρήστης μπορεί να πληκτρολογέι (1/2/3) ανάλογα με τον συνδιασμό που θέλει να δεί.
Για το clustering χρησημοποιήθηκαν : 	-Initialization Park-Jun
					-Assigment PAM
					_Update a la Lloyds'
