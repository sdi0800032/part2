#ifndef HAMMING_MEDOID_C
#define HAMMING_MEDOID_C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "hash.h"
#include "records.h"
#include "records_medoid.h"
#include "matrix_medoid.h"
#include "hamming_medoid.h"

#define LINESZ 1024



/////vasiki sunartisi gia dedomena hamming
void hamming2(char *path,int k,int L,char *output,int clusters,int fraction,int iterations,int *val){


/////////kanoume init to hashtable pou 8a ams xreiastei argotera
	int j=0,mikos,i=0,o=0,z=0,bucket=0,aut=0,amount=0;
	char c;
	char buff[80];
	unsigned long long item1;
	char item[64],number[1000],gramma[50],gramma2[64],result[k];
	int **tuxaioi= malloc (sizeof (int*) * k);       //////////edw apothikeuontai oi tuxaioi arithmoi gia to hash
	for(i=0;i<k;i++){
		tuxaioi[i]=(int*)malloc(sizeof(int) * L);
	}
		
	char *token,*token2;

 	FILE* stream = fopen(path, "r");
	i=0;
	char *line;
	size_t len = 0;
	ssize_t read=0;
	read = getline(&line, &len, stream);
		token = strtok(line," \n\t");  //should use delimiter
		strcpy(gramma,token);
		token2 = strtok(NULL," \n\t");
		strcpy(gramma2,token2);

	while ((read = getline(&line, &len, stream)) != -1) {
		token = strtok(line," \n\t");  //should use delimiter
		strcpy(item,token);
		token2 = strtok(NULL," \n\t");
		strcpy(number,token2);
		mikos=strlen(number);	///// vriskoume poso megaloi einai oi arithmoi	
		amount++;   		///////kai to plithos tous
	}
	printf("mikos %d \n",mikos);
	printf("amount %d \n",amount);
	amount=1000;
	//mikos=1000;
	char **inputs;			///// edw apothikeuontai ta dedomena apo ta datasets
	inputs=malloc(sizeof(char*)*amount);
	for(i=0;i<amount;i++){
		inputs[i]=(char*)malloc(sizeof(char)*(mikos));
	}
	i=0;
	rewind(stream);
	char **onomata= malloc (sizeof (char*) * amount); ///////////ftiaxnoume ena pinaka me to onoma kathe entry gia na ektupwthei argotera

	for(i=0;i<amount;i++){
		
		onomata[i]=(char*)malloc(sizeof(char) * 100);
		memset(onomata[i], 0, sizeof onomata[i]);
	}
	read = getline(&line, &len, stream);
	o=0;
		while ((read = getline(&line, &len, stream)) != -1 && o<amount) {
		token = strtok(line," \n\t");  //should use delimiter
		strcpy(item,token);

		token2 = strtok(NULL," \n\t");
		strcpy(number,token2);	////diavazoume enan ena ta dedomena

			strcpy(inputs[o],number);
			strcpy(onomata[o],item);
			o++;
		}
		o=0;

	while(j<L){ 		//////////paragontai oi tuxaioi arithmoi
		while(i<k){
			int tuxaios=rand()%(mikos+1);
			//printf("tuxaios %d \n",tuxaios);
			tuxaioi[i][j]=tuxaios;
			i++;


		}
		i=0;
		j++;
	}
	i=0;
	j=0;


	printf("edw1 \n");
	fclose(stream);



//////////dimiourgoume ta data mas kai tous pinakes gia ta initialization
	
	int **distance_matrix_hamming=malloc(sizeof(int* )*amount);	
	for(i=0;i<amount;i++){
		distance_matrix_hamming[i]=malloc(sizeof(int)*amount);

	}
	int line_total[amount];
	int total_sum=0;
	double v[amount];	
	entries **entries_array=malloc(sizeof(entries*)*amount);
	
	for(i=0;i<amount;i++){
		entries_array[i]=malloc(sizeof(entries*));
		entries_array[i]->value=0;

	}
/////ftiaxnoume distance matrix apo tis apostaseis hamming
	for(i=0;i<amount;i++){
		line_total[i]=0;
		for(j=0;j<amount;j++){
			distance_matrix_hamming[i][j]=find_distance(inputs[i],inputs[j],mikos,amount);
			line_total[i]+=distance_matrix_hamming[i][j];
		}

		total_sum+=line_total[i];
	}
	double smallest=1;
	for(i=0;i<amount;i++){
		entries_array[i]->distances=distance_matrix_hamming[i];

	}
	data **data_array=malloc(sizeof(data*)*amount);
	init_data_array(amount,data_array,entries_array,clusters);
	int assigning=0;
	centroids **centroids_array=malloc(sizeof(centroids*)*clusters);

///////pame stin antistoixi periptwsi analoga me tis epiloges tou xristi
	clock_t begin = clock();
	FILE *out=fopen(output,"w");
	if(val[0]==1){
		centroids_array=plus_init(distance_matrix_hamming,data_array,amount,clusters);
		//fprintf(out,"K-medoids++-");
	}	
	else if(val[0]==2){
		centroids_array=concentrate_init(distance_matrix_hamming,line_total,v,entries_array,amount,data_array,clusters);
		//fprintf(out,"Park-Jun-");
	}
	if(val[1]==1){
		pam_assign(data_array,centroids_array,amount,clusters);
		 assigning=1;
		//fprintf(out,"PAM assignment-");
	}
	if(val[2]==1){
		update_Lloyds(centroids_array,data_array,amount,k,L,tuxaioi,inputs,output,mikos,clusters,assigning);
		//fprintf(out,"Updata a la Lloyds' \n");
	}




	int u,total=0,h,new_total=0;




	
	for(u=0;u<clusters;u++){
		for(i=0;i<amount;i++){
			if(data_array[i]->centroid_position==centroids_array[u]->position){
				centroids_array[u]->total++;
			}
		}
	}
	for(u=0;u<clusters;u++){
		printf("Cluster-%d { size: %d , medoid: %10s }\n",(u+1),centroids_array[u]->total,onomata[centroids_array[u]->position]); 
	}
	//printf("clustering time: %f \n",time_spent);
	//int silho=find_silhouett(data_array,amount,out);


	infos2 **infos_array=infos_init(amount,1000);
	int posa[clusters];
	for(i=0;i<clusters;i++){
		posa[i]=0;
	}

	int kati=0;
	for(i=0;i<amount;i++){
		strcpy(infos_array[i]->id,onomata[i]);
		for(j=0;j<amount;j++){
			if(data_array[i]->centroid_position==data_array[j]->centroid_position){

				infos_array[i]->apostaseis[kati]=distance_matrix_hamming[i][j];
				strcpy(infos_array[i]->found[kati],onomata[j]);
				//printf("kata %s \n",infos_array[i]->found[kati]);
				kati++;
			}
		}
		kati=0;
	}	
	int posas=0;
	fprintf(out,"Algorithm: Hamming Clustering\n");
	for(posas=0;posas<amount;posas++){
		int posotis=0;
		fprintf(out,"User %d Recommending: ",posas+1);
		for(o=0;o<4;o++){
			if(data_array[posas]->centroid_position==centroids_array[o]->position){
				posotis=centroids_array[o]->total;
			}
		}
		recommend *recom=malloc(sizeof(recommend)*amount);
		float z=find_z(infos_array,posas,posotis);
		int that=0,best_pos=0;
		float sunolo=0,best=0;
		for(that=0;that<amount;that++){
			float olo=find_rest3(infos_array,posas,that,inputs,posotis);
			sunolo=olo*z;
			recom[that].olo=sunolo;
			recom[that].position=that;
			if(sunolo>best){
				best=sunolo;
				best_pos=that;
			}
		}
		//printf(" BEST %f best pos %d \n",best,best_pos);
		quicksort5(recom,0,amount);
		int i=0;
		for(i=0;i<5;i++){
			fprintf(out,"item%d ",recom[i].position);
		}
		fprintf(out,"\n");
	}	
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	fprintf(out,"Execution time: %f \n",time_spent);
	fclose(out);

	//fclose(edw);


/*	for(i=0;i<k;i++){
		free(tuxaioi[i]);
	}
	free(tuxaioi);
	for(i=0;i<amount;i++){
		free(inputs[i]);
	}
	free(inputs);*/
}

///////vriskei hamming apostaseis

int find_distance2(char *sto_hashtable,char *apexw,int mikos,int amount){
	int i=0;
	int distance=0;
	for(i=0;i<amount;i++){
		if(sto_hashtable[i]!=apexw[i]){
			distance++;
		}

	}
	return distance;



}

//////sort ena pinaka me entries gia na kanoume ta init

void quicksort(entries **entries_array,int first,int last){
 	int pivot,j,i;
	entries **Array,*tmp;		
	Array=entries_array;
	if(first<last){
        	pivot=first;
        	i=first;
        	j=last;
        	while(i<j){
                	while(Array[i]->value<=Array[pivot]->value && i<last)
                 		i++;
             		while(Array[j]->value>Array[pivot]->value)
                 		j--;
             		if(i<j){
                 		tmp = Array[i];                 
				Array[i] = Array[j];			
				Array[j] = tmp;			 
            			}
         		}
			tmp=Array[pivot];
         		Array[pivot]=Array[j];
			Array[j] = tmp;	
         		quicksort(Array,first,j-1);
         		quicksort(Array,j+1,last);
	}
}

//////arxikopoiisi tou array me ta vasika mas dedomena

void init_data_array(int amount,data **data_array,entries **entries_array,int clusters){
	int i=0,j;	
	for(i=0;i<amount;i++){
		//printf(" data %d \n",i);
		data_array[i]=malloc(sizeof(data));
		data_array[i]->distance_from_centroid=100;
		data_array[i]->centroid_position=0;
		data_array[i]->distance_from_2nd_centroid=50;
		data_array[i]->second_centroid_position=0;
		data_array[i]->distances=entries_array[i]->distances;
		data_array[i]->has_been_centroid=0;
		data_array[i]->which_centroid=-1;
		data_array[i]->is_centroid=0;
		data_array[i]->position=i;
		data_array[i]->centroids_for_data=malloc(sizeof(centroids*)*clusters);
		for(j=0;j<clusters;j++){
			data_array[i]->centroids_for_data[j]=malloc(sizeof(centroids*));

		}
	}
	
}



/////////PArk-Jun init

centroids** concentrate_init(int **distance_matrix_hamming,int *line_total,double *v,entries **entries_array,int amount,data **data_array,int clusters){

	double smallest=1;
	int i,j;
	for(i=0;i<amount;i++){
		for(j=0;j<amount;j++){

			if(line_total[j]==0)
				line_total[j]=7500;
			//printf("line total %d j %d ",line_total[j],j);
			//printf("apostaseis %d i=%d j=%d \n",distance_matrix_hamming[i][j],i,j);
			v[i]=(double)distance_matrix_hamming[i][j]/(double)line_total[j];
			entries_array[i]->value+=(double)distance_matrix_hamming[i][j]/(double)line_total[j];
			
		}	
		//printf(" entries_array[i]->value %f i %d \n", entries_array[i]->value,i);
		entries_array[i]->position=i;
		entries_array[i]->distances=distance_matrix_hamming[i];
		if(entries_array[i]->value<smallest){
			smallest=entries_array[i]->value;
		}
	}
	quicksort(entries_array,0,(amount-1));
	centroids **centroids_array=malloc(sizeof(centroids*)*clusters);
	for(i=0;i<clusters;i++){
		centroids_array[i]=malloc(sizeof(centroids));
		centroids_array[i]->value=entries_array[i]->value;
		centroids_array[i]->position=entries_array[i]->position;
		centroids_array[i]->distances=entries_array[i]->distances;
		centroids_array[i]->sum_distances=0;
		centroids_array[i]->total=0;
		data_array[centroids_array[i]->position]->is_centroid=1;
		//printf("after %.15f \n",centroids_array[i]->value);
		//printf("position %d \n",centroids_array[i]->position);
	}
	//printf("smallest %.15f amount %d \n",smallest,amount);
	return centroids_array;
}

////////// ++ init
centroids** plus_init(int **distance_matrix_hamming,data **data_array,int amount,int clusters){
	int first=rand()%(amount);
	int sum=0,i,posa=0;
	int D[amount];
	centroids **centroids_array=malloc(sizeof(centroids*)*clusters);
	for(i=0;i<clusters;i++){
		centroids_array[i]=malloc(sizeof(centroids));
		centroids_array[i]->total=0;
	}
	centroids_array[0]->position=first;
	centroids_array[0]->distances=distance_matrix_hamming[centroids_array[0]->position];
	centroids_array[0]->sum_distances=0;
	data_array[centroids_array[0]->position]->is_centroid=1;
	D[0]=distance_matrix_hamming[centroids_array[0]->position][0]*distance_matrix_hamming[centroids_array[0]->position][0];
	for(i=0;i<amount;i++){
		data_array[i]->centroid_position=centroids_array[0]->position;
		data_array[i]->distance_from_centroid=distance_matrix_hamming[i][centroids_array[0]->position];
		sum+=data_array[i]->distance_from_centroid;
		centroids_array[0]->sum_distances+=data_array[i]->distance_from_centroid;
		data_array[i]->which_centroid=0;
		if(i>0)
			D[i]=D[i-1]+data_array[i]->distance_from_centroid*data_array[i]->distance_from_centroid;
	}
	posa++;
	int u=1;
	while(posa<clusters){
		int new=rand()%sum;
/////////vriskoume se poia thesi tou pinaka einai o tuxaios arithmos pou dialexame
		int where=search(D,new,amount,posa);
		centroids_array[u]->position=where;
		centroids_array[u]->distances=distance_matrix_hamming[centroids_array[u]->position];
		centroids_array[u]->sum_distances=0;
		for(i=0;i<amount;i++){
			if(data_array[i]->distance_from_centroid>distance_matrix_hamming[i][centroids_array[u]->position]){
				centroids_array[data_array[i]->which_centroid]->sum_distances-=data_array[i]->distance_from_centroid;
				data_array[i]->centroid_position=centroids_array[u]->position;
				data_array[i]->distance_from_centroid=distance_matrix_hamming[i][centroids_array[u]->position];
				centroids_array[u]->sum_distances+=data_array[i]->distance_from_centroid;
			}
///////meiwnoume to megethos tou pinaka pou exoume ftiaxei gia na vroume ta centroids me tin pithanotia pou theloume 
/////// giati idi exoume parei ena
			D[0]=data_array[0]->distance_from_centroid*data_array[0]->distance_from_centroid;
			if(i>0)
				D[i]=D[i-1]+data_array[i]->distance_from_centroid*data_array[i]->distance_from_centroid;
			
		}
		sum=D[amount-posa];
		u++;
		posa++;

	}
	return centroids_array;
}

///////vriskoume anamesa se poies 8eseis tou pinaka vrisketai mia timi pou psaxnoume

int search(int D[5400],int new,int amount,int posa){
	int i;
	for(i=0;i<(amount-posa);i++){
		if(new>D[i] && new<=D[i+1]){
			return i;
		}
	}


}



///////vriskoume to medoid enos cluster
int find_cluster_medoid(centroids *centroid,data** data_array,int amount,int old_centroid){
	int i,j,u;
	int old_distances=0,new_distances=0;
	for(i=0;i<amount;i++){
		if(data_array[i]->centroid_position==centroid->position){
			old_distances+=data_array[i]->distance_from_centroid;
		}
	}
	for(i=0;i<amount;i++){
		if(data_array[i]->centroid_position==centroid->position){
			for(j=0;j<amount;j++){
				if(data_array[j]->centroid_position==centroid->position){
					new_distances+=data_array[j]->distances[i];
				}
			}
		}
		//printf("old %d new %d \n",old_distances,new_distances);
		if(new_distances<old_distances && new_distances!=0){
			for(u=0;u<amount;u++){
		//printf("centroid TOU DATA %d amount %d \n",data_array[u]->centroid_position,amount); 
			if(data_array[u]->centroid_position==old_centroid){
				data_array[u]->centroid_position=0;
				data_array[u]->distance_from_centroid=0;
			}

			}
			centroid->position=i;
			centroid->sum_distances=new_distances;
			centroid->distances=data_array[i]->distances;
			old_distances=new_distances;
		}
	
	new_distances=0;
	}

	return centroid->position;	

}




////////kanei sort ta centroids gia to kathe data kai to kanei assign sto kontinotero
void pam_assign(data **data_array,centroids **centroids_array,int amount,int clusters){
	int i,u;
	for(i=0;i<amount;i++){
		data_array[i]->centroids_for_data=centroids_array;
		for(u=0;u<clusters;u++){
			data_array[i]->centroids_for_data[u]=centroids_array[u];		


		}
		centroid_sort(data_array[i]->distances,data_array[i]->centroids_for_data,0,(clusters-1));
		//printf("pam %d \n",i); 
		data_array[i]->centroid_position=data_array[i]->centroids_for_data[0]->position;
		data_array[i]->distance_from_centroid=data_array[i]->distances[data_array[i]->centroids_for_data[0]->position];
		data_array[i]->second_centroid_position=data_array[i]->centroids_for_data[1]->position;
		data_array[i]->distance_from_2nd_centroid=data_array[i]->distances[data_array[i]->centroids_for_data[1]->position];
	}	



}

///////kanei sort ston pinaka me centroids gia to kathe data
void centroid_sort(int *distances,centroids ** centroids_array,int first,int last){
 	int pivot,j,i;
	centroids **Array,*tmp;		
	Array=centroids_array;
	if(first<last){
        	pivot=first;
        	i=first;
        	j=last;
        	while(i<j){
                	while(distances[Array[i]->position]<=distances[Array[pivot]->position] && i<last)
                 		i++;
             		while(distances[Array[j]->position]>distances[Array[pivot]->position])
                 		j--;
             		if(i<j){
                 		tmp = Array[i];                 
				Array[i] = Array[j];			
				Array[j] = tmp;			 
            			}
         		}
			tmp=Array[pivot];
         		Array[pivot]=Array[j];
			Array[j] = tmp;	
         		centroid_sort(distances,Array,first,j-1);
         		centroid_sort(distances,Array,j+1,last);
	}
}

/////////vriskei to  medoid enos cluster kai to kanei centroid
/////// an xanatrexoume kai vroume pali to idio medoid tote paei sto epomeno 
void update_Lloyds(centroids **centroids_array,data** data_array,int amount,int k,int L,int ** tuxaioi,char **inputs,char *output,int mikos,int clusters,int assigning){

	int i=0;
	while(i<clusters){
		int old_centroid=centroids_array[i]->position;
		int something=find_cluster_medoid(centroids_array[i],data_array,amount,old_centroid);
		//printf("KAINOURGIO %d \n",centroids_array[i]->position);
		if(assigning==1){
			pam_assign(data_array,centroids_array,amount,clusters);
		}
		if(old_centroid==centroids_array[i]->position && i<5){
			i++;
		}

	}

}


int j_function(data **data_array,int amount){
	int i,sum=0;
	for(i=0;i<amount;i++){
		sum+=data_array[i]->distance_from_centroid;

	}
	return sum;

}

//////vriskoume to silhouette xrisimopoiwntas tin apostasi apo to centroid kai apo to deutero kontinotero centroid tou kathe entry
int find_silhouett(data **data_array,int amount,FILE *out){
	float *a=malloc(sizeof(int)*amount);
	float *b=malloc(sizeof(int)*amount);
	float *silhouett=malloc(sizeof(int)*amount);
	float total_sil=0;
	int i,j;
	int count=0,count2=0;
	int max=0;
	fprintf(out,"Silhouette : [");
	for(i=0;i<amount;i++){
		for(j=0;j<amount;j++){
			if(data_array[i]->centroid_position==data_array[j]->centroid_position){
				a[i]+=data_array[i]->distances[j];

				count++;

			}
			if(data_array[i]->second_centroid_position==data_array[j]->second_centroid_position){
				b[i]+=data_array[i]->distances[j];
				count2++;
			}
		}
		a[i]=a[i]/count;
		b[i]=b[i]/count2;
		//printf("a[] %f b[] %f \n",a[i],b[i]);
		if(a[i]>max){
			max=a[i];
			if(b[i]>max){
				max=b[i];
			}
		}
		if(b[i]>max){
			max=b[i];
			if(a[i]>max){
				max=a[i];
			}
		}
		silhouett[i]=(b[i]-a[i])/max;

		//fprintf(out," %f , ",silhouett[i]);
		total_sil+=silhouett[i];

		count=0,count2=0;
	}
	fprintf(out,"AVERAGE: %f ] \n",(total_sil/amount));
	return total_sil;


}




#endif  
