#ifndef nnLSH_C
#define nnLSH_C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "hash.h"
#include "records.h"
#include <math.h>
#include "records_medoid.h"
#include "matrix_medoid.h"
#include "hamming_medoid.h"
#include "pareheader.h"
#define LINESZ 1024

void create_query(char **total_marks,char *path,int radius,int summ);
void create_query_clid(double **euclid,char *path,int radius,int total,int summ);

int main(int argc, char** argv){

	char path[256],output[256];
	char *line;
	size_t len = 0;
	ssize_t read=0;
	char marks[5400];
	int items1[5400];
	int i=0,summ=0;
	double average[5400];
	for(i=0;i<argc;i++){
		if(strcmp(argv[i],"-d")==0){
				strcpy(path,argv[i+1]);
				printf("%s\n",path);
		}
		if(strcmp(argv[i],"-o")==0){
				strcpy(output,argv[i+1]);
				printf("%s\n",output);
		}
	}
	FILE *yahoo=fopen(path,"r");
	for(i=0;i<5400;i++){
		average[i]=0;
	}
	for(i=0;i<5400;i++){
		marks[i]='0';
		items1[i]=0;
	}
	int user=0,item=0,mark=0,old_user=0,total=0,pos=0,count=0;
	while ((read = getline(&line, &len, yahoo)) != -1) {
		//sscanf(	line,"%d %d %d  ",&user,&item,&mark);
		char *token = strtok(line," \n\t");  //should use delimiter
		user=atoi(token);
		char *token2 = strtok(NULL," \n\t");
		item=atoi(token2);
		char *token3 = strtok(NULL," \n\t");
		mark=atoi(token3);;
		if(mark>0 && user==1){
			marks[item-1]='1';

		}
		average[total]+=mark;
		count++;
		int flag=0;
		for(i=0;i<5400;i++){
			if(items1[i]==item)
			{
				flag=1;
				//pos=i;
			}
		}
		if(flag==0){
			items1[pos]=item;	
			summ++;
			pos++; 
		}
		if(user!=old_user){
			average[total]-=mark;
			average[total]=average[total]/(count-1);
			count=1;
			total++;
			average[total]+=mark;
			old_user=user;
		}
		

	}
	average[total]=average[total]/count;



	//printf("total %d count %d \n ",total,count);
	//printf(" summ %d \n",summ);
	int total_items[total];
	for(i=1;i<=total;i++){
		total_items[i]=i;
		//printf("i %d  average %f  \n",i,average[i]);
	}
	rewind(yahoo);
	int j=0;

	double **euclid=malloc(sizeof(double*)*total);
	char **total_marks=malloc(sizeof(char*)*total);
	for(i=0;i<total;i++){
		total_marks[i]=malloc(sizeof(char)*(summ+1));
		euclid[i]=malloc(sizeof(double)*(summ));
		for(j=0;j<summ;j++){
			total_marks[i][j]='0';
			euclid[i][j]=0;
		}
		total_marks[i][summ]='\0';
	}
	int counter=0;
	user=1;old_user=1;
	while ((read = getline(&line, &len, yahoo)) != -1) {
		sscanf(	line,"%d %d %d  ",&user,&item,&mark);
		if(mark>0){
			total_marks[counter][item-1]='1';
			euclid[counter][item-1]=mark-average[counter];
		}

		if(user!=old_user){
			old_user=user;
			counter++;
		}

	}
	fclose(yahoo);
	FILE *out=fopen("hamming.txt","w");
	FILE *clid=fopen("euclidean.txt","w");
	fprintf(out,"@metric_space hamming\n");
	//fprintf(clid,"@metric_space euclidean \n@metric euclidean\n");
	for(i=0;i<total;i++){
		fprintf(out,"item%d \t",i+1);

		fprintf(out,"%s \n",total_marks[i]);

	}
	for(i=1;i<1001;i++){
		fprintf(clid,"item%d \t",i);
		for(j=0;j<1000;j++){
			fprintf(clid," %f \t ",euclid[i][j]);
		}
					fprintf(clid,"  \n");
	}
	fclose(out);
	fclose(clid);
	int val[3];  ///////ftiaxnoume to menu me tis epiloges
	val[0]=2;val[1]=1;val[2]=1;
	char *answer;
	answer = malloc(sizeof(char)*10);
	printf("Type the method you want to implement: \n 1.Hamming LSH \n 2.Hamming Clustering \n 3.Euclidean/Cosine Clustering \n");
	scanf("%s", answer);
	if(!strcmp(answer,"1")){
		create_query(total_marks,"query.txt",200,total);
		hamming("hamming.txt",9,3,"query.txt",output,total_marks);
	}
	//create_query_clid(euclid,"query_eucl.txt",20,total,summ);
	//cosine_eucl("euclidean.txt","query_eucl.txt", "edw2.txt", 5  ,2 ,euclid );

	if(!strcmp(answer,"2")){
		hamming2("hamming.txt",4,5,output,4,400,2,val);
	}
	if(!strcmp(answer,"3")){
		cos_items_ptr items;
		items= store_vectors( "euclidean.txt", NULL , NULL , 0 );
		//printf("arxi total %d \n",items->total_dimensions);
		char *filename = store_distances( items, items->current_items); 
		matrix2(filename,4,5,output,4,400,2,val,items);
	}
}


void create_query(char **total_marks,char *path,int radius,int summ){
	FILE *out=fopen(path,"w");
	int i=0;
	fprintf(out,"Radius %d\n",radius);
	for(i=0;i<100;i++){
		fprintf(out,"item_idS%d \t",i+1);
		fprintf(out,"%s \n",total_marks[i]);

	}
	fclose(out);



}

void create_query_clid(double **euclid,char *path,int radius,int total,int summ){
	FILE *out=fopen(path,"w");
	int i=0,j=0;
	fprintf(out,"Radius: %d\n",radius);
	for(i=1;i<10;i++){
		fprintf(out,"item_idS%d \t",i);
		for(j=0;j<summ;j++){
			fprintf(out," %f \t ",euclid[i][j]);
		}
					fprintf(out,"  \n ");
	}
	fclose(out);



}

#endif
