#ifndef HAMMING_C
#define HAMMING_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "hash.h"
#include "records.h"
#include "records_medoid.h"
#include "matrix_medoid.h"
//#include <math.h>
#define LINESZ 1024




/////////////////voithaei stin metatropi apo duadiko se dekadiko
/*int Pow(int p){

	int i;
	int x=1;
	if(p == 0)
		return 1;
	else{
		for(i=0;i<p;i++)
			x = x*2;
	}
	return x;

}*/


void hamming(char *path,int k,int L,char *query,char *output,char **total_marks){

	int j=0,mikos,i=0,o=0,z=0,bucket=0,aut=0,amount=0;
	char c;
	char buff[80];
	unsigned long long item1;
	char item[64],number[1000],gramma[50],gramma2[1000],result[k];
	int **tuxaioi= malloc (sizeof (int*) * k);       //////////edw apothikeuontai oi tuxaioi arithmoi gia to hash
	for(i=0;i<k;i++){
		tuxaioi[i]=(int*)malloc(sizeof(int) * L);
	}
		
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

 	FILE* stream = fopen(path, "r");

	i=0;
	//fscanf(stream,"%s %s ",gramma,gramma2);
	//printf("%s  \n", gramma2);

	    read = getline(&line, &len, stream);
	for(i=0;i<5400;i++){
	   read = getline(&line, &len, stream);
		//sscanf(buff,"%s %s",item,number);
		char *token = strtok(line," \n\t");  //should use delimiter
		strcpy(item,token);
		char *token2 = strtok(NULL," \n\t");
		strcpy(number,token2);
		mikos=strlen(number);	///// vriskoume poso megaloi einai oi arithmoi	
		amount++;   		///////kai to plithos tous
	}
	
	printf("mikos %d \n",mikos);
	printf("amount %d \n",amount);
	char **inputs;			///// edw apothikeuontai ta dedomena apo ta datasets
	inputs=malloc(sizeof(char*)*amount);
	for(i=0;i<amount;i++){
		inputs[i]=(char*)malloc(sizeof(char)*mikos);
	}
	i=0;
	rewind(stream);
	while(j<L){ 		//////////paragontai oi tuxaioi arithmoi
		while(i<k){
			int tuxaios=rand()%(mikos+1);
			tuxaioi[i][j]=tuxaios;
			i++;


		}
		i=0;
		j++;
	}
	i=0;
	j=0;


	memset(result, 0, sizeof result);
	 read = getline(&line, &len, stream);
	initHashtable(1000,L);		/////arxikopoiisi hashtable
	for(o=0;o<amount;o++){
		if (amount==5400){		////diavazoume enan ena ta dedomena
			read = getline(&line, &len, stream);
		char *token = strtok(line," \n\t");  //should use delimiter
		strcpy(item,token);
		char *token2 = strtok(NULL," \n\t");
		strcpy(number,token2);
			number_ptr noumero=malloc(sizeof(number_ptr));
			noumero->name= malloc(sizeof(char) * 1000);
			noumero->id= malloc(sizeof(char) * 100);
			strcpy(inputs[o],total_marks[o]);
			strcpy(noumero->name,total_marks[o]);
			strcpy(noumero->id,item);
			noumero->position=o;
			while(j<L){
			bucket=hamming_hash(k,L,number,tuxaioi,j);		/////kaloume ti sunartisi pou epistrefei se poio bucket prepei na mpei kathe entry
			//printf("bucket %d \n",bucket);
			bucketentry1( noumero , bucket ,j);		///// vazoume to entry sto antistoixo bucket
						
			//printf("edw j %d \n",j);
			j++;
			}
		}
	j=0;
	}
	
	
////// afou diavasame ola ta dedomena kaloume ti sunartisi pou dexetai ta queries
	hamming_Search(query,k,L,tuxaioi,mikos,amount,inputs,output);
/*
	for(i=0;i<k;i++){
		free(tuxaioi[i]);
	}
	free(tuxaioi);
	for(i=0;i<amount;i++){
		free(inputs[i]);
	}
	free(inputs);*/
}

//////////Kanei to hash kai epistrefei to keli sto opoio prepei na mpei o kathe arithmos

int hamming_hash(int k,int L,char number[1000],int **tuxaioi,int j){
	char *result=malloc(sizeof(char)*k);
//////// ftiaxnoume enan pinaka me ta tuxaia psifia tou arithmou pou epilexame nwritera gia kathe diaforetiko L
///// metatrepoume meta ton pinaka auton pou einai mia anaparastasi k duadikwn psifiwn se dekadiko arithmo
//// gia na exoume to bucket pou psaxnoume
	int i=0,aut=0,bucket=0;
	memset(result, 0, sizeof result+1);
		while(i<k){	

			result[i]=number[1000-tuxaioi[i][j]-1];
			aut=atoi(&result[i]);
			bucket=bucket+aut*Pow(k-i-1);
			i++;
		};
		i=0;
		
	//printf("result %s \n",result);
	free(result);
	return bucket;

}


/////////analamvanei na vrei ta entries pou einai sto idio bucket me auto pou dinetai apo to query
/////// kai upologizei ta kontina se auto me vasi tin aktina
////// kathws kai to kontinotero kai tin apostasi tou

void hamming_Search(char *query,int k,int L,int **tuxaioi,int mikos,int amount,char **inputs,char *output){
	FILE* stream = fopen(query, "r");
	FILE* out = fopen(output, "w");
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
	int posa=0;
	int **ektupwmena= malloc (sizeof (int*) * 5400);		///////enas pinakas pou voi8aei na doume an kapoios kontinos exei idi ektupwthei
	int a=0,b=0;									////// apotrepei to na ektupwnoume polles fores to idio entry se diaforeiko hashtable L 
	for(a=0;a<5400;a++){
		ektupwmena[a]=(int*)malloc(sizeof(int) * amount);
		for(b=0;b<amount;b++){
			ektupwmena[a][b]=0;
		}
	}		

	char gramma[1000];
	int aktina;
	char number[1000];
	int query_counter=0;
	read = getline(&line, &len, stream);
	char *token = strtok(line," \n\t");  //should use delimiter
	strcpy(gramma,token);
	char *token2 = strtok(NULL," \n\t");
	aktina=atoi(token2);
	//fprintf(out,"%s ", gramma);
	//fprintf(out,"%d  \n", aktina);
	int much=0;
	infos2 **infos_array=infos_init(100,30);
			clock_t begin_hash = clock(); //// arxi tou clock gia to LSH
	while(	getline(&line, &len, stream)!=EOF){

			char *token3 = strtok(line," \n\t");  //should use delimiter
			strcpy(gramma,token3);
			char *token4 = strtok(NULL," \n\t");
			strcpy(number,token4);			

			strcpy(infos_array[much]->id,gramma);
			//fprintf(out,"\nQuery: %s  \t", gramma);
			//fprintf(out,"%s \n R=%d-near neighbours: \n", number,aktina);
			int j=0;
			int i=0;
			int lowest_distance=1000;		/////arxikopoioime to distance me kati pou sigoura 8a vroume mikrotero tou
			char nearest[1000];	

				
			
			for(j=0;j<L;j++){
				int true_distance=0;
///////// vriskoume to bucket pou antistoixei sto query
				int bucket=hamming_hash(k,L,number,tuxaioi,j);
				//printf("bucket count %d \n",bucket);
////// diatrexoume olo to bucket sto opoio 8a pigaine to query
				if(BucketArray[j][bucket]->count>0){
					for(i=0;i<BucketArray[j][bucket]->count;i++){
						//printf("sto hash %s \n",BucketArray[j][bucket]->bucketarray[i].n_ptr->name);
						true_distance=find_distance(BucketArray[j][bucket]->bucketarray[i].n_ptr->name,number,mikos,amount);
						if(true_distance<=(aktina)){	
							if(ektupwmena[query_counter][BucketArray[j][bucket]->bucketarray[i].n_ptr->position]==0){
								ektupwmena[query_counter][BucketArray[j][bucket]->bucketarray[i].n_ptr->position]=1;
			///////////elegxoume an exei xanaektupw8ei auto to entry		
								if (posa<10){

									//fprintf(out," %s \n ",BucketArray[j][bucket]->bucketarray[i].n_ptr->id);
									infos_array[much]->apostaseis[j*10+posa]=true_distance;	
									strcpy(infos_array[much]->found[j*10+posa],BucketArray[j][bucket]->bucketarray[i].n_ptr->id);	
									posa++;
								}					
							}
						//printf("-----true distance %d \n ",true_distance);
						}
////////// vriskoume ti mikroteri apostasi kai kratame to id tou entry
						if(true_distance<lowest_distance){
							lowest_distance=true_distance;
							strcpy(nearest,BucketArray[j][bucket]->bucketarray[i].n_ptr->id);
						}					
					}
				}

				posa=0;

			}
	
			//fprintf(out,"Nearest Neighbour: %s \n ",nearest);
			//fprintf(out,"distanceLSH:%d \n ",lowest_distance);
			clock_t begin_normal = clock(); ////arxi clock gia kanoniko scanning
			int normal_distance= find_normal_distance(inputs,number,mikos,amount);  //////sunartisi upologismou apostasis
			clock_t end_normal = clock();
			double time_spent_normal = (double)(end_normal - begin_normal) / CLOCKS_PER_SEC;
			//fprintf(out,"distanceTRUE : %d \n ",normal_distance);

			//fprintf(out,"tTrue: %f \n",time_spent_normal);

			query_counter++;
			much++;
	}
	fprintf(out,"Algorithm: LSH Hamming\n");
	int posas=0;
	for(posas=0;posas<100;posas++){
		fprintf(out,"User %d Recommending: ",posas+1);
		recommend *recom=malloc(sizeof(recommend)*1000);
		float z=find_z(infos_array,posas,L*10);
		int that=0,best_pos=0;
		float sunolo=0,best=0;
		for(that=0;that<1000;that++){
			float olo=find_rest(infos_array,posas,that,inputs,L*10);
			sunolo=olo*z;
			recom[that].olo=sunolo;
			recom[that].position=that;
			if(sunolo>best){
				best=sunolo;
				best_pos=that;
			}
		}
		//printf(" BEST %f best pos %d \n",best,best_pos);
		quicksort5(recom,0,1000);
		int i=0;
		for(i=0;i<5;i++){
			fprintf(out,"item%d ",recom[i].position);
		}
		fprintf(out,"\n");
	}
	clock_t end_hash = clock();   /////telos tou clock tou LSH
	double time_spent = (double)(end_hash - begin_hash) / CLOCKS_PER_SEC;	
	fprintf(out,"Execution time: %f \n",time_spent);
	for(a=0;a<100;a++){
		free(ektupwmena[a]);
	}
	free(ektupwmena);

}

///////upologizei ti mikroteri apostasi metaxu tou query kai olwn twn stoixeiwn tou dataset


int find_normal_distance(char **inputs,char *number,int mikos,int amount){
	int i=0,j=0;
	int distance=0;
	int smallest_distance=3000;
	for(j=0;j<amount;j++){
	for(i=0;i<mikos;i++){
		if(inputs[j][i]!=number[i]){
			distance++;
		}

	}
	if(distance<smallest_distance){
		smallest_distance=distance;
	}
	distance=0;
	}
	return smallest_distance;


}

////////////upologizei tin apostasi tou query me ena entry tou hashtable

int find_distance(char *sto_hashtable,char *apexw,int mikos,int amount){
	int i=0;
	int distance=0;
	for(i=0;i<1000;i++){
		if(sto_hashtable[i]!=apexw[i]){
			distance++;
		}

	}
	return distance;



}





#endif  /* HAMMING_C */
