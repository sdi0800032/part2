#ifndef HAMMING_MEDOID_C
#define HAMMING_MEDOID_C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "hash.h"
#include "records.h"
#include "records_medoid.h"
#include "matrix_medoid.h"
#include "hamming_medoid.h"
#include "pareheader.h"
//#include "lin.c"
#define LINESZ 1024



void matrix2(char* path,int k,int L,char *output,int clusters,int fraction,int iteration,int *val,cos_items_ptr items){



 	FILE* stream = fopen(path, "r");
	int i=0,j=0;
	char buff[3000];
	char gramma[50],gramma2[50],item[3000],number[3000];
	fscanf(stream,"%s %s ",gramma,gramma2);
	printf("%s  \n", gramma2);
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
	int count=0;

    read = getline(&line, &len, stream);

    //printf("%s", line);
    read = getline(&line, &len, stream);
    //printf("Retrieved line of length %zu :\n", read);
 
	char *token = strtok(line," \n\t");  ////metrame to plithos apostasew kathe stoixeiou
	while( token != NULL && count<1000) 
	{
		count++;
		int d = atoi(token);
		token = strtok(NULL," \n\t");
	}
	//printf("count %d\n",count);

	int **pinakas= malloc (sizeof (int*) * count); //////edw apothikeuontai ola ta dedomena apo to dataset
	for(i=0;i<count;i++){
		pinakas[i]=(int*)malloc(sizeof(int) * count);
	}
	i=0;
	rewind(stream);

    read = getline(&line, &len, stream);
    read = getline(&line, &len, stream);
	char **onomata= malloc (sizeof (char*) * count); ///////////ftiaxnoume ena pinaka me to onoma kathe entry gia na ektupwthei argotera

	for(i=0;i<count;i++){
		onomata[i]=(char*)malloc(sizeof(char) * 64);
		memset(onomata[i], 0, sizeof onomata[i]);
	}
	i=0;
	while(    read = getline(&line, &len, stream)!=0 && i<count){
       //printf("Retrieved line of length %zu :\n", read);
        //printf("%s", line);
		char noumero[6];
		strcat(onomata[i],"item");
		sprintf(noumero,"%d",i);
		strcat(onomata[i],noumero);

		char *token = strtok(line," \n\t");  //should use delimiter
		while( token != NULL) {
			int d = atoi(token);
	   		pinakas[i][j]=d;
	   		token = strtok(NULL," \n\t");
			j++;
		}
		i++;
		j=0;


	}
	i=0;
	int **tuxaioi= malloc (sizeof (int*) *(2* k));	////edw apothikeuontai oi tuxaioi arithmoi pou paragontai gia kathe L
	for(i=0;i<(2*k);i++){
		tuxaioi[i]=(int*)malloc(sizeof(int) * L);
	}
	for(j=0;j<L;j++){		////////apothikeusi tuxaiwn arithmwn
	for(i=0;i<k;i++){
		int tuxaios1=rand()%(count);
		int tuxaios2=rand()%(count);
		while(tuxaios1==tuxaios2){
			tuxaios1=rand()%(count);
			tuxaios2=rand()%(count);

		}
		//printf("tuxaioi :%d %d\n",tuxaios1,tuxaios2);
		tuxaioi[j][2*i]=tuxaios1;
		tuxaioi[j][2*i+1]=tuxaios2;

	}
	}
	int o=0;





///////////arxizoume na ftiaxnoume tis domes gia ta centroids kai ta dedomena pou 8a mpoun sta clusters


	

	int *line_total=malloc(sizeof(int)*count);
	int total_sum=0;
	double *v=malloc(sizeof(double)*count);	
	entries **entries_array=malloc(sizeof(entries*)*count);
	
	for(i=0;i<count;i++){
		entries_array[i]=malloc(sizeof(entries*));
		entries_array[i]->value=0;

	}
////ftiaxnoume tous pinaas me ta athroisma gia ta initializations
	for(i=0;i<count;i++){
		line_total[i]=0;
		for(j=0;j<count;j++){
			line_total[i]+=pinakas[i][j];
			//printf("line total %d \n",line_total[j]);
		}
		total_sum+=line_total[i];
	}

	double smallest=1;
	for(i=0;i<count;i++){
		entries_array[i]->distances=pinakas[i];
		entries_array[i]->position=i;
	}
	data **data_array=malloc(sizeof(data*)*count);
	init_data_array(count,data_array,entries_array,clusters);
	int assigning=0;
	centroids **centroids_array=malloc(sizeof(centroids*)*clusters);
///////////analoga me to ti edwse o xristis kanoume ta katallilo sundiasmo sunartisewn gia init assign kai update

	clock_t begin = clock();
	FILE *out=fopen(output,"w");
	//fprintf(out,"Algorithm:");
	 if(val[0]==1){
		centroids_array=plus_init(pinakas,data_array,count,clusters);
			//fprintf(out,"K-medoids++-");
	}	
	else if(val[0]==2){
		centroids_array=concentrate_init(pinakas,line_total,v,entries_array,count,data_array,clusters);
				//fprintf(out,"Park-Jun-");
	}
	if(val[1]==1){
		pam_assign(data_array,centroids_array,count,clusters);
		assigning=1;
		//fprintf(out,"PAM assignment-");
	}
	if(val[2]==1){
		update_Lloyds_matrix(centroids_array,data_array,count,k,L,tuxaioi,output,clusters,pinakas,assigning);
		//fprintf(out,"Updata a la Lloyds' \n");
	}







	int u;
	for(u=0;u<clusters;u++){
		for(i=0;i<count;i++){
			if(data_array[i]->centroid_position==centroids_array[u]->position){
				centroids_array[u]->total++;
			}
		}
	}

	//int silho=find_silhouett(data_array,count,out);



	fclose(stream);

	infos2 **infos_array=infos_init(1000,1000);

	int kati=0;
	for(i=0;i<1000;i++){
		strcpy(infos_array[i]->id,onomata[i]);
		for(j=0;j<1000;j++){
			if(data_array[i]->centroid_position==data_array[j]->centroid_position){

				infos_array[i]->apostaseis[kati]=pinakas[i][j];
				strcpy(infos_array[i]->found[kati],onomata[j]);
				//printf("kata %s \n",infos_array[i]->found[kati]);
				kati++;
			}
		}
		kati=0;
	}	
	int posas=0;
	fprintf(out,"Algorithm: Euclidean/Cosine Clustering\n");
	for(posas=0;posas<1000;posas++){
		fprintf(out,"User %d Recommending: ",posas+1);
		int posotis=0;
		for(o=0;o<4;o++){
			if(data_array[posas]->centroid_position==centroids_array[o]->position){
				posotis=centroids_array[o]->total;
			}
		}
		recommend *recom=malloc(sizeof(recommend)*1000);
		float z=find_z(infos_array,posas,posotis);
		int that=0,best_pos=0;
		float sunolo=0,best=0;
		for(that=0;that<1000;that++){
			float olo=find_rest2(infos_array,posas,that,items,posotis);
			sunolo=olo*z;
			recom[that].olo=sunolo;
			recom[that].position=that;
			if(sunolo>best){
				best=sunolo;
				best_pos=that;
			}
		}
		//printf(" BEST %f best pos %d \n",best,best_pos);
		quicksort5(recom,0,1000);
		int i=0;
		for(i=0;i<5;i++){
			fprintf(out,"item%d ",recom[i].position);
		}
		fprintf(out,"\n");
	}	

	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	fprintf(out,"Execution time: %f \n",time_spent);
	fclose(out);	
	/*for(i=0;i<count;i++){
		free(pinakas[i]);
		free(onomata[i]);
		for(u=0;u<clusters;u++){
			free(data_array[i]->centroids_for_data[u]);
		}
		free(data_array[i]);
		free(entries_array[i]);
	}
	free(data_array);
	free(entries_array);
	for(u=0;u<clusters;u++){
		free(centroids_array[u]);
	}
	free(centroids_array);
	free(pinakas);
	free(v);
	free(onomata);
	free(line_total);
	for(i=0;i<(2*k);i++){
		free(tuxaioi[i]);
	}
	free(tuxaioi);*/
}


///ftiaxnoume to arxeio pou 8a steiloume sto DBH me queries ta centroids mas

void create_query_matrix(centroids **centroids_array,int **pinakas,int aktina,int count,int clusters){
	char file[30]="Query_Distance_Matrix.txt";
	FILE* stream = fopen(file, "w");
	int i,j;
	fprintf(stream,"Radius:\t%d \n",aktina);
	for(i=0;i<clusters;i++){
		fprintf(stream,"item_idS%d",(i+1));
		for(j=0;j<count;j++){
			fprintf(stream,"\t%d",pinakas[centroids_array[i]->position][j]);
		}
		fprintf(stream,"\n");
	}
	fclose(stream);
}


//////////ulopoiei to update a la Lloyds' analoga me to assign pou exoume epilexei

void update_Lloyds_matrix(centroids **centroids_array,data** data_array,int count,int k,int L,int ** tuxaioi,char *output,int clusters,int **pinakas,int assigning){

	int i=0;
	while(i<clusters){
//////vriskoume to medoid tou cluster
		int old_centroid=centroids_array[i]->position;
		int something=find_cluster_medoid(centroids_array[i],data_array,count,old_centroid);
		//printf("KAINOURGIO %d \n",centroids_array[i]->position);
		if(assigning==1){
			pam_assign(data_array,centroids_array,count,clusters);
		}
			if(old_centroid==centroids_array[i]->position && i<5){
				i++;
			}

	}

}

/////////////allazoume arxika ta centroids upologizoume tin antikeimeniki sunartisi kai an einai xeiroteri apo tin
///////////// proigoumeni xanakanoume assign to proigoumeno centroid

void update_clarance_matrix(centroids **centroids_array,data **data_array,int amount,int k,int L,char *output,int** tuxaioi,int clusters,int **pinakas,int fraction,int iterations,int assigning){
	int q=0;
	int posa;
	for(q=0;q<iterations;q++){
	if(fraction==-1){
		posa=0.12*clusters*(amount-clusters);
	
		if(posa<250)	posa=250;
	}
	else{
		posa=fraction;
	}
	//printf("posa %d amount %d \n",posa,amount);
	int i=0,j=0,flag2=0,flag,aktina,u=0;
	int old_centroid,old_centroid_position,which;
		int total_distances=0;
		for(u=0;u<amount;u++){
			total_distances+=data_array[u]->distance_from_centroid;

		}
	for(i=0;i<posa;i++){
		int tuxaio_centroid=rand()%(clusters);
		int tuxaio_neo=rand()%amount;
		for(j=0;j<clusters;j++){
			if(centroids_array[j]->position!=tuxaio_neo)
				flag2=1;

		}


		if(flag2==1)
			tuxaio_neo=rand()%amount;
///////allazoume to centroid
		for(u=0;u<clusters;u++){
			if(centroids_array[u]->position==centroids_array[tuxaio_centroid]->position){
				old_centroid=centroids_array[u]->sum_distances;
				old_centroid_position=centroids_array[u]->position;			
				centroids_array[u]->position=data_array[tuxaio_neo]->position;
				centroids_array[u]->distances=data_array[tuxaio_neo]->distances;
				which=u;
			}
		}
		

		pam_assign(data_array,centroids_array,amount,clusters);
		//assign_LSH_matrix( k, L,tuxaioi,amount,pinakas,output,data_array,old_centroid_position,centroids_array,clusters);

		int new_total_distances=0;
////an exoun meinei stoixeia apo to proigoumeno centroid ta kanoume 0
		for(u=0;u<amount;u++){
			if(data_array[u]->centroid_position==old_centroid_position){
				data_array[u]->centroid_position=0;
				data_array[u]->distance_from_centroid=0;
			}
			else{
				data_array[u]->distance_from_centroid=data_array[u]->distances[data_array[u]->centroid_position];
		}
			new_total_distances+=data_array[u]->distance_from_centroid;
			centroids_array[which]->sum_distances=new_total_distances;
		}
/////////sugkrinoume tis apostaseis kai an oi kainourgia dn einai mikroteri tote xanakanoume assign ta palia centroids
		//printf("old %d new %d \n",total_distances,new_total_distances);
		if(total_distances<new_total_distances){

			int temp_centroid=centroids_array[which]->position;
			centroids_array[which]->position=old_centroid_position;
			
			centroids_array[which]->distances=data_array[old_centroid_position]->distances;
			pam_assign(data_array,centroids_array,amount,clusters);	
			//assign_LSH_matrix( k, L,tuxaioi,amount,pinakas,output,data_array,temp_centroid,centroids_array,clusters);
			for(u=0;u<amount;u++){
				if(data_array[u]->centroid_position==temp_centroid){
					data_array[u]->centroid_position=0;
					data_array[u]->distance_from_centroid=0;
				}
				else{
					data_array[u]->distance_from_centroid=data_array[u]->distances[data_array[u]->centroid_position];
				}
				new_total_distances+=data_array[u]->distance_from_centroid;
			}
			centroids_array[which]->sum_distances=total_distances;
		
			new_total_distances=0;
		}
		else{
			total_distances=new_total_distances;
		}		
	}
/////////koitame apo ta iterations poio einai kalutero 
	centroids **temp_centroid_array=malloc(sizeof(centroids*)*clusters);
	int best_distance=0,last_distance=0;
	last_distance=j_function(data_array,amount);
	if(last_distance<best_distance){
		best_distance=last_distance;
		temp_centroid_array=centroids_array;

	}
	else{
		pam_assign(data_array,centroids_array,amount,clusters);
		//assign_LSH_matrix( k, L,tuxaioi,amount,pinakas,output,data_array,0,temp_centroid_array,clusters);

	}
	}

}




#endif 

