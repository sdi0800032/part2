#ifndef RECORDS_MEDOID_H
#define RECORDS_MEDOID_H

/////////// domi gia ta centroids
typedef struct{
	int position;	//thesi me tin opoia diavastike
	double value;	
	int *distances;	////pinakas me tis aopstaseis apo ta alla simeia
	int sum_distances;
	int total;	////plithos egrafwn pou anikoun se auto to centroid
}centroids;

/////////domi pou mas voi8aei sta init
typedef struct{
	double value;
	int position;
	int *distances;
}entries;

////kuria domi twn egrafwn 
typedef struct{
	int distance_from_centroid;  ////apostasi apo to centroid
	int position;		/////thesi sto sunoliko pinaka
	int centroid_position;		////thesi tou centroid
	int distance_from_2nd_centroid;		/////apostasi apo to 2o kontinotero xentroid
	int second_centroid_position;	////i thesi tou deuterou kontinoterou centroid
	int *distances;	//////////pinakas me tis apostaseis apo ta alla simeia
	int has_been_centroid;
	int is_centroid;
	int which_centroid;	/////se poio centroid anikei me arithmitiki seira
	centroids **centroids_for_data;	//////pinakas me ta centroid pou ton kanoume sort gia na exoume me ti seira ta kontinotera centroids
}data;





typedef struct infos2{
	char *id;
	int *apostaseis;
	char **found;


}infos2;

typedef struct recommend{
	float olo;
	int position;
}recommend;



infos2 ** infos_init(int amount,int size);
#endif
