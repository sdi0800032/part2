#ifndef PAREHEADER_H
#define PAREHEADER_H


struct COS_items {
	double **item_array;
	int current_items;
	int current_dimension;
	int total_dimensions;
	int *centroid;
	int *temp_centroid;
	double *distance_to_centroid;
};

typedef struct COS_items *cos_items_ptr ;
cos_items_ptr store_vectors(char * , char * , char * , int );
void store_item_coords( double  , cos_items_ptr  ) ;
cos_items_ptr allocate_space_items( int );
char* store_distances( cos_items_ptr , int );

int* menu();
#endif
