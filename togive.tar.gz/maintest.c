#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>

#include "pareheader.h"


int main(int argc, char** argv){
	char path[256],query[256],output[256];
	int i=0;
	int k=4,L=5;
	int *val;
	cos_items_ptr items;
	char *filename;
	val = malloc(sizeof(char)*3);
	for(i=0;i<argc;i++){
		if(strcmp(argv[i],"-d")==0){
				strcpy(path,argv[i+1]);
				printf("%s\n",path);
		}
		if(strcmp(argv[i],"-q")==0){
				strcpy(query,argv[i+1]);
				printf("%s\n",query);
		}
		if(strcmp(argv[i],"-o")==0){
				strcpy(output,argv[i+1]);
				printf("%s\n",output);
		}
		if(strcmp(argv[i],"-k")==0){
			sscanf(argv[i+1], "%d", &k);
		}
		if(strcmp(argv[i],"-L")==0){
			sscanf(argv[i+1], "%d", &L);
		}
	}
	items = store_vectors( path , NULL , NULL , 0 );
	filename = store_distances(  items, items->current_items);
	printf("output file is %s \n" , filename);
	val = menu();
	for(i=0; i<3; i++)
	{
		printf("user entered %d \n" , val[i] );
	}
//	cptr1 = init_k_centroids(k , items->current_items);
//	cptr2 = init_k_centroids(k , items->current_items);
//	init_kmedoids_plus( cptr1 , items->current_items , items , k );
//	init_parkjun( cptr1 ,  items ,  k , items->current_items);
 //   pam_find_centers(cptr1 ,  items ,  k , items->current_items , 0);
	return 1;
}
